<?php
// determine if the database connection configuration is available
// if not, include the connection information
if( !defined("DB_HOST") ) {
    trigger_error("Database configuration is incorrect");
	die();
}

/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */
class Database {
	
	/*
	* Create variables for credientials to MySQl database
	* the database connection link
	* the database name
	* the password
	*/	
	private $dbhost = DB_HOST;
	private $dbuser = DB_USER;
	private $dbname = DB_NAME;
	private $dbpass = DB_PASS;
	private $query = NULL;
	private $con = NULL;
	private $result = array();
	
	/**
	 *@call the connection function
	 **/
	public function __construct() {
        $this->connect();
    }
	
	public function superAdministrator() {
		return FALSE;
	}
	
	public function connect() {
		if($this->con == NULL) {
			//connect to the database
			$this->mysqli = new mysqli($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname) or die('<h1>Error connecting to database. Please check your settings.</h1>');
			
			if($this->mysqli) {
				//set the connection to true
				$this->con = true;
				return true;
			} else {
				array_push($this->result, @mysqli_error($mysqli));
				return false;
			}
		} else {
			return true;
		}
	}
	
	
	public function getConnection() {
		return $this->con;	
	}
	
	public function disconnect() {
		if($this->con) {
			if(@mysqli_close($this->con)) {
				$this->con = false;
				return true;
			} else {
				return false;
			} 
		}
	}
	
	/*
	 *@query the database
	 *@request table and where clauses@
	 *
	*/
	public function select($sql) {
		$query = $this->mysqli->query($sql);
		return $query;
	}
	
	public function insert($sql) {
		$query = $this->mysqli->query($sql);
		
		if($query) {
			return $query;
		} else {
			return @mysqli_error($this->con);
		}
	}
	
	public function simple_insert($table, $data) {
		$query = $this->mysqli->query("INSERT INTO `$table` VALUES ($data)");
		
		if($query) {
			return $query;
		} else {
			return @mysqli_error($this->con);
		}
	}
	/*
	*@count the number of rows
	*/	
	public function scount($sql) {
		if($sql) {
			return mysqli_num_rows($sql);
		} else {
			return @mysqli_error($this->con);
		}
	}
	
	public function update($sql) {
		if($sql) {
			return $this->mysqli->query($sql);
		} else {
			return @mysqli_error($this->con);
		}
	}
	
	public function delete($table, $where) {
		$query = $this->mysqli->query("DELETE FROM `$table` $where");
		if($query) {
			return $query;
		} else {
			return @mysqli_error($this->con);
		}
	}
	
	public function db_error() {
		return mysqli_error($this->mysqli);
	}
	/**
	 * Get the insert id of the query
	 *
	 */
	public function getInsertId() {
	   return $this->mysqli->insert_id;   
	}
	
	/**
	 * Returns the database object used by the manager
	 * @return cleanData
	 * Cleans the user inputs 
	*/	
	public function cleanData($theValue) {
			
		if (PHP_VERSION < 6) {
			$theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
		}
			
		$theValue = function_exists("mysqli_real_escape_string") ? $this->mysqli->escape_string($theValue) : $this->mysqli->escape_string($theValue);
		
		$theValue = str_replace(
			array('\\','<?','?>','<script>','alert','</script>','\';','\'','window.location.href=','window','href=','location','<','>'),
			array('','','','','','','','','','','','',''), $theValue);
		
	
		$theValue = trim(stripslashes($theValue));
		
		return $theValue;
	}
	
	/**
	 * Returns the database object used by the manager
	 * @return cleanData
	 * validates only strings
	*/
	function str_validate($validString){
		
		$name_exp = "/^[a-zA-Z][A-Za-z]+$/";
		
		if(!preg_match($name_exp, $validString)){
			return false;
		}
		return $validString;
	}
			
	/**
	 * get the results of the query
	 * @return results
	 **/
	public function getResult() {
		return $this->result;
	}
}
?>