<?php

//This function is responsible for date/time formatting
function RelativeTimeCommented($timestamp) {
			
	if( !is_numeric( $timestamp ) ){
		$timestamp = strtotime( $timestamp );
	
		if( !is_numeric( $timestamp ) ){
				return ""; 
		} 
	}
		  
	$difference = time() - $timestamp;
	$periods = array( "sec", "min", "hr", "day", "week", "mth", "yrs", "decade" );
	$lengths = array( "60","60","24","7","4.35","12","10");
		
	if ($difference > 0) { // this was in the past
		$ending = "ago";
	}else { // this was in the future
		$difference = -$difference;
		$ending = "to go";
	}
		
	for( $j=0; $difference>=$lengths[$j] and $j < 7; $j++ )
		$difference /= $lengths[$j];
	$difference = round($difference);
	if( $difference != 1 ){
		// Also change this if needed for an other language
		$periods[$j].= "s";
	}
	$text = "$difference $periods[$j] $ending";
	return $text;
}
?>