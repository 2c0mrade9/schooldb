<?php
/**
*@check if the user wanted to access the file directly
*@if so display a forbidden page
**/
if(!defined("DB_HOST")) { include '../index.php'; die(); }


/**
 *@create the SiteOptions class
 *@let it extend the Database class
 *
*/
class Options extends Database { 
	
	/**
	 *@Set initial variables for the main site information
	**/
	public $data = NULL;
	public $SiteName = NULL;
	public $getMetaDescription = NULL;
	public $getSiteAddress = NULL;
	public $getSiteKeyWords = NULL;
	public $getSitePhone = NULL;
	public $getCreatedBy = NULL;
	public $getSiteUrl = NULL;
	public $SITE_URLMain = NULL;
	public $getSiteDescription = NULL;
	public $getSiteSlogan = NULL;
	public $getSiteEmail = NULL;
	public $getSiteAuthor = NULL;
	public $getSiteSEO = NULL;
	public $getSiteStatus = NULL;
	public $getSiteStatusMsg = NULL;
	public $getSiteHomePageText = NULL;
	public $getSiteFooterText = NULL;
	
	/**
	 *@create the site information function
	**/
	public function getSiteInformation() {
		
		/**
		 *@pass the information into an array
		 **/
		$db = new Database();
		
		/*
		 *@call the select function
		 *@select function takes 3 arguments one is compulsory
		 *@table, where_clause = NULL, limit = NULL
		 *@get the site options
		*/
		$sql = $db->select("SELECT * FROM `".TABLE_PREFIX."options`");
		
		/**
		 *@pass the information into an array
		 **/
		$data = $sql->fetch_assoc();
		
		/**
		 *@assign variables to the information
		 **/
		$this->SiteName = $data["SiteName"];
		$this->getMetaDescription = stripslashes($data["SiteDescription"]);
		$this->getSiteAddress = stripslashes($data["SiteAddress"]);
		$this->getSiteKeyWords = htmlspecialchars($data['SiteKeywords']);
		$this->getSitePhone = stripslashes($data['SitePhone']);
		$this->getCreatedBy = $data['CreatedBy'];
		$this->getSiteUrl = $data['SiteUrl'];
		$this->SITE_URLMain = $data['SiteUrlMain'];
		$this->getSiteAcademicYear = $data['AcademicYear'];
		$this->getSiteTerm = $data['Term'];
		$this->getSiteDescription = stripslashes($data['SiteDescription']);
		$this->getSiteSlogan = $data['SiteSlogan'];
		$this->getSiteEmail = stripslashes($data['SiteEmail']);
		$this->getSiteStatus = stripslashes($data['SiteActive']);
		$this->getSiteStatusMsg = stripslashes($data['SiteActiveMsg']);
		$this->getSiteSEO = stripslashes($data['SiteSEO']);
		$this->getSiteAuthor = stripslashes($data['CreatedBy']);
		$this->getSiteFooterText = stripslashes($data['SiteFooterText']);
		$this->getSiteHomePageText = stripslashes($data['SiteHomePageText']);
	
		/**
		 *@return this so as to asess the stored information
		 **/
		return $this;
	}
	
	/**
	 * @create new functions
	 * @Take variables from the getSiteInformation Function
	 * @Assign variables to the site information
	 */
	public function getSiteName() {
		return $this->getSiteInformation()->SiteName;
	}
	
	public function getMetaDescription() {
		return $this->getSiteInformation()->getMetaDescription;
	}
	
	public function getSiteUrl() {
		return $this->getSiteInformation()->getSiteUrl;
	}
	
	public function getSiteUrlMain() {
		return $this->getSiteInformation()->SITE_URLMain;
	}
	
	public function getSiteAddress() {
		return $this->getSiteInformation()->getSiteAddress;
	}
	
	public function getSiteKeyWords() {
		return $this->getSiteInformation()->getSiteKeyWords;
	}
	
	public function getSitePhone() {
		return $this->getSiteInformation()->getSitePhone;
	}
	
	public function getCreatedBy() {
		return $this->getSiteInformation()->getCreatedBy;
	}
	
	public function getSiteDescription() {
		return $this->getSiteInformation()->getSiteDescription;
	}
	
	public function getSiteSlogan() {
		return $this->getSiteInformation()->getSiteSlogan;
	}
	
	public function getSiteEmail() {
		return $this->getSiteInformation()->getSiteEmail;
	}
	
	public function getSiteSEO() {
		return $this->getSiteInformation()->getSiteSEO;
	}
	
	public function getSiteFooterText() {
		return $this->getSiteInformation()->getSiteFooterText;
	}
	
	public function getSiteHomePageText() {
		return $this->getSiteInformation()->getSiteHomePageText;
	}
	
	public function getSiteStatus() {
		return $this->getSiteInformation()->getSiteStatus;
	}
	
	public function getSiteStatusMsg() {
		return $this->getSiteInformation()->getSiteStatusMsg;
	}
	
	public function getSiteAuthor() {
		return $this->getSiteInformation()->getSiteAuthor;
	}
	
	public function getSiteAcademicYear() {
		return $this->getSiteInformation()->getSiteAcademicYear;
	}
	
	public function getSiteTerm() {
		return $this->getSiteInformation()->getSiteTerm;
	}
	
	/**
	*@destroy the connection to save disk space / memory
	**/
	public function __destruct() {
	}
}


?>