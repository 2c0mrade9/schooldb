<?php
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
//start a new session
// *** Validate request to login to this site.
session_start();

////////////////////////////////////////////////////////////////////////////
///////////////////// ERROR REPORTING //////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
error_reporting(E_ALL);
ini_set('display_errors', '1');

//page_category_to_display for footer
$page_category_to_display = '';
// get the current directory path
$currentPath = str_replace("\\", "/", dirname(__FILE__)) . "/";

$endPos = 0; // try to determine the base root
// check if we are configuring a normal page
if (strpos($currentPath, "/pages/") != 0) { // if we are not configuring a page
    $endPos = strpos($currentPath, "/pages/");

// check if configuring a theme related document
} else if (strpos($currentPath, "/themes/") != 0) {
    $endPos = strpos($currentPath, "/themes/");

// check if configuring a cms related document
} else if (strpos($currentPath, "/cms/") != 0) {
    $endPos = strpos($currentPath, "/cms/");

// check if configuring a cms related document
} else if (strpos($currentPath, "/assets/") != 0) {
    $endPos = strpos($currentPath, "/assets/");
    
} else if (strpos($currentPath, "/core/") != 0) {
    $endPos = strpos($currentPath, "/core/");
}

$base = substr($currentPath, 0, $endPos + 1);
$prot = explode("/", $_SERVER['SERVER_PROTOCOL']);
$siteRoot = str_replace($_SERVER['DOCUMENT_ROOT'], "/", $base);
$siteRoot = str_replace("//", "/", $siteRoot);
$siteHost = strtolower($prot[0]) . "://" . $_SERVER['HTTP_HOST'];
$basePath = str_replace("//", "/", $_SERVER['DOCUMENT_ROOT'] . $siteRoot);

////////////////////////////////////////////////////////////////////////////
/////////////////// SETTING CONSTANTS //////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
define('SITE_ROOT',$siteHost.''.$siteRoot);
define('CORE_PATH', $basePath.'/core');
define('SITE_NAME','Future VIP\'s');
define('ASSETS_PATH', $base.'/assets');
define('CONTROLLER_PATH', CORE_PATH.'/controller');
define('MODELS_PATH', CORE_PATH.'/models');
define('VIEWS_PATH', CORE_PATH.'/views');
define('UTILS_PATH', CORE_PATH.'/utils');
define('CONFIG_PATH', ASSETS_PATH.'/-__config_-');
define('IMAGES_PATH', ASSETS_PATH.'/images');
define('JS_PATH', ASSETS_PATH.'/js');
define('THEMES_PATH', ASSETS_PATH.'/theme');
define('TEMP_PATH', ASSETS_PATH.'/tmp');
define('ERROR_FILE', TEMP_PATH.'/error505.php');
define('TABLE_PREFIX', 'cepstb_');
define('NAVIGATION_LIMIT', 25);
////////////////////////////////////////////////////////////////////////////
//////////// INCLUDE THE CONFIGURATION FILES ///////////////////////////////
////////////////////////////////////////////////////////////////////////////

require(CONFIG_PATH.'/connect_to_mysql.php');
require(UTILS_PATH.'/Database.php');
require(CORE_PATH.'/Options.php');

$site = new Options();
$db = new Database();

//DEFINE THE SITE URL IN THE DATABASE
define('SITE_URL', $site->getSiteUrl());
define('SITE_MAIN_URL', $site->getSiteUrlMain());
define('SITE_MAIN_STATUS', $site->getSiteStatus());
define('SITE_ASSETS_PATH', SITE_URL.'/assets');
define('SITE_IMAGE_PATH', SITE_URL.'/assets/images');
define('SITE_JS_PATH', SITE_URL.'/assets/js');
define('SITE_CSS_PATH', SITE_URL.'/assets/css');
define('STAFF_IMAGE_PATH', SITE_IMAGE_PATH.'/pfiles');
define('AC_YEAR', $site->getSiteAcademicYear());
define('AC_TERM', $site->getSiteTerm());
?>