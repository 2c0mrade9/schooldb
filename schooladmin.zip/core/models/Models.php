<?php
/**
*@check if the user wanted to access the file directly
*@if so display a forbidden page
**/
if(!defined("DB_HOST")) { include '../index.php'; die(); }

/**
 *@create the Models class
 *@let it extend the Database class
 *
*/
class Models extends Database {
			
	//construct the neccesary connection
	public function construct() {		
		//take the connection from the parent class (Database Class)
        parent::connect();
    }
	
	public function RelativeTimeCommented($timestamp) {
			
			if( !is_numeric( $timestamp ) ){
				$timestamp = strtotime( $timestamp );
			
				if( !is_numeric( $timestamp ) ){
						return ""; 
				} 
			}
		  
			$difference = time() - $timestamp;
			$periods = array( "sec", "min", "hr", "day", "week", "mth", "yrs", "decade" );
			$lengths = array( "60","60","24","7","4.35","12","10");
			
			if ($difference > 0) { // this was in the past
				$ending = "ago";
			}else { // this was in the future
				$difference = -$difference;
				$ending = "to go";
			}
			
			for( $j=0; $difference>=$lengths[$j] and $j < 7; $j++ )
				$difference /= $lengths[$j];
			$difference = round($difference);
			if( $difference != 1 ){
						// Also change this if needed for an other language
				$periods[$j].= "s";
			}
			$text = "$difference $periods[$j] $ending";
			return $text;
		}
	
	public function create_slug($string, $ext=''){     
		$replace = '-';
		$string = strtolower($string);     
		
		//remove query string     
		if(preg_match("#^http(s)?://[a-z0-9-_.]+\.[a-z]{2,4}#i",$string)){         
			$parsed_url = parse_url($string);         
			$string = $parsed_url['host'].' '.$parsed_url['path'];         
			//if want to add scheme eg. http, https than uncomment next line         
			//$string = $parsed_url['scheme'].' '.$string;    
		}     
		
		//replace / and . with white space     
		$string = preg_replace("/[\/\.]/", " ", $string);     
		$string = preg_replace("/[^a-z0-9_\s-]/", "", $string);     
		
		//remove multiple dashes or whitespaces     
		$string = preg_replace("/[\s-]+/", " ", $string);     
		
		//convert whitespaces and underscore to $replace     
		$string = preg_replace("/[\s_]/", $replace, $string);    
		
		//limit the slug size     
		$string = substr($string, 0, 100);     
		
		//slug is generated     
		return ($ext) ? $string.$ext : $string; 
	}
	
	public function limit_words($string, $word_limit = null) {
		
		$words = explode(" ",$string);
		
		return implode(" ", array_splice($words, 0, $word_limit));
	}
	
	function image_resize($path) {

           $x = getimagesize($path);            
           $width  = $x['0'];
           $height = $x['1'];

           $rs_width  = $width / 2;//resize to half of the original width.
           $rs_height = $height / 2;//resize to half of the original height.

           switch ($x['mime']) {
              case "image/gif":
                 $img = imagecreatefromgif($path);
                 break;
              case "image/jpeg":
                 $img = imagecreatefromjpeg($path);
                 break;
              case "image/png":
                 $img = imagecreatefrompng($path);
                 break;
           }

           $img_base = imagecreatetruecolor($rs_width, $rs_height);
           imagecopyresized($img_base, $img, 0, 0, 0, 0, $rs_width, $rs_height, $width, $height);

           $path_info = pathinfo($path);    
           switch ($path_info['extension']) {
              case "gif":
                 imagegif($img_base, $path);  
                 break;
              case "jpeg":
                 imagejpeg($img_base, $path);  
                 break;
              case "png":
                 imagepng($img_base, $path);  
                 break;
           }

        }
}
?>