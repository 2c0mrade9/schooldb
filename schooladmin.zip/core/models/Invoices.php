<?php 

class Invoices {
	
	public function __construct() {
		$site = new Options;
		//get some external variables
		$this->academicTerm = $site->getSiteTerm();
		$this->academicYear = $site->getSiteAcademicYear;
		
		return $this;
	}
	
	public function getInvoices($where, $limit=5, $order='desc', $academicYear=false, $academicTerm=false) {
		
		$db = new Database;
		$site = new Options;
		
		if($where != null)
			$add = $where . "";
		else
			$add = '';
		
		if($academicYear == false)
			$academicYear = "`academicyear`='{$this->academicYear}' AND ";
		else
			$academicYear = "";
		
		if($academicTerm == false)
			$academicTerm = "`term`='{$this->academicTerm}' AND ";
		elseif($academicTerm != false and $academicTerm != "all_terms")
			$academicTerm = " AND";
		elseif($academicTerm != false and $academicTerm == "all_terms")
			$academicTerm = 'AND';
			
		$sql = $db->select("
			SELECT 
				id, sum(amount) as amount,unqid,feetypeid,feetype,studentid,studentunq,studentemail,class,classid,academicyear,term,date,status
			FROM `payments` 
			WHERE 
				$add
				$academicYear
				$academicTerm
				`status`='1'
				GROUP BY `studentunq`,`term`
			ORDER BY `id` desc
			$limit
		");
		
		if($db->scount($sql) > 0) {
			while($res = $sql->fetch_assoc()) {
				
				$student = new Students;
				$feestype = new FeesType;
				$classes = new Classes;
				
				$display = "<tr align='left' class='gradeU'>";
				$display .= "<td><strong>{$res['id']}</strong></td>";
				$display .= "<td>{$res['feetype']}</td>";
				$display .= "<td style='text-align:left'>".date("d M Y", strtotime($res['date']))."</td>";
				$display .= "<td align='left' style='text-align:left'>".$this->generatePaymentStatus(
								$this->academicTerm, 
								$this->academicYear, 
								$res['studentunq'], 
								$res['classid'], 
							$res['feetypeid'])->paymentsStatus."
						</td>";
				$display .= "<td>{$res['studentid']}</td>";
				//get the fees for the fee type
				if($res['feetypeid'] == 1)
					$display .= "<td>".$this->amount = $classes->getClassById($res['classid'])->classFees."</td>";
				else
					$display .= "<td>".$feestype->getFeeTypeById($res['feetypeid'])->feeTypeAmount."</td>";
				$display .= "<td>{$res['amount']}</td>";
				$display .= "<td>{$this->getInvoiceById($res['unqid'])->invoiceFeeBalance}</td>";
				$display .= "<td style='text-align:left'>";
				$display .= '
				<a href="'.SITE_URL.'/invoice-view/'.$res['unqid'].'" class="btn btn-info" data-placement="top" data-toggle="tooltip" data-original-title="View" title="View"><i class="fa fa-check-square-o"></i></a>
				<a href="'.SITE_URL.'/invoice-edit/'.$res['unqid'].'" class="btn btn-warning" data-placement="top" data-toggle="tooltip" data-original-title="Edit" title="Edit"><i class="fa fa-edit"></i></a>
				<a onclick="javascript:confirmSubmit(\''.$res['id'].'\',\'payments\', \'Payment of Student With ID - ('.$res['studentunq'].')\');" class="btn btn-danger" title="Delete" data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i></a>';
				$display .= "";
				$display .= "</td>";
				$display .= "</tr>";

				print $display;
			}

		} else {
			
		}
	}
	
	public function getInvoiceById($invoiceId) {
		//initialize
		$this->invoiceResult = false;
		//create object
		$student = new Students;
		$db = new Database;
		$feestype = new FeesType;
		$classes = new Classes;
		//clean the invoice id parsed
		$invoiceId = $db->cleanData($invoiceId);
		//query the database
		$sql = $db->select("SELECT * FROM `payments` WHERE `unqid`='$invoiceId' AND `status`='1'");
		//count the row
		if($db->scount($sql) > 0) {
			//set invoice result
			$this->invoiceResult = true;
			//using the while loop
			while($result = $sql->fetch_assoc()) {
				//set the variables
				$this->invoiceUnq = $result["unqid"];
				$this->invoiceFeeType = $result["feetype"];
				$this->invoiceFeeTypeID = $result["feetypeid"];
				$this->invoiceStudentId = $result["studentid"];
				$this->invoiceStudentUnq = $result["studentunq"];
				$this->invoiceAcademicYear = $result["academicyear"];
				$this->invoiceAcademicYearO = '<option value="'.$this->invoiceAcademicYear.'" selected="selected">'.$this->invoiceAcademicYear.'</option>';
				$this->invoiceTerm = $result["term"];
				$this->invoiceTermR = $result["term"];
				if($this->invoiceTerm == 1)
					$this->invoiceTerm = "Term One";
				elseif($this->invoiceTerm == 2)
					$this->invoiceTerm = "Term Two";
				elseif($this->invoiceTerm == 3)
					$this->invoiceTerm = "Term Three";
				elseif($this->invoiceTerm == 4)
					$this->invoiceTerm = "Term Four";
				else
					$this->invoiceTerm = "Term One";
					
				$this->invoiceAmount = $result["amount"];
				$this->invoiceDateR = $result["date"];
				$this->invoiceDate = date("d M Y", strtotime($result["date"]));
				$this->invoiceStudentName = $this->invoiceStudentId;
				$this->invoiceStudentClass =  $result["class"];
				$this->invoiceStudentClassId =  $result["classid"];
				$this->invoiceStudentEmail =  $result["studentemail"];
				$this->invoiceStudentPhone =  $result["studentphone"];
				$this->invoiceFeeTypeName = $this->invoiceFeeType;
				if($result['feetypeid'] == 1)
					$this->invoiceFeeTypeAmount = $classes->getClassById($this->invoiceStudentClassId)->classFees;
				else
					$this->invoiceFeeTypeAmount = $feestype->getFeeTypeById($result['feetypeid'])->feeTypeAmount;
				$this->invoiceSubTotal = $this->getStudentsTotalPayments(
											$this->invoiceAcademicYear,
											$this->invoiceTermR,
											$this->invoiceStudentUnq,
											$this->invoiceFeeTypeID,
											$this->invoiceStudentClassId
										)->totalPayment;
				
										
				$this->invoiceFeeBalance = $student->getStudentById($this->invoiceStudentUnq)->studentBalance;
				
				//get the feetype and its amount
				
				$this->paymentStatus = $this->getStudentsTotalPayments(
							$this->invoiceAcademicYear,
							$this->invoiceTermR,
							$this->invoiceStudentUnq,
							$this->invoiceFeeTypeID,
							$this->invoiceStudentClassId
						)->paymentStatus;
			}
		} else {
			$this->invoiceResult = false;
			$this->invoiceFeeBalance = '0.00';
		}
		return $this;
	}
	
	public function getStudentsTotalPayments($year, $term, $studentID, $feeTypeId,$classID=false){
		//create object
		$db = new Database;
		$classes = new Classes;
		$feestype = new FeesType;
		
		if(empty($term))
			$academicTerm = $this->academicTerm;
		else
			$academicTerm = $term;
		
		if(empty($year))
			$academicYear = $this->academicYear;
		else
			$academicYear = $year;
		
		//query the database
		$sql = $db->select("SELECT * FROM `payments` 
			WHERE 
				`feetypeid`='$feeTypeId' AND 
				`studentunq`='$studentID' AND
				`academicyear`='$academicYear' AND 
				`term`='$academicTerm' AND 
				`status`='1' 
			ORDER BY `id` DESC");
			
		//get the fees for the fee type
		if($feeTypeId == 1)
			$this->amount = $classes->getClassById($classID)->classFees;
		else
			$this->amount = $feestype->getFeeTypeById($feeTypeId)->feeTypeAmount;
		//count the number of rows
		if($db->scount($sql) > 0) {
			//QUERY TO GET THE TOTAL PAYMENT FOR THE TERM
			$sumsql = $db->select("
				SELECT SUM(amount) AS amount FROM `payments` 
					WHERE 
						`feetypeid`='$feeTypeId' AND 
						`studentunq`='$studentID' AND
						`academicyear`='$academicYear' AND 
						`term`='$academicTerm' AND 
						`status`='1' 
					group by studentunq ORDER BY `id` DESC");
				if($db->scount($sumsql) > 0) {
					$result = $sumsql->fetch_assoc();
					$this->totalPayment = $result['amount'];
					$this->getBalance = $this->amount - $this->totalPayment;
					
					if($this->getBalance == 0)
						$this->paymentStatus = '<button class="btn btn-success btn-xs">Fully Paid</button>';
					elseif($this->totalPayment == ($this->amount/2))
						$this->paymentStatus = '<button class="btn bg-blue btn-xs">Half Paid</button> ';
					else
						$this->paymentStatus = '<button class="btn btn-warning btn-xs">Partially Paid</button> '; 
				}
		} else {
			$this->totalPayment = "0.00";
			$this->getBalance = $this->amount;
			$this->paymentStatus = '<button class="btn btn-danger btn-xs">Nothing Paid</button>';
		}
		
		return $this;
	}
		
	public function generatePaymentStatus($academicTerm, $academicYear, $studentID, $studentClass, $feeTypeId) {
		
		$db = new Database;
		$classes = new Classes;
		$feestype = new FeesType;
		
		if($academicYear == false)
			$academicYear = "`academicyear`='{$this->academicYear}' AND ";
		else
			$academicYear = "";
		
		if($academicTerm == false)
			$academicTerm = "`term`='{$this->academicTerm}' AND ";
		else
			$academicTerm = " AND";
		
		$sql = $db->select("
			SELECT SUM(amount) AS amount FROM `payments` 
			WHERE 
				`feetypeid`='$feeTypeId' AND 
				`studentunq`='$studentID'
				$academicYear
				$academicTerm
				`status`='1'
			GROUP BY `studentunq`,`feetypeid`,`term`
			ORDER BY `id` desc
		");
		
		if($db->scount($sql) >0) {
			while($result = $sql->fetch_assoc()) {
				$this->totalPaymentMade = $result['amount'];
				//get the fees for the fee type
				if($feeTypeId == 1)
					$this->totalAmount = $classes->getClassById($studentClass)->classFees;
				else
					$this->totalAmount = $feestype->getFeeTypeById($feeTypeId)->feeTypeAmount;
				
				$this->getBalance = $this->totalAmount - $this->totalPaymentMade;
				
				if($this->getBalance == 0)
					$this->paymentsStatus = '<button class="btn btn-success btn-xs">Fully Paid</button>';
				elseif($this->totalPaymentMade == ($this->totalAmount/2))
					$this->paymentsStatus = '<button class="btn bg-blue btn-xs">Half Paid</button> ';
				elseif($this->getBalance < 0)
					$this->paymentsStatus = '<button style="text-align:left" class="btn btn-success btn-xs">Fully Paid (GHC '.$result['amount'].') <br><span style="color:yellow"> Balance: GHC: '.($this->getBalance*-1).'</span></button> ';
				elseif($this->getBalance == $this->totalAmount)
					$this->paymentsStatus = '<button class="btn btn-danger btn-xs">Not paid at all</button> ';
				elseif($this->getBalance > 0)
					$this->paymentsStatus = '<button class="btn bg-blue btn-xs">Partial Payment</button> ';
			}
		} else {
			$this->totalPaymentMade = "0.00";
		}
		
		return $this;
	}
	
	
	public function getStudentsFeesPayments($where = null, $limit = null, $order = "ASC") {
		$db = new Database();
		
		if($where != null)
			$add = $where . " AND status='1'";
		else
			$add = "status='1'";
		
		
		$sql = $db->select("SELECT * FROM `students` WHERE $add ORDER BY `id` $order $limit");
		
		
	}
}
?>