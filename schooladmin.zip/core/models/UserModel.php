<?php
// determine if the database connection configuration is available
// if not, include the connection information
if(!defined("DB_HOST")) { include '../index.php'; die(); }


/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */

class UserModel extends Models {

	public $display_submenu;
	public $data = NULL;


	public function getAdminUsers() {
		$db = new Database();

		$sql = $db->select("SELECT * FROM `tb_admin` WHERE `status`='1'");

		while($res = $sql->fetch_assoc()) {
			
			$name_alias = str_ireplace(' ', '-', strtolower($res['FullName']));
			$display = "<tr class='gradeU'>";
			$display .= "<td>{$res['id']}</td>";
			$display .= "<td>{$res['FirstName']} {$res['LastName']}</td>";
			$display .= "<td>{$res['Username']}</td>";
			$display .= "<td>".ucwords($res['Level'])."</td>";
			$display .= "<td>".date("D dS M Y H:i:s a", strtotime($res['LastAccess']))."</td>";
			if(isset($_SESSION["theFutureAdminLoggedIns"])) {
				$display .= "<td><a href='".SITE_URL."/users-edit/{$res['Username']}/{$res['id']}?edit' class='btn btn-success'>";
				$display .= "<i class='fa fa-edit fa-fw'></i>Edit</a> ";
				$display .= '
				<a onclick="javascript:confirmSubmit(\''.$res['id'].'\',\'tb_admin\', \'Administrator with Name - ('.$res['FirstName'].' '.$res['LastName'].')\');" title="Delete" class="btn btn-danger" data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i> Delete</a>
				';
				$display .= "</td>";
			}
			$display .= "</tr>";

			print $display;
		}

	}
	
	public function getUserDetails($id) {
		$db = new Database();
		$this->found = true;
		
		$sql = $db->select("SELECT * FROM `tb_admin` WHERE `id`='$id' AND `status`='1'");
		if($db->scount($sql) == 1) {
			while($res = $sql->fetch_assoc()) {
				
				$this->found = true;
				
				$this->fname = $res['FirstName'];
				$this->lname = $res['LastName'];
				$this->funame = $res['FullName'];
				$this->uname = $res['Username'];
				$this->email = $res['Email'];
				$this->role = $res['Role'];
				$this->id = $res['id'];
				$this->lacs = strftime(date("D d M Y, H:i:a", strtotime($res['LastAccess'])));
				
				return $this;
			}
		} else {
			$this->found = false;
		}
		return $this;
	}
	

}
?>