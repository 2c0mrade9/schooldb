<?php 
// determine if the database connection configuration is available
// if not, include the connection information
if(!defined("DB_HOST")) { include '../index.php'; die(); }

class Designation {
	
	public $classResult = false;
	
	public function getDesignation($where = null, $limit = null, $order = "ASC") {
		$db = new Database();
		
		if($where != null)
			$add = $where . " AND status='1'";
		else
			$add = "status='1'";
		
		
		$sql = $db->select("SELECT * FROM `designation` WHERE $add ORDER BY `id` $order $limit");
		
		if($db->scount($sql) > 0) {
			while($res = $sql->fetch_assoc()) {
				//count the number of employees with the specified designation
				$count = $db->scount($db->select("SELECT * FROM employee WHERE designation='{$res['id']}' AND status='1'"));
							
				$display = "<tr align='left' class='gradeU'>";
				$display .= "<td><strong>{$res['id']}</strong></td>";
				$display .= "<td style='text-align:left'>".ucwords($res['name'])."</td>";
				$display .= "<td>{$count}</td>";
				$display .= "<td style='text-align:left'>";
				$display .= '<a href="'.SITE_URL.'/designation-view/'.$res['id'].'" class="btn btn-warning" data-placement="top" data-toggle="tooltip" data-original-title="View"><i class="fa fa-edit"></i> View </a>
				<a onclick="javascript:confirmSubmit(\''.$res['id'].'\',\'designation\', \'Designation with Name - ('.$res['name'].')\');" class="btn btn-danger" data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i>Delete</a>';
				$display .= "";
				$display .= "</td>";
				$display .= "</tr>";

				print $display;
			}

		} else {
			print "<tr align='left' class='gradeU'><td colspan='4'>Sorry! No data was found.</td><td></td><td></tr>";
		}

	}
	
	public function getDesignationById($id,$linked=false) {
		
		$db = new Database;
		
		//check if the id sent is numeric
		if(!is_numeric($id)) {
			//return false if not numeric
			$this->desigResult = false;
		} else {
			//if numeric then process by quering the database
			$sql = $db->select("SELECT * FROM `designation` WHERE `id`='$id'");
			//count the number of rows
			if($db->scount($sql) == 1) {
				//get the information 
				$this->desigResult = true;
				while($res = $sql->fetch_assoc()) {
					$this->desigId = $id;
					$this->desigName  = $res['name'];
					if($linked != false)
						$this->desigName = "<a href='".SITE_URL."/designation-view/$id'>{$this->desigName}</a>";
					
					$this->desigSlug = $res['slug'];
					$this->desigOpt = "<option value='{$res['id']}' selected='selected'>{$res['name']}</option>";
				}
			} else {
				//set an error
				$this->desigResult = false;
				$this->desigName = '';
				$this->desigSlug = "";
				$this->desigOpt = '';
			}
		}
		//return the results
		return $this;
	}
	
	public function getMonthById($id,$linked=false) {
		
		$db = new Database;
		
		//check if the id sent is numeric
		if(!is_numeric($id)) {
			//return false if not numeric
			$this->monResult = false;
		} else {
			//if numeric then process by quering the database
			$sql = $db->select("SELECT * FROM `months` WHERE `id`='$id'");
			//count the number of rows
			if($db->scount($sql) == 1) {
				//get the information 
				$this->monResult = true;
				while($res = $sql->fetch_assoc()) {
					$this->monName = $res['name'];
				}
			} else {
				//set an error
				$this->monResult = false;
				$this->monName = '';
			}
		}
		//return the results
		return $this;
	}
	
	public function getQualificationById($id,$linked=false) {
		
		$db = new Database;
		
		//check if the id sent is numeric
		if(!is_numeric($id)) {
			//return false if not numeric
			$this->quaResult = false;
		} else {
			//if numeric then process by quering the database
			$sql = $db->select("SELECT * FROM `qualification` WHERE `id`='$id' AND status='1'");
			//count the number of rows
			if($db->scount($sql) == 1) {
				//get the information 
				$this->quaResult = true;
				while($res = $sql->fetch_assoc()) {
					$this->quaId = $id;
					$this->quaName  = $res['name'];
					if($linked != false)
						$this->quaName = "<a href='".SITE_URL."/qualification-view/$id'>{$this->quaName}</a>";
					
					$this->quaSlug = $res['slug'];
					$this->quaOpt = "<option value='{$res['id']}' selected='selected'>{$res['name']}</option>";
				}
			} else {
				//set an error
				$this->quaResult = false;
				$this->quaName = '';
				$this->quaSlug = "not-set";
				$this->quaOpt = "";
			}
		}
		//return the results
		return $this;
	}
	
}

?>