<?php 
// determine if the database connection configuration is available
// if not, include the connection information
if(!defined("DB_HOST")) { include '../index.php'; die(); }

class Remarks {
	
	public $remarksResult = false;
	
	public function getRemarks($where = null, $s_table) {
		$db = new Database();
		
		if($where != null)
			$add = $where . " AND status='1'";
		else
			$add = "status='1'";
		
		
		$sql = $db->select("SELECT * FROM $s_table WHERE $add ORDER BY `id` $order $limit");
		
		if($db->scount($sql) > 0) {
			
		} else {
			print "<tr align='left' class='gradeU'><td colspan='3'>Sorry! No data was found.</td><td></td><td></td><td></tr>";
		}

	}
	
	public function getRemarksByid($id,$s_table) {
		//create new database object;
		$db = new Database;
		//clean the data parsed by the user
		$id = $db->cleanData($id);
		$s_table = $db->cleanData($s_table);
		//initial values
		$this->remResult = false;
		//set the field to query
		if($s_table == "students")
			$field = "studentunq";
		elseif($s_table == "employees")
			$field  = "id";
		
		//query the database
		$sql = $db->select("SELECT * FROM $s_table WHERE $field='$id' AND status='1'");
		
		//count the number of rows found and return the appropriate search results
		if($db->scount($sql) == 1) {
			$this->remResult = true;
			//fetch the results
			$result = $sql->fetch_assoc();
			//assign variables
			$this->headTeacher = $result['headteacher_remarks'];
			$this->proprietress = $result['proprietries_remarks'];
		} else {
			$this->remResult = false;
		}
		
		return $this;
		
	}
}

?>