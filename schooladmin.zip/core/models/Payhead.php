<?php

class Payhead {
	
	public function getPayheadById($id,$linked=false) {
		
		$db = new Database;
		
		//check if the id sent is numeric
		if(!is_numeric($id)) {
			//return false if not numeric
			$this->payHeadResult = false;
		} else {
			//if numeric then process by quering the database
			$sql = $db->select("SELECT * FROM `payhead` WHERE `id`='$id' AND status='1'");
			//count the number of rows
			if($db->scount($sql) == 1) {
				//get the information 
				$this->payHeadResult = true;
				while($res = $sql->fetch_assoc()) {
					$this->payHeadId = $id;
					$this->payHeadName  = $res['name'];
					if($linked != false)
						$this->payHeadName = "<a href='".SITE_URL."/payhead-view/$id'>{$this->payHeadName}</a>";
					$this->payHeadSlug = $res['slug'];
					$this->payHeadNote = $res['description'];
					$this->payheadOpt = "<option value='{$res['id']}' selected='selected'>{$res['name']}</option>";
				}
			} else {
				//set an error
				$this->payHeadResult = false;
				$this->payHeadName = 'NotSet';
				$this->payHeadNote = '';
				$this->payHeadSlug = '';
				$this->payheadOpt = '';
			}
		}
		//return the results
		return $this;
	}
	
	public function getSalarySettingsById($tid) {
		//create new objects
		$db = new Database;
		$design = new Designation;
		//clean the data parsed
		$this->tid = $db->cleanData($tid);
		//set the found == false
		$this->s_found = false;
		//query the database
		$sql = $db->select("SELECT * FROM salary_settings WHERE employeeid='$tid' AND status='1'");
		//count the number of rows found
		if($db->scount($sql) > 0) {
			$this->s_found = true;
			//fetch the information
			$result = $sql->fetch_assoc();
			//set the values with its own variables
			$this->design = $result["designation"];
			$this->design_opt = $design->getDesignationById($this->design)->desigOpt;
			$this->payhead = $result["payhead"];
			$this->payhead_opt = $this->getPayheadById($this->payhead)->payheadOpt;
			$this->employeeid = $result["employeeid"];
			$this->amount = $result["amount"];
			$this->balance = $result["balance"];
			$this->rdate = $result["rdate"];
		} else {
			$this->s_found = false;
		}
		return $this;
	}
	
	public function paymentDetails($tid,$amt,$mid,$yid) {
		//create new objects
		$db = new Database;
		//
		$sql = $db->select("select id,month,sum(amount) as amount,employeeid,year from payroll 
						where month='$mid' and employeeid='$tid' and year='$yid' and status='1'
						group by month,employeeid,year");
		if($db->scount($sql) >0) {
			while($result = $sql->fetch_assoc()) {
				$this->bal = $amt-$result['amount'];
				$this->amt = $result['amount'];
			}
		} else {
			$this->bal = $amt+$this->getSalarySettingsById($tid)->balance;
			$this->amt = '0';
		}
		
		return $this;
 	}
}
?>