<?php 
// determine if the database connection configuration is available
// if not, include the connection information
if(!defined("DB_HOST")) { include '../index.php'; die(); }

class Classes {
	
	public $classResult = false;
	
	public function getClasses($where = null, $limit = null, $order = "ASC") {
		$db = new Database();
		
		if($where != null)
			$add = $where . " AND status='1'";
		else
			$add = "status='1'";
		
		
		$sql = $db->select("SELECT * FROM `class` WHERE $add ORDER BY `id` $order $limit");
		
		if($db->scount($sql) > 0) {
			while($res = $sql->fetch_assoc()) {
				
				$student = new Students;
				$employees = new Employees;
				$count = new CountModel;
				
				$this->classTeacher = $employees->getEmployeeById($res['teacher'],'linked')->teacherName;
				$this->classNumber = $count->TableCount('students','WHERE `class`="'.$res['id'].'"')->table_count;
				
				$display = "<tr align='left' class='gradeU'>";
				$display .= "<td><strong>{$res['id']}</strong></td>";
				$display .= "<td style='text-align:left'>".ucwords($res['name'])."</td>";
				$display .= "<td>{$this->classTeacher}</td>";
				$display .= "<td>{$this->classNumber}</td>";
				$display .= "<td>{$res['fees']}</td>";
				$display .= "<td style='text-align:left'>";
				$display .= '<a href="'.SITE_URL.'/classes-view/'.$res['id'].'" class="btn btn-warning" data-placement="top" data-toggle="tooltip" data-original-title="View"><i class="fa fa-edit"></i> View </a>
				<a onclick="javascript:confirmSubmit(\''.$res['id'].'\',\'class\', \'Class with Name - ('.$res['name'].')\');"  class="btn btn-danger" data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i> Delete</a>';
				$display .= "";
				$display .= "</td>";
				$display .= "</tr>";

				print $display;
			}

		} else {
			print "<tr align='left' class='gradeU'><td colspan='3'>Sorry! No data was found.</td><td></td><td></td><td></tr>";
		}

	}
	
	public function getClassById($id,$linked=false) {
		
		$db = new Database;
		
		//check if the id sent is numeric
		if(!is_numeric($id)) {
			//return false if not numeric
			$this->classResult = false;
		} else {
			//if numeric then process by quering the database
			$sql = $db->select("SELECT * FROM `class` WHERE `id`='$id' AND status='1'");
			//count the number of rows
			if($db->scount($sql) == 1) {
				//get the information 
				$this->classResult = true;
				while($res = $sql->fetch_assoc()) {
					$this->classId = $id;
					$this->className  = $res['name'];
					if($linked != false)
						$this->className = "<a href='".SITE_URL."/classes-view/$id'>{$this->className}</a>";
					
					$this->classTeacher = $res['teacher'];
					$this->classNote = $res['note'];
					$this->classFees = $res['fees'];
					$this->classOpt = "<option value='{$res['id']}' selected='selected'>{$res['name']}</option>";
				}
			} else {
				//set an error
				$this->classResult = false;
				$this->className = '';
				$this->classFees = "";
				$this->classTeacher = '0';
				$this->classOpt = "";
			}
		}
		//return the results
		return $this;
	}
	
	public function updateClassTeacher($classId,$teacherId) {
		//create object
		$db = new Database;
		//check if both values parsed are numerics
		if(is_numeric($classId) and is_numeric($teacherId)) {
			//check if the student number do exists in the database
			$db->update("UPDATE `class` SET `employee`='$teacherId' WHERE `id`='$classId' LIMIT 1");
		} else {
			return false;
		}
	}
	
}

?>