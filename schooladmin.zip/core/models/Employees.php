<?php
// determine if the database connection configuration is available
// if not, include the connection information
if(!defined("DB_HOST")) { include '../index.php'; die(); }


/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */

class Employees extends Models {

	public $display_submenu;
	public $data = NULL;

	public function getEmployees($where = null, $limit = null, $order = "ASC") {
		$db = new Database();
		
		if($where != null)
			$add = $where . "";
		else
			$add = '1  AND `status`=\'1\'';
		
		
		$sql = $db->select("SELECT * FROM `employee` WHERE $add ORDER BY `id` $order $limit");
		
		if($db->scount($sql) > 0) {
			while($res = $sql->fetch_assoc()) {
				
				$religion = new Religion;
				$classes = new Classes;
				$design = new Designation;
				
				$this->stuClass = $classes->getClassById($res['class'],'linked')->className;
				
				$display = "<tr align='left' class='gradeU'>";
				$display .= "<td><strong>{$res['id']}</strong></td>";
				$display .= "<td style='text-align:left'>".ucwords($res['fullname'])."</td>";
				$display .= "<td>{$design->getDesignationById($res['designation'])->desigName}</td>";
				$display .= "<td>{$design->getQualificationById($res['qualification'])->quaName}</td>";
				$display .= "<td>{$this->stuClass}</td>";
				$display .= "<td>{$res['phone']}</td>";
				$display .= "<td style='text-align:left'>";
				$display .= '<a href="'.SITE_URL.'/employee-view/'.$res['uniqueid'].'" title="View" class="btn btn-success" data-placement="top" data-toggle="tooltip" data-original-title="View"><i class="fa fa-check-square-o"></i></a>
				<a href="'.SITE_URL.'/employee-edit/'.$res['uniqueid'].'" title="Edit" class="btn btn-warning" data-placement="top" data-toggle="tooltip" data-original-title="Edit"><i class="fa fa-edit"></i></a>
				<a onclick="javascript:confirmSubmit(\''.$res['id'].'\',\'employee\', \'Employee with Name - ('.$res['fullname'].')\');" title="Delete" class="btn btn-danger" data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i> </a>
				<a href="'.SITE_URL.'/salary-settings/'.$res['uniqueid'].'" title="Salary Settings" class="btn btn-warning" data-placement="top" data-toggle="tooltip" data-original-title="Salary Settings"><i class="fa fa-money"></i><i class="fa fa-gear"></i></a>';
				$display .= "";
				$display .= "</td>";
				$display .= "</tr>";

				print $display;
			}

		} else {
			print "<tr align='left' class='gradeU'><td>Sorry! No data was found.</td><td></td><td></td><td></tr>";
		}

	}
	
	public function getEmployeeById($id,$linked=false) {
		
		$db = new Database;
		$religion = new Religion;
		
		//check if the id sent is numeric
		if(!preg_match("/^[a-zA-Z0-9]+$/", $id)) {
			//return false if not numeric
			$this->teacherResult = false;
		} else {
			//clean the id parsed
			$id = $db->cleanData($id);
			//if numeric then process by quering the database
			$sql = $db->select("SELECT * FROM `employee` WHERE (`id`='$id' and status='1') OR (`uniqueid`='$id' and status='1') OR (`phone`='$id' AND `status`='1')");
			//count the number of rows
			if($db->scount($sql) == 1) {
				$religion = new Religion;
				//get the information 
				$this->teacherResult = true;
				while($res = $sql->fetch_assoc()) {
					$this->teacherId = $id;
					$this->teacherID = $res['id'];
					$this->teacherName  = $res['fullname'];
					if($linked != false)
						$this->teacherName = "<a href='".SITE_URL."/employee-view/$id'>{$this->teacherName}</a>";
					
					$design = new Designation;
					$classes = new Classes;
					
					$this->teacherPhone = $res['phone'];
					$this->teacherAddress = $res['address'];
					$this->teacherDesig = $design->getDesignationById($res['designation'])->desigName;
					$this->teacherDesigOpt = $design->getDesignationById($res['designation'])->desigOpt;
					$this->teacherReligion = $religion->getReligionById($res['religion'])->regName;
					$this->teacherDob = date("d M Y", strtotime($res['dob']));
					$this->teacherDobr = $res['dob'];
					$this->teacherGender = $res['gender'];
					$this->teacherGenderOpt = "<option value='{$this->teacherGender}'>{$this->teacherGender}</option>";
					$this->teacherEmail = $res['email'];
					$this->teacherPhoto = $res['photo'];
					$this->teacherReligionOpt = $religion->getReligionById($res['religion'])->regOpt;
					$this->teacherClassOpt = $classes->getClassById($res['class'])->classOpt;
					$this->teacherUID = $res['uniqueid'];
					$this->teacherCert = $res['certificate'];
					$this->teacherSchool = $res['schoolname'];
					$this->teacherExperience = $res['full_qualification'];
					$this->teacherQualification = $design->getQualificationById($res['qualification'])->quaName;
					$this->teacherQualificationOpt = $design->getQualificationById($res['qualification'])->quaOpt;
					$this->teacherUser = $res['username'];
					$this->teacherPass = $res['password'];
					$this->teacherJoin = date("d M Y", strtotime($res['djoin']));
					$this->teacherJobr = $res['djoin'];
				}
			} else {
				//set an error
				$this->teacherResult = false;
				$this->teacherName = 'Not Set';
			}
		}
		//return the results
		return $this;
	
	}
	
	public function updateClassTeacherColumn($classId) {
		
		$db = new Database;
		$this->changeResult = false;
		
		//check if the id sent is numeric
		if(!is_numeric($classId)) {
			//return false if not numeric
			$this->changeResult = false;
		} else {
			//query the database
			$sql = $db->select("SELECT id,class,status FROM `employee` WHERE `class`='$classId' AND `status`='1'");
			//count the number of rows
			if($db->scount($sql) > 0) {
				
				//using the while loop just change the class to 0
				while($res = $sql->fetch_assoc()) {
					//update the rows again
					$db->update("UPDATE `employee` SET `class`='0' WHERE `class`='$classId'");
				}
				$this->changeResult = true;
			} else {
				return false;
			}
		}
		
		return $this;
	}
	
	public function autorunCheck() {
		
		$db = new Database;
		//query the database
		$sql = $db->select("SELECT * FROM `students` WHERE `status`='1'");
		//count the number of rows
		if($db->scount($sql) > 0) {
			//using the while loop
			while($result = $sql->fetch_assoc()) {
				//set variables
				//$class = $
			}
		} else {
			return false;
		}
		
	}
	
	public function fetchSalarySettings() {
		//create more objects
		$db = new Database;
		$design = new Designation;
		$payheads = new Payhead;
		//query the database
		$sql = $db->select("SELECT * FROM `salary_settings` WHERE status='1' ORDER BY `id` ASC");	
		//count
		if($db->scount($sql) > 0) {
			//using the while loop
			while($result = $sql->fetch_assoc()) {
				print "<tr align='left' class='gradeU'>";
				print "<td><strong>{$result['id']}</strong></td>";
				print "<td><strong>{$this->getEmployeeById($result['employeeid'])->teacherName}</strong></td>";
				print "<td><strong>{$design->getDesignationById($result['designation'])->desigName}</strong></td>";
				print "<td><strong>{$payheads->getPayheadById($result['payhead'])->payHeadName}</strong></td>";
				print "<td><strong>{$result['amount']}</strong></td>";
				print "<td><strong>{$result['balance']}</strong></td>";
				print '<td><a href="'.SITE_URL.'/salary-settings-view/'.$result['employeeid'].'" class="btn btn-info" data-placement="top" data-toggle="tooltip" data-original-title="View" title="View"><i class="fa fa-check-square-o"></i></a>
				<a onclick="javascript:confirmSubmit(\''.$result['id'].'\',\'salary_settings\', \'Salary Setting of - ('.$this->getEmployeeById($result['employeeid'])->teacherName.')\');" class="btn btn-danger" data-placement="top" data-toggle="tooltip" data-original-title="View" title="Delete"><i class="fa fa-trash-o"></i></a>';
				print "</td>";
				print "</tr>";
			}
		} else {
			return false;
		}
	}
}
?>
