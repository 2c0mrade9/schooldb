<?php 
// determine if the database connection configuration is available
// if not, include the connection information
if(!defined("DB_HOST")) { include '../index.php'; die(); }

class Religion {
	
	public $regResult = false;
	
	public function getReligionById($id) {
		
		$db = new Database;
		
		//check if the id sent is numeric
		if(!is_numeric($id)) {
			//return false if not numeric
			$this->regResult = false;
		} else {
			//if numeric then process by quering the database
			$sql = $db->select("SELECT * FROM `religion` WHERE `id`='$id'");
			//count the number of rows
			if($db->scount($sql) == 1) {
				//get the information 
				$this->regResult = true;
				while($res = $sql->fetch_assoc()) {
					$this->regId = $id;
					$this->regName  = $res['name'];
					$this->regOpt = "<option value='{$res['id']}' selected='selected'>{$res['name']}</option>";
				}
			} else {
				//set an error
				$this->regResult = false;
				$this->regOpt = '';
				$this->regName = '';
			}
		}
		//return the results
		return $this;
	}
}

?>