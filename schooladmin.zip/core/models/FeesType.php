<?php 
// determine if the database connection configuration is available
// if not, include the connection information
if(!defined("DB_HOST")) { include '../index.php'; die(); }

class FeesType {
	
	public $classResult = false;
	
	public function getFeeTypes($where = null, $limit = null, $order = "DESC") {
		$db = new Database();
		
		if($where != null)
			$add = $where . "";
		else
			$add = "status='1'";
		
		
		$sql = $db->select("SELECT * FROM `finance_feestype` WHERE $add GROUP BY `type` ORDER BY `id` $order $limit");
		
		if($db->scount($sql) > 0) {
			while($result = $sql->fetch_assoc()) {
				
				$display = "<tr align='left' class='gradeU'>";
				$display .= "<td><strong>{$result['id']}</strong></td>";
				$display .= "<td><strong>{$result['type']}</strong></td>";
				$display .= "<td><strong>GHc{$result['amount']}</strong></td>";
				$display .= "<td><strong>{$result['slug']}</strong></td>";
				$display .= '<td>
				<a href="'.SITE_URL.'/fees-type-view/'.$result['id'].'" class="btn btn-info" data-placement="top" data-toggle="tooltip" data-original-title="View" title="View"><i class="fa fa-check-square-o"></i></a>
				<a href="'.SITE_URL.'/fees-type-delete/'.$result['id'].'" onclick="return confirm(\'you are about to delete a record. This cannot be undone. are you sure?\')" class="btn btn-danger" title="Delete" data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i></a>';
				$display .= "</td>";
				$display .= "</tr>";

				print $display;
			}

		} else {
			print "<tr align='left' class='gradeU'><td colspan='4'>Sorry! No data was found.</td></tr>";
		}

	}
	
	public function getFeeTypeById($id,$linked=false) {
		
		$db = new Database;
		
		//check if the id sent is numeric
		if(!is_numeric($id)) {
			//return false if not numeric
			$this->fTypeResult = false;
		} else {
			//if numeric then process by quering the database
			$sql = $db->select("SELECT * FROM `finance_feestype` WHERE `id`='$id'  AND status='1'");
			//count the number of rows
			if($db->scount($sql) == 1) {
				//get the information 
				$this->fTypeResult = true;
				while($res = $sql->fetch_assoc()) {
					$this->feeTpeId = $id;
					$this->feeTypeName  = $res['type'];
					if($linked != false)
						$this->feeTypeName = "<a href='".SITE_URL."/fees-type-view/$id'>{$this->feeTypeName}</a>";
					$this->feeTypeNote = $res['note'];
					$this->feeTypeAmount = $res['amount'];
				}
			} else {
				//set an error
				$this->fTypeResult = false;
				$this->feeTypeName = 'NotSet';
				$this->feeTypeNote = '';
				$this->feeTypeAmount = '0.00';
			}
		}
		//return the results
		return $this;
	}
	
}

?>