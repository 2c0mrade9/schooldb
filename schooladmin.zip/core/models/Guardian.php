<?php
// determine if the database connection configuration is available
// if not, include the connection information
if(!defined("DB_HOST")) { include '../index.php'; die(); }


/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */

class Guardian extends Models {

	public function getGuardians($where = null, $limit = null, $order = "ASC") {
		$db = new Database();
		
		if($where != null)
			$add = $where . "";
		else
			$add = '1';
		
		
		$sql = $db->select("SELECT * FROM `guardian` WHERE $add ORDER BY `id` $order $limit");
		
		if($db->scount($sql) > 0) {
			while($res = $sql->fetch_assoc()) {
				
				$student = new Students;
				
				$this->wardName = $student->getStudentById($res['ward'],'linked')->studentName;
				
				$display = "<tr align='left' class='gradeU'>";
				$display .= "<td><strong>{$res['id']}</strong></td>";
				$display .= "<td style='text-align:left'>".ucwords($res['fullname'])."</td>";
				$display .= "<td>{$res['profession']}</td>";
				$display .= "<td>".$this->listWards($res['id'])->studentName."</td>";
				$display .= "<td>{$res['phone']}</td>";
				$display .= "<td style='text-align:left'>";
				$display .= '<a href="'.SITE_URL.'/guardian-view/'.$res['id'].'" title="Edit Details of '.$res['fullname'].'" class="btn btn-success" data-placement="top" data-toggle="tooltip" data-original-title="View"><i class="fa fa-check-square-o"></i></a>
				<a href="'.SITE_URL.'/guardian-edit/'.$res['id'].'" title="Edit Details of '.$res['fullname'].'" class="btn btn-warning" data-placement="top" data-toggle="tooltip" data-original-title="Edit"><i class="fa fa-edit"></i></a>
				<a onclick="javascript:confirmSubmit(\''.$res['id'].'\',\'guardian\', \'Guardian with Name - ('.$res['fullname'].')\');" title="Delete Details of '.$res['fullname'].'" class="btn btn-danger" data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i> </a>';
				$display .= "";
				$display .= "</td>";
				$display .= "</tr>";

				print $display;
			}

		} else {
			print "<tr align='left' class='gradeU'><td>Sorry! No data was found.</td><td></td><td></td><td></tr>";
		}

	}
	
	public function getGuardianById($id,$linked=false,$studentID='',$diffname='diffname') {
		$db = new Database();
		$student = new Students;
		$religion = new Religion;
		
		if(is_numeric($id)) {
			$sql = $db->select("SELECT * FROM `guardian` WHERE (`id`='$id' AND status='1') OR (`phone`='$id' AND status='1') LIMIT 1");
			$this->guardResult = false;
			
			if($db->scount($sql) > 0) {
				$this->guardResult = true;
				while($res = $sql->fetch_assoc()) {
					
					$this->guardId = $id;
					$this->guardName  = $res['fullname'];
					$this->guardPhone = $res['phone'];
					$this->guardEmail = $res['email'];
					$this->guardHometown = $res['hometown'];
					$this->guardReligionId = $res['religion'];
					$this->guardReligion = $religion->getReligionById($res['religion'])->regName;
					$this->guardReligionOpt = $religion->getReligionById($res['religion'])->regOpt;
					$this->guardResidence = $res['residence'];
					$this->guardOccup = $res['profession'];
					$this->guardAddress = $res['address'];
					if($linked!=false)
						$this->guardName = "<a href='".SITE_URL."/guardian-view/$id'>{$this->guardName}</a>";
					if($linked!=false)
						$this->guardPhone = "<a href='".SITE_URL."/guardian-view/$id'>{$this->guardPhone}</a>";
					$this->guardWard = $student->getStudentById($res['ward'],'linked')->studentName;
						
				}

			} else {
				$this->guardResult = false;
				$this->guardName = '<a href="'.SITE_URL.'/parents-add/'.$studentID.'">Assign Parent</a>';
				$this->guardPhone = '';
				
				if($diffname="diffname")
					$this->guardName = 'Not assigned yet';
			}
		} else {
			$this->guardResult = false;
			$this->guardName = '<a href="'.SITE_URL.'/parents-add/'.$studentID.'">Assign Parent</a>';
			$this->guardPhone = '';
			
			if($diffname="diffname")
				$this->guardName = 'Not assigned yet';
		}
		
		return $this;

	}
	
	//create a function to get all wards of the parent
	public function listWards($guardid,$linked="show") {
			//create new database object
			$db = new Database;
			$classes = new Classes;
				
			$guardid = $db->cleanData($guardid);
			$this->studentName = "";
			//query the students table for the specified parent id
			$sql = $db->select("SELECT * FROM `students` WHERE `parent`='$guardid' AND `status`='1'");
			//check the number of rows found
			if($db->scount($sql) > 0) {
					//using the while loop list the name of the students
				while($res = $sql->fetch_assoc()) {
					//assign the name
					if($linked=="show") {
						$this->stuClass = $classes->getClassById($res['class'],'linked')->className;
					
						$this->studentName .= "<a href='".SITE_URL."/student-view/{$res['studentunq']}'>
							".ucwords($res['surname'])." ".ucwords($res['firstname'])." - (".$this->stuClass.")</a>";
						if($db->scount($sql) > 1)
							$this->studentName .= ",";
					} elseif($linked=="dont") {
						$this->stuClass = $classes->getClassById($res['class'],'')->className;
					
						$this->studentName .= ucwords($res['surname'])." ".ucwords($res['firstname'])." (".$this->stuClass.") <strong><a href='javascript:return false;' onclick='return remove_ward(\"".$res['id']."\");' title='Remove Ward'><i class=\"fa fa-trash-o\"></i></a></strong>";if($db->scount($sql) > 1)$this->studentName .= ", ";
					}
				}
				$this->found = "yes";
			} else {
				$this->found = "no";
				$this->studentName = "";
			}
		
		return $this;
			
	}
	
	//create a function to get all wards of the parent
	public function listWardsNew($guardid,$linked="show") {
			//create new database object
			$db = new Database;
			$student = new Students;
			$classes = new Classes;
				
			$guardid = $db->cleanData($guardid);
			$this->studentName = "";
			//query the students table for the specified parent id
			$sql = $db->select("SELECT * FROM `guardian_add` WHERE `parent`='6422123' GROUP BY ward");
			//check the number of rows found
			if($db->scount($sql) > 0) {
					//using the while loop list the name of the students
				while($res = $sql->fetch_assoc()) {
					//assign the name
					$this->stuClass = $student->getStudentById($res['ward'],'',$res['ward'])->studentClass2;
					$this->studentName .= $student->getStudentById($res['ward'],'',$res['ward'])->studentName." (".$this->stuClass.") <strong><a href='javascript:return true;' onclick='return remove_ward_add(\"".$res['id']."\");' title='Remove Ward'><i class=\"fa fa-trash-o\"></i></a></strong>";if($db->scount($sql) > 1)$this->studentName .= ", ";
				}
				$this->found = "yes";
			} else {
				$this->found = "no";
				$this->studentName = "";
			}
		
		return $this;
			
	}
	
	public function updateWards($session, $pid) {
		//create new database object
		$db = new Database;
		//query the database
		$sql = $db->select("SELECT * FROM guardian_add WHERE parent='".$db->cleanData($session)."'");
		//check the number of rows
		if($db->scount($sql) > 0) {
			//ussng the while looop to fetch the information
			while($result = $sql->fetch_assoc()) {
				//update the students with the id
				$db->update("UPDATE students SET parent='$pid' WHERE id='{$result['ward']}'");
			}
		}
		
	}
}
?>