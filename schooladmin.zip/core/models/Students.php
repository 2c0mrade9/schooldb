<?php
// determine if the database connection configuration is available
// if not, include the connection information
if(!defined("DB_HOST")) { include '../index.php'; die(); }


/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */

class Students extends Models {

	public $display_submenu;
	public $data = NULL;

	public function getStudents($where = null, $limit = null, $order = "ASC") {
		$db = new Database();
		
		if($where != null)
			$add = $where . " AND status='1'";
		else
			$add = "status='1'";
		
		
		$sql = $db->select("SELECT * FROM `students` WHERE $add ORDER BY `id` $order $limit");
		
		if($db->scount($sql) > 0) {
			while($res = $sql->fetch_assoc()) {
				
				$classes = new Classes;
				$guardian = new Guardian;
				
				$this->stuClass = $classes->getClassById($res['class'],'linked')->className;
				$this->stuGuard = '('.$guardian->getGuardianById($res['parent'],'linked',$res['studentunq'])->guardName .'/'.$guardian->getGuardianById($res['parent'],'linked')->guardPhone.')'; 
				
				$display = "<tr align='left' class='gradeU'>";
				$display .= "<td><strong>{$res['id']}</strong></td>";
				$display .= "<td style='text-align:left'>".ucwords($res['surname'])." ".ucwords($res['firstname'])."</td>";
				$display .= "<td>{$this->stuClass}</td>";
				$display .= "<td  style='text-align:left'>{$this->stuGuard}</td>";
				$display .= "<td>{$res['phone']}</td>";
				$display .= "<td style='text-align:left'>";
				$display .= '<a href="'.SITE_URL.'/student-view/'.$res['studentunq'].'" class="btn btn-success" data-placement="top" data-toggle="tooltip" data-original-title="View" title="View"><i class="fa fa-check-square-o"></i></a>
				<a href="'.SITE_URL.'/student-edit/'.$res['studentunq'].'" class="btn btn-warning" data-placement="top" data-toggle="tooltip" data-original-title="Edit" title="Edit"><i class="fa fa-edit"></i></a>
				<a onclick="javascript:confirmSubmit(\''.$res['id'].'\',\'students\', \'Student with Name & ID - ('.$res['surname'].' '.$res['firstname'].' - '.$res['studentunq'].')\');"  title="Delete" class="btn btn-danger" data-placement="top" data-toggle="tooltip" data-original-title="Delete"> <i class="fa fa-trash-o"></i> </a>';
				$display .= "";
				$display .= "</td>";
				$display .= "</tr>";

				print $display;
			}

		} else {
			print "<tr align='left' class='gradeU'><td>Sorry! No data was found.</td><td></td><td></td><td></td><td></td><td></td><td></tr>";
		}

	}

	public function getStudentById($id, $linked=false,$sid="none") {
		//create a new object
		$db = new Database;
		$classes = new Classes;	
		//variables
		$this->studentName = '';
		//check if the id sent is numeric
		if(empty($id)) {
			//return false if not numeric
			$this->stuResult = false;
			$this->studentClass = "";
			
		} else {
			$id = $db->cleanData($id);
			if($sid=="none")
				$field="`studentunq`";
			elseif(is_numeric($sid))
				$field="`id`";
			//if numeric then process by quering the database
			$sql = $db->select("SELECT * FROM `students` WHERE $field='$id' AND `status`='1'");
			//count the number of rows
			if($db->scount($sql) == 1) {
				//get the information 
				$this->stuResult = true;
				$religion = new Religion;
				while($res = $sql->fetch_assoc()) {
					$this->studentId = $id;
					$this->studentSname = ucwords($res['surname']);
					$this->studentFname = ucwords($res['firstname']);
					$this->studentName  = ucwords($res['surname']).' '.ucwords($res['firstname']);
					if($linked != false)
						$this->studentName = "<a href='".SITE_URL."/student-view/$id'>{$this->studentName}</a>";
					$this->studentClass = $classes->getClassById($res['class'],'linked')->className;
					$this->studentClass2 = $classes->getClassById($res['class'],false)->className;
					$this->studentClassR = $res['class'];
					$this->studentGender = $res['gender'];
					$this->studentEmail = $res['email'];
					$this->studentPhone = $res['phone'];
					$this->studentPlace = $res['residence'];
					$this->studentLanguage = $res['language'];
					$this->studentPhoto = $res['photo'];
					$this->studentBalance = $res['balance'];
					$this->studentGuardian = $res['parent'];
					$this->studentAddress = $res['address'];
					$this->studentDob = date("d M Y", strtotime($res['dob']));
					$this->studentDobR = $res['dob'];
					$this->studentReligion = $religion->getReligionById($res['religion'])->regName;
					$this->studentReligionR = $res['religion'];
					$this->studentUser = $res['username'];
				
				}
			} else {
				//set an error
				$this->stuResult = false;
				$this->studentName = '';
				$this->studentClass = "";
				$this->studentEmail = "";
				$this->studentPhone = "";
			}
		}
		//return the results
		return $this;
	
	}
	
	public function updateGuardianInfo($studentId, $parentId) {
		$db = new Database;
		//check if both values parsed are numerics
		if($db->cleanData($studentId) and is_numeric($parentId)) {
			//check if the student number do exists in the database
			if($this->getStudentById($studentId)->stuResult == true) {
				//update the student information
				$update = $db->update("UPDATE `students` SET `parent`='$parentId' WHERE `studentunq`='$studentId' LIMIT 1");
				//check if the update was successful
				if($update)
					return true;
				else
					return false;
			} else {
				//return false meaning this went bad
				return false;
			}
		} else {
			return false;
		}
	}
	
	public function updateStudentsTeacherInfo($classId, $teacherId) {
		$db = new Database;
		$classes = new Classes;
		
		//check if both values parsed are numerics
		if(is_numeric($classId) and is_numeric($teacherId)) {
			//check if the student number do exists in the database
			if($classes->getClassById($classId,false)->classResult == true) {
				//update the class teacherId
				$classes->updateClassTeacher($classId, $teacherId);
				//query the database for all students in that class
				$sql = $db->select("SELECT id,studentunq,class,status FROM `students` WHERE `class`='$classId'");
				//count the number of rows
				if($db->scount($sql) > 0) {
					//using the while loop
					while($result = $sql->fetch_assoc()) {
						//update the students information
						$update = $db->update("UPDATE `students` SET `teacher`='$teacherId' WHERE `class`='$classId'");
					}
				}
			} else {
				//return false meaning this went bad
				return false;
			}
		} else {
			return false;
		}
	}
	
}
?>