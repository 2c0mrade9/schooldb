<?php

/*
 * this class deals with count manager
 *
 */
 
class CountModel extends Models {
	
	public function TableCount($table, $where_clause = null) {
		
		$db = new Database();
		
		$sql = $db->select("SELECT * FROM `{$table}` {$where_clause}");
		
		$this->table_count = $db->scount($sql);
		
		if($this->table_count == 0)
			$this->table_count = 0;
		else
			$this->table_count = $this->table_count;
		
		return $this;
	}
	
}
	