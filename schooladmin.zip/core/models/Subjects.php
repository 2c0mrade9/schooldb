<?php
// determine if the database connection configuration is available
// if not, include the connection information
if(!defined("DB_HOST")) { include '../index.php'; die(); }


/**
 * Create a class for easily accessing the database and making modifications
 * in a object oriented manner
 */

class Subjects {

	public $display_submenu;
	public $data = NULL;

	public function getSubjects($where = null, $limit = null, $order = "ASC") {
		$db = new Database();
		
		if($where != null)
			$add = $where . " AND status='1'";
		else
			$add = "status='1'";
		
		
		$sql = $db->select("SELECT * FROM `subjects` WHERE $add ORDER BY `id` $order $limit");
		
		if($db->scount($sql) > 0) {
			while($res = $sql->fetch_assoc()) {
				
				$classes = new Classes;
				$employees = new Employees;
				
				$this->stuClass = $classes->getClassById($res['class'],false)->className;
				$display = "<tr align='left' class='gradeU'>";
				$display .= "<td><strong>{$res['id']}</strong></td>";
				$display .= "<td style='text-align:left'>{$this->stuClass}</td>";
				$display .= "<td>{$res['name']}</td>";
				$display .= "<td  style='text-align:left'>{$res['code']}</td>";
				$display .= "<td>{$employees->getEmployeeById($res['teacher'])->teacherName}</td>";
				$display .= "<td style='text-align:left'>";
				$display .= '<a href="'.SITE_URL.'/subject-view/'.$res['id'].'" class="btn btn-success" data-placement="top" data-toggle="tooltip" data-original-title="View" title="View"><i class="fa fa-check-square-o"></i></a>
				<a onclick="javascript:confirmSubmit(\''.$res['id'].'\',\'subjects\', \'Subject with Name - ('.$res['name'].' for '.$this->stuClass.')\');" title="Delete" class="btn btn-danger" data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i></a>';
				$display .= "";
				$display .= "</td>";
				$display .= "</tr>";

				print $display;
			}

		} else {
			print "<tr align='left' class='gradeU'><td>Sorry! No data was found.</td><td></td><td></td><td></td><td></td><td></td></tr>";
		}

	}

	public function getSubjectById($id, $linked=false) {
		//create a new object
		$db = new Database;
		$employees = new Employees;
		$classes = new Classes;			
		//check if the id sent is numeric
		if(empty($id) and !is_numeric($id)) {
			//return false if not numeric
			$this->subResult = false;
		} else {
			$id = $db->cleanData($id);
			//if numeric then process by quering the database
			$sql = $db->select("SELECT * FROM `subjects` WHERE `id`='$id'");
			//count the number of rows
			if($db->scount($sql) == 1) {
				//get the information 
				$this->subResult = true;
				$religion = new Religion;
				while($res = $sql->fetch_assoc()) {
					$this->subjectId = $id;
					$this->subjectName = ucwords($res['name']);
					$this->subjectCode = ucwords($res['code']);
					$this->subjectClass = $res['class'];
					$this->subjectClassOpt = "<option value='{$this->subjectClass}' selected='selected'>{$classes->getClassById($this->subjectClass)->className}</option>";
					$this->subjectTeacher = $res['teacher'];
					$this->subjectTeacherOpt = "<option value='{$this->subjectTeacher}' selected='selected'>{$employees->getEmployeeById($this->subjectTeacher)->teacherName}</option>";
				}
			} else {
				//set an error
				$this->subResult = false;
				$this->subjectName = 'NotSet';
			}
		}
		$this->studentName = 'NotSet';
		//return the results
		return $this;
	
	}
	
}
?>