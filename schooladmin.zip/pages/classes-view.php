<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Class - View',$site->getSiteName());
//create a new object of the count model
$db = new Database;
$classes = new Classes;

$msg_log = '';
//update the class information
if(isset($_POST['updateClass'])) {
	$className = $db->cleanData($_POST['classes']);
	$teacherID = $db->cleanData($_POST['teacherID']);
	$note = $db->cleanData($_POST['note']);
	$amount = $db->cleanData($_POST['amount']);
	$classId = $db->cleanData($_POST['classId']);
	//update the information
	$update = $db->update("UPDATE `class` SET `name`='$className',`teacher`='$teacherID',`fees`='$amount',`note`='$note' WHERE `id`='$classId'");
	
	if($update) {
		$msg_log .= "<div class='btn bg-green'>Congrats! Class information was successfully updated.</div><br><br>";
		$db->update("UPDATE `teacher` SET `class`='0' WHERE `class`='$classId'");
		$db->update("UPDATE `teacher` SET `class`='$classId' WHERE `id`='$teacherID'");
		$db->update("UPDATE `students` SET `teacher`='$teacherID' WHERE `class`='$classId'");
	} else {
		$msg_log .= "<div class='btn btn-danger'>Sorry! There was an error updating the class information.</div><br><br>";
	}
}
?>
	
	<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-sitemap"></i> Class</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?php print SITE_URL; ?>/classes/index"> Class</a></li>
            <li class="active">Viewing Class</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            
			
				<?php if(isset($ACTION[1]) and is_numeric($ACTION[1]) and $classes->getClassById($ACTION[1])->classResult==true) { ?>
				<div class="col-sm-6">
				<?php print $msg_log; ?>
				<form class="form-horizontal" role="form" method="post">

                    <div class="form-group">                        <label for="classes" class="col-sm-3 control-label">
                            Class                        </label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" id="classes" value="<?php print $classes->getClassById($ACTION[1])->className; ?>" name="classes" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">
					<label for="teacherID" class="col-sm-3 control-label">
                            Teacher Name</label>
                        <div class="col-sm-8">
                            
                            <select tabindex="-1" required name="teacherID" id="teacherID" class="form-control guargianID select2-offscreen">
							<?php
								if($classes->getClassById($ACTION[1])->classTeacher != 0) {
									$getTeacher = $db->select("SELECT id,fullname FROM `teacher` WHERE `id`='{$classes->getClassById($ACTION[1])->classTeacher}' LIMIT 1");
									if($db->scount($getTeacher) > 0) {
										$result = $getTeacher->fetch_assoc();
										print "<option selected='selected' value='".$result['id']."'>{$result['fullname']}</option>";
									}
								}
							?>
							<option value="0">Select Teacher</option>
							<?php
								$sql2 = $db->select("SELECT id,fullname FROM `employee`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['fullname']}</option>";
									}
								}
								?>
							</select>
							</div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
					<div class="form-group">                        
					<label for="classes" class="col-sm-3					control-label">
                            Fees Payable                        </label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" id="amount" name="amount" value="<?php print $classes->getClassById($ACTION[1])->classFees; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
                    <div class="form-group">                        <label for="note" class="col-sm-3 control-label">
                            Note                        </label>
                        <div class="col-sm-8">
                            <textarea class="form-control" style="resize:none;height:100px;" id="note" name="note"><?php print $classes->getClassById($ACTION[1])->classNote; ?></textarea>
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-8">
							<input type="hidden" name="classId" id="classId" value="<?php print $ACTION[1]; ?>">
                            <input class="btn btn-success" value="Update Class Information" name="updateClass" type="submit">
                        </div>
                    </div>

                </form>
				</div>
				<div class="col-sm-6">
					<div id="getCLassesHistory"></div>
				</div>
				<script>
				$("#classes").focus();
				getAllClasses();
				function getAllClasses() {
					$.ajax({
							type: 'POST',
						url: "<?php print SITE_URL; ?>/z_call_classes",
						data: "getAllClasses&call_all",
						dataType: "html",
						success: function(data) {
						   $('#getCLassesHistory').html(data);
						}
					});
				}
				</script>
				<?php
					} else {
						PageNotFound();
					}
				?>

            
        </div>
    </div>
</div>
 
                    </div>
                </div>
            </section>
        </aside>
      
	  
<?php
//get the page footer to include
template_footer();
?>