<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$models = new Models;
$guardian = new Guardian;
$student = new Students;
require 'core/checkaccess.php';
if(isset($_POST['call_all_wards']) and isset($_POST['pid']) and is_numeric($_POST['pid']) and !isset($_POST['_fetched'])) {
?>
	
	<select name="ward" onchange='return add_ward(this.value);' id="guargianID" class="form-control guargianID">
		<option value="0">Add Ward</option>
		<?php
			$stud = $db->select("SELECT * FROM `students` WHERE `parent`!='{$_POST['pid']}' and `status`='1'");
			while($studres=$stud->fetch_assoc()){
				$studentClass = $student->getStudentById($studres['studentunq'])->studentClass2;
				print "<option value='".$studres['id']."'>{$studres['surname']} {$studres['firstname']} ($studentClass)</option>";
			}
		?>
	</select>
<?php
} elseif(isset($_POST['call_all_wards']) and isset($_POST['_fetched']) and isset($_POST['ppid'])) {
	if(is_numeric($_POST['ppid']) and $_POST['ppid']==5) { 
?>
	
	<select name="ward" onchange='return add_ward(this.value);' id="guargianID" class="form-control guargianID">
		<option value="0">Add Ward</option>
		<?php
			$stud = $db->select("SELECT * FROM `students` WHERE `status`='1'");
			while($studres=$stud->fetch_assoc()){
				$studentClass = $student->getStudentById($studres['studentunq'])->studentClass2;
				$studentParent = $guardian->getGuardianById($studres['studentunq'],false,'','diffname')->guardName;
				print "<option value='".$studres['id']."'>{$studres['surname']} {$studres['firstname']} ($studentParent)</option>";
			}
		?>
	</select>
<?php
	} else {
		//query the database
		$sql = $db->select("SELECT * FROM guardian_add WHERE parent='".$db->cleanData($_POST['ppid'])."'");
		//using the while loop
?>
		
		<select name="ward" onchange='return add_ward(this.value);' id="guargianID" class="form-control guargianID">
		<option value="0">Add Ward</option>
<?php
		if($db->scount($sql) > 0) {
			//query the students table
			$sql2 = $db->select("SELECT s.id as id, s.studentunq as studentunq, s.status, g.id, g.ward, FROM students s, guardian_add g
						WHERE s.id !=g.id and s.status='1'");
			//use the while loop
			while($result2 = $sql2->fetch_assoc()) {
				$studentClass = $student->getStudentById($result2['studentunq'])->studentClass2;
				$studentParent = $guardian->getGuardianById($result2['studentunq'],false,'','diffname')->guardName;
				print "<option value='".$result2['id']."'>{$result2['surname']} {$result2['firstname']} ($studentParent)</option>";
			} 
			
		} elseif($db->scount($sql) < 1) {
			//query the students table
			$sql2 = $db->select("SELECT * FROM students WHERE status='1'");
			//use the while loop
			while($result2 = $sql2->fetch_assoc()) {
				$studentClass = $student->getStudentById($result2['studentunq'])->studentClass2;
				$studentParent = $guardian->getGuardianById($result2['studentunq'],false,'','diffname')->guardName;
				print "<option value='".$result2['id']."'>{$result2['surname']} {$result2['firstname']} ($studentParent)</option>";
			} 
		}
?>
		</select>
<?php
	}
}
?>