<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Employees',$site->getSiteName());
//create a new object of the count model
$employees = new Employees;
?>

		<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
					<div class="box">
						<div class="box-header bg-purple">
							<h3 class="box-title"><i class="fa fa-users"></i> Employees</h3>

						   
							<ol class="breadcrumb">
								<li><a href="<?php print SITE_URL; ?>"><i class="fa fa-laptop"></i> Dashboard</a></li>
								<li class="active">Employees</li>
							</ol>
						</div><!-- /.box-header -->
						<!-- form start -->
						<div class="box-body">
							<div class="row">
								<div class="col-sm-12">

									<h5 class="page-header">
										<a class="btn btn-success" href="<?php print SITE_URL; ?>/employee-add">
											<i class="fa fa-plus"></i> 
											Add an Employee                        </a>
									</h5>
									
						
									
									<div class="col-sm-12">

									<div class="nav-tabs-custom ">
										
										<div class="box-header bg-red">
											<h3 class="box-title">
												All Employees
											</h3>
										</div>
										
										<?PHP
										if(isset($ACTION[1])) {
										?>
										<div class="tab-content">
										<div id="all" class="tab-pane active">
										<div id="hide-table">
											<div id="example1_wrapper" class="dataTables_wrapper form-inline" role="grid">
											<table aria-describedby="example1_info" id="example1" class="table table-striped table-bordered table-hover dataTable no-footer">
												<thead>
												<tr role="row">
													<td>ID</td>
													<td>FULLNAME</td>
													<td>DESIGNATION</td>
													<td>QUALIFICATION</td>
													<td>CLASS</td>
													<td>PHONE</td>
													<td>ACTION</td>
												</tr>
												</thead>

												<tbody aria-relevant="all" aria-live="polite" role="alert">
													<?php print $employees->getEmployees("", "LIMIT 5000", "DESC"); ?>
												</tbody>
											</table>
											</div>
										</div>

										</div>
									</div>
										<?php
										} else {
											PageNotFound();
										}
										?>

									</div> <!-- nav-tabs-custom -->
									</div>
									
								</div>
							</div>
						</div><?php //body div ?>
					</div><?php //box div ?>
				</div><?php //col-sm-12 div ?>
			</div><?php //row div ?>
		</section>
	</aside>
		<script type="text/javascript">
            $(function() {
                $("#example1").dataTable();
                $('#example2').dataTable({
                    "bPaginate": true,
                    "bLengthChange": false,
                    "bFilter": false,
                    "bSort": true,
                    "bInfo": true,
                    "bAutoWidth": false
                });
            });
        </script>
<?php
//get the page footer to include
template_footer();
?>