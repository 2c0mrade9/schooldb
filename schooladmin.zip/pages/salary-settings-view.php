<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Salary Settings - Create',$site->getSiteName());
//create a new object of the count model
$msg_log = '';
$models = new Models;
$salary = new Payhead;
?>
<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-money"></i>Employee Salary Settings</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?php print SITE_URL; ?>/payhead-add/index"> Pay Heads</a></li>
            <li class="active">Add new Payhead</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            <div class="col-sm-4">
				
				<?php if(isset($ACTION[1]) and $db->cleanData($ACTION[1]) and $salary->getSalarySettingsById($db->cleanData($ACTION[1]))->s_found==true) { ?>
				<div id="results"></div>
				<form class="form-horizontal" role="form" action="javascript:updateSalarySettings();" method="post">

                    <div class="form-group">
						<label for="payhead" class="col-sm-4 control-label">
                           Designation
						</label>
                        <div class="col-sm-8">
                           <select tabindex="-1" required="required" name="designID" id="designID" onchange="return showEmployee();" class="form-control guargianID select2-offscreen">
								<option value="0">Select Designation</option>
								<?php print $salary->getSalarySettingsById($db->cleanData($ACTION[1]))->design_opt; ?>
								<?php
								$sql2 = $db->select("SELECT * FROM `designation`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['name']}</option>";
									}
								}
								?>
							</select>
                        </div>
                        <span class="col-sm-3 control-label">
                        </span>
                    </div>
					<div class="form-group" id="employee_name">
						<label for="amount" class="col-sm-4 control-label">
                            Employee
						</label>
                        <div class="col-sm-8">
                            <div id="employee_list"></div>
                        </div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
					 <div class="form-group">
						<label for="payhead" class="col-sm-4 control-label">
                           Payment Type
						</label>
                        <div class="col-sm-8">
                           <select tabindex="-1" required="required" name="payhead" id="payhead" class="form-control guargianID select2-offscreen">
								<option value="0">Select Payment Type</option>
								<?php print $salary->getSalarySettingsById($db->cleanData($ACTION[1]))->payhead_opt; ?>
								<?php
								$sql2 = $db->select("SELECT * FROM `payhead`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['name']}</option>";
									}
								}
								?>
							</select>
                        </div>
                        <span class="col-sm-3 control-label">
                        </span>
                    </div>
					<div class="form-group">
						<label for="amount" class="col-sm-4 control-label">
                            Amount
						</label>
                        <div class="col-sm-8">
                            <input required="required" value="<?php print $salary->getSalarySettingsById($db->cleanData($ACTION[1]))->amount; ?>" class="form-control" style="" id="amount" name="amount">
                        </div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
					<div class="form-group">
						<label for="balance" class="col-sm-4 control-label">
                            Balance
						</label>
                        <div class="col-sm-8">
                            <input value="<?php print $salary->getSalarySettingsById($db->cleanData($ACTION[1]))->balance; ?>" class="form-control" style="" id="balance" name="balance">
                        </div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
					<div class="form-group">
                        <div class="col-sm-offset-4 col-sm-8">
							<input class="btn btn-success" value="Update Salary Setting" name="" type="submit">
                        </div>
                    </div>
				</form>
				<?php } else { ?>
					<h2 class="headline text-info"> 404</h2>
					<div class="error-content">
						<h3><i class="fa fa-warning text-yellow"></i> Oops! Page not found.</h3>
						<p>
							We could not find the page you were looking for.<Br>
							<a href="<?php print SITE_URL; ?>">RETURN TO DASHBOARD</a> or <a href="<?php print SITE_URL; ?>/search">SEARCH</a>
						</p>
					</div><!-- /.error-content -->
				<?php } ?>
            </div>
			<div class="col-sm-8">
				<a class="btn btn-warning" href="<?php print SITE_URL; ?>/salary-settings">
					<i class="fa fa-plus-circle"></i> 
					Add New
				</a><br><hr>
				<div id="loadSalariesView"></div>
			</div>
			<script>
			$("#designID").focus();
			$("#employee_name").hide();
			
			loadSalaries();
			function loadSalaries() {
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_call_salary_settings",
					data: "loadSalaries&call_all",
					dataType: "html",
					success: function(data) {
					   $('#loadSalariesView').html(data);
					}
				});
			}
			<?php if(isset($ACTION[1]) and $db->cleanData($ACTION[1]) and $salary->getSalarySettingsById($db->cleanData($ACTION[1]))->s_found==true) { ?>
			showEmployee();
			function showEmployee() {
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_call_employees",
					data: "empid=<?php print $ACTION[1]; ?>&designID=<?php print $salary->getSalarySettingsById($db->cleanData($ACTION[1]))->design; ?>",
					dataType: "html",
					success: function(results) {
						$("#employee_name").show();
						$('#employee_list').html(results);
					}
				});
			}
			
			function updateSalarySettings() {
				var designID = $("#designID").val();
				var amount = $("#amount").val();
				var employeeID = $("#employeeID").val();
				var payhead = $("#payhead").val();
				var balance = $("#balance").val();
				
				loadSalaries();
				
				if(designID==0) {
					$("#results").html("<div class='btn btn-danger'>Sorry! Please select designation.</div><br><br>");
				} else if(employeeID==0) {
					$("#results").html("<div class='btn btn-danger'>Sorry! Please select employee.</div><br><br>");
				} else if(employeeID=="undefined") {
					$("#results").html("<div class='btn btn-danger'>Sorry! Please select employee.</div><br><br>");
				} else if(payhead==0) {
					$("#results").html("<div class='btn btn-danger'>Sorry! Please select employee pay head.</div><br><br>");
				} else {
					$('#results').html('<div id="loading-bar" style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
					$.ajax({
						type: 'POST',
						url: "<?php print SITE_URL; ?>/z_update_salary_settings",
						data: "update&empid=<?php print $ACTION[1]; ?>&designID="+designID+"&amount="+amount+"&employeeID="+employeeID+"&payhead="+payhead+"&balance="+balance,
						dataType: "html",
						success: function(results) {
							alert("Salary Settings Information was successfully updated");
							location.reload();
						}
					});
				}
			}
			<?php } ?>
			</script>
        </div>
    </div>
</div>
 
                    </div>
                </div>
            </section>
        </aside>
	  
<?php
//get the page footer to include
template_footer();
?>