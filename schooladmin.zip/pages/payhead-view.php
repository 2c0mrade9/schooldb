<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Payhead - Edit',$site->getSiteName());
//create a new object of the count model
$msg_log = '';
$models = new Models;
$payheads = new Payhead;
//update the class information
if(isset($_POST['updatePayhead'])) {
	$payhead = ucwords($db->cleanData($_POST['payhead']));
	$note = ucwords($db->cleanData($_POST['note']));
	$payheadid = ucwords($db->cleanData($_POST['payheadid']));
	$slug = $models->create_slug($payhead);
	//check if all fields are filled
	$check = $db->select("SELECT id FROM `payhead` WHERE `id`='$payheadid'");
	if($db->scount($check) != 1) {
		$msg_log .= "<div class='btn btn-danger'>Sorry! The payhead id supplied does not exist in the database.</div><br><br>";
	} else {
		$update = $db->update("UPDATE `payhead` SET `name`='$payhead',`slug`='$slug',`description`='$note' WHERE `id`='$payheadid' LIMIT 1");
		
		if($update) {
			$msg_log .= "<div class='btn bg-green'>Congrats! Pay Head was successfully updated.</div><br><br>";
		} else {
			$msg_log .= "<div class='btn btn-danger'>Sorry! There was an error updating the Payhead.</div><br><br>";
		}
		$payhead = "";	
	}
}
?>
<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-money"></i>Employee Payhead</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?php print SITE_URL; ?>/payhead-add/index"> Pay Heads</a></li>
            <li class="active">Add new Payhead</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            <div class="col-sm-5">
				<?php if(isset($ACTION[1]) and is_numeric($ACTION[1]) and $payheads->getPayheadById($ACTION[1])->payHeadResult==true) { ?>
				
				<?php print $msg_log; ?>
				<form class="form-horizontal" role="form" method="post">

                    <div class="form-group">
						<label for="payhead" class="col-sm-4 control-label">
                            Employee Pay Type/Head
						</label>
                        <div class="col-sm-8">
                            <input required="required" value="<?php print $payheads->getPayheadById($ACTION[1])->payHeadName; ?>" class="form-control" id="payhead" name="payhead" type="text">
                        </div>
                        <span class="col-sm-3 control-label">
                        </span>
                    </div>
					<div class="form-group"> 
					<label for="note" class="col-sm-4 control-label">
                            Description                        </label>
                        <div class="col-sm-8">
                            <textarea class="form-control" style="resize:none;height:100px;" id="note" name="note"><?php print $payheads->getPayheadById($ACTION[1])->payHeadNote; ?></textarea>
                        </div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
					<div class="form-group">
                        <div class="col-sm-offset-4 col-sm-8">
							<input type="hidden" name="payheadid" id="payheadid" value="<?php print $ACTION[1]; ?>">
							<input class="btn btn-success" value="Update PayHead" name="updatePayhead" type="submit">
                        </div>
                    </div>
				</form>
				<?php
					} else {
						PageNotFound();
					}
				?>
            </div>
			<div class="col-sm-7">
				<h5 class="page-header">
					<a class="btn bg-yellow" href="<?php print SITE_URL; ?>/payhead-add">
					<i class="fa fa-edit"></i> 
					Insert New Payhead
					</a>
				</h5>
				<div id="payheadview"></div>
			</div>
			<script>
			$("#payhead").focus();
			
			payhead();
			function payhead() {
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_call_payhead",
					data: "payhead&call_all",
					dataType: "html",
					success: function(data) {
					   $('#payheadview').html(data);
					}
				});
			}
			</script>
        </div>
    </div>
</div>
 
                    </div>
                </div>
            </section>
        </aside>
	  
<?php
//get the page footer to include
template_footer();
?>