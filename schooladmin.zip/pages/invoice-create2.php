<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Invoice - Add',$site->getSiteName());
//create a new object of the count model
$db = new Database;
$classes = new Classes;
$feetype = new FeesType;
$student = new Students;

//initialization
$feeTypeId = "0";
$studentID = "0";
$classesID = "0";
$term = "0";
		
if(isset($_POST['amount']) and isset($_POST['classesID'])) {
	$amount = (int)$db->cleanData($_POST['amount']);
	$feeTypeId = $feetype->getFeeTypeById($db->cleanData($_POST['feeTypeId']))->feeTypeName;
	if($feeTypeId != "NotSet" || $_POST['studentID']!="NotSet" || $studentID != "0") {
		$studentID = $student->getStudentById($db->cleanData($_POST['studentID']))->studentName;
		$email = $student->getStudentById($db->cleanData($_POST['studentID']))->studentEmail;
		$phone = $student->getStudentById($db->cleanData($_POST['studentID']))->studentPhone;
	}
	$classesID = $classes->getClassById($db->cleanData($_POST['classesID']))->className;
	$classid = $db->cleanData($_POST['classesID']);
	$date = $db->cleanData($_POST['date']);
	$academicYear = $db->cleanData($_POST['academicYear']);
	$term = $db->cleanData($_POST['term']);
	if($feeTypeId == "NotSet" || $studentID == "0" || $studentID == "NotSet" || $classesID == "NotSet" || $term == "0") {
		print "<script>alert('Sorry! All fields are required');</script>";
	} elseif($amount < 1) {
		print "<script>alert('Sorry! Enter a valid Amount');</script>";
	} else {
		//insert into the database
		$admin = $_SESSION['Username'];
		$balance = $student->getStudentById($db->cleanData($_POST['studentID']))->studentBalance;
		$newbalance = $balance-$amount;
		if($amount > $balance) {
			$amount=(int)$balance;
			$newbalance = $balance-$amount;
		}
		
		$unqid = 'INV'.rand(0, 9999999);
		$insert = $db->insert("INSERT INTO `payments` (unqid,feetypeid,feetype,studentid,studentunq,studentemail,studentphone,class,classid,amount,academicyear,term,date,rdate,rname) VALUES
			('$unqid','".$db->cleanData($_POST['feeTypeId'])."','$feeTypeId','$studentID','".$db->cleanData($_POST['studentID'])."','$email','$phone','$classesID','$classid','$amount','$academicYear','$term','$date',now(),'$admin')
		");
		$feeTypeId = "NotSet";
		$studentID = "NotSet";
		$classesID = "NotSet";
		$term = 0;
		//redirect
		if($insert) {
			$db->update("UPDATE students set balance='$newbalance' where studentunq='".$db->cleanData($_POST['studentID'])."'");
			print '<script>window.location.href="'.SITE_URL.'/invoice-view/'.$unqid.'"</script>';
		}
	}
}
?>

	 <aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header active bg-purple">
        <h3 class="box-title"><i class="fa icon-invoice"></i> Invoice</h3>

       
        <ol style="display: block;" class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?php print SITE_URL; ?>/invoice/index">Invoice</a></li>
            <li class="active">Add Invoice</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            <div class="col-sm-5" style="border:solid #000000 0px">
                <form class="form-horizontal" role="form" method="post">
					<div class="form-group">
						<label for="classesID" class="col-sm-4 control-label">
                            Academic Year 
						</label>
                        <div class="col-sm-8">

                            <select tabindex="-1" required="required" onchange="return clearHistory();" name="academicYear" id="academicYear" class="form-control guargianID select2-offscreen">
								<option selected="selected" value="<?php print AC_YEAR; ?>"><?PHP PRINT AC_YEAR; ?></option>
								<option value="<?php print AC_YEAR; ?>">-----------------------------------------------</option>
								<?php
								$currentYear = date("Y")-3;
								for($i = 0; $i < 5; $i++) {
									$currentYear++;
									$previousYear = $currentYear - 1;
									if(($previousYear."/".$currentYear) == ''.(date("Y")).'/'.(date("Y")+1).'')
										print "<option value='".($previousYear)."/".($currentYear)."'>".($previousYear)."/".($currentYear)."</option>";
									else
										print "<option value='".($previousYear)."/".($currentYear)."'>".($previousYear)."/".($currentYear)."</option>";
								}
								?>
							</select>
							</div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
					<div class="form-group">
						<label for="classesID" class="col-sm-3 control-label">
							Term
						</label>
                        <div class="col-sm-8">

                            <select tabindex="-1" required="required" onchange="clearHistory(); warningBox();" name="term" id="term" class="form-control guargianID select2-offscreen">
								<option value="<?PHP PRINT AC_TERM; ?>">Term <?PHP PRINT AC_TERM; ?></option>
								<option value="1">Term One</option>
								<option value="2">Term Two</option>
								<option value="3">Term Three</option>
								<option value="4">Term Four</option>
							</select>
							</div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
                    <div class="form-group">                        <label for="classesID" class="col-sm-3 control-label">
                            Class                        </label>
                        <div class="col-sm-8">

                            <select tabindex="-1" required="required" onchange="return clearHistory();" name="classesID" id="classesID" class="form-control guargianID select2-offscreen">
								<option value="0">Select Class</option>
								<?php
								$sql2 = $db->select("SELECT * FROM `class`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['name']}</option>";
									}
								}
								?>
							</select>
							</div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">
						<label for="studentID" class="col-sm-3 control-label">
                            Student
						</label>
                        <div class="col-sm-8">
							<div id="edited_students">
                            <select tabindex="-1" required onchange="return clearHistory();" name="studentID" id="studentID" class="form-control guargianID select2-offscreen">
								<option value="0">Select Student</option>
							</select>
							</div>
						</div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">
						<label for="feetype" class="col-sm-3 control-label">
                            Fee Type
						</label>
                        <div class="col-sm-8">
                            <select tabindex="-1" required name="feeTypeId" onchange="return getHistory();" id="feeTypeId" class="form-control guargianID select2-offscreen">
								<option value="0">Select Fees Type</option>
								<?php
								$sql3 = $db->select("SELECT * FROM `finance_feestype`");
								if($db->scount($sql3) >0) {
									while($res3=$sql3->fetch_assoc()){
										print "<option value='".$res3['id']."'>{$res3['type']}</option>";
									}
								}
								?>
							</select>
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">                        <label for="amount" class="col-sm-3 control-label">
                            Amount                        </label>
                        <div class="col-sm-8">
                            <input class="form-control" onkeyup="getHistory(); getBalance();" required="required" id="amount" name="amount" type="number">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">                        <label for="date" class="col-sm-3 control-label">
                            Date                        </label>
                        <div class="col-sm-8">
                            <input value="<?php print date("Y-m-d"); ?>"required="required" class="form-control" id="date" name="date" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-8">
                            <input id="submitButton" class="btn btn-success" value="Create Invoice" type="submit">
                        </div>
                    </div>

                </form>
            </div>
			<div class="col-sm-7">
				<div id="feeTypeHistory"></div>
				<div id="feeTypeBalance"></div>
			</div>
        </div>
    </div>
		</div>

		<script type="text/javascript">
		$("#submitButton").attr("disabled","disabled");
		fsubmitButton();
		function fsubmitButton() {
			var ca=$('#classesID').val();
			var sa=$('#studentID').val();
			var ta=$("#term").val();
			var am=$("#amount").val();
			
			if(ca==0 || sa==0 || am.length < 1) {
				$("#submitButton").attr("disabled","disabled");
			} else {
				$("#submitButton").removeAttr("disabled");
			}
		
		}
		$('#classesID').change(function(event) {
			submitButton();
			var classesID = $(this).val();
			$('#studentID').val('');
			if(classesID === '0') {
				$('#studentID').val(0);
			} else {
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_call_all_student",
					data: "classesID=" + classesID,
					dataType: "html",
					success: function(data) {
					   $('#studentID').html(data);
					}
				});
			}
		});
		
		function getHistory() {
			
			var feeTypeId = $("#feeTypeId").val();
			var studentID = $("#studentID").val();
			var term = $("#term").val();
			var classesID = $("#classesID").val();
			var academicYear = $("#academicYear").val();
			if(classesID == '0') {
				alert("Please Select Class");
				$("#classesID").focus();
			} else
			if(studentID == '0') {
				alert("Please Select Student");
				$("#studentID").focus();
			} else
			if(studentID != '0' && feeTypeId != "0") {
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_student_payment_history",
					data: "classID="+classesID+"&feeTypeId=" + feeTypeId + "&studentID=" + studentID + "&term=" + term + "&academicYear=" +academicYear,
					dataType: "html",
					success: function(data) {
					   $('#feeTypeHistory').html(data);
					   //GET THE BALANCE OF THE STUDENT
					   getBalance(feeTypeId,studentID,term,classID,academicYear);
					}
				});
			}
			
		}
		
		function getBalance() {
			getHistory();
			var feeTypeId = $("#feeTypeId").val();
			var studentID = $("#studentID").val();
			var term = $("#term").val();
			var amount = $("#amount").val();
			var classesID = $("#classesID").val();
			var academicYear = $("#academicYear").val();
			if(classesID == '0') {
				alert("Please Select Class");
				$("#classesID").focus();
			} else
			if(studentID == '0') {
				alert("Please Select Student");
				$("#studentID").focus();
			} else
			if(studentID != '0' && feeTypeId != "0") {
			$.ajax({
				type: 'POST',
				url: "<?php print SITE_URL; ?>/z_student_payment_history",
				data: "onlyBalance&amount="+amount+"&classID="+classesID+"&feeTypeId=" + feeTypeId + "&studentID=" + studentID + "&term=" + term + "&academicYear=" +academicYear,
				dataType: "html",
				success: function(data) {
				   $('#feeTypeBalance').html(data);
				}
			});
			}
		}
		
		function clearHistory() {
			$('#feeTypeHistory').html('');
		}
		
		function warningBox() {
			var term = $('#term').val();
			var current_term = <?php print AC_TERM; ?>;
			if(current_term != term) {
				if(confirm("You have chosen a Term which is different from the current Academic Term in the System. In order to continue with this process, you need to change the System Academic Year / Term. If not you will be denied to make an entry that is different from this Academic Term. Thank you.")) {
					window.location.href='<?php print SITE_URL; ?>/settings';
				}
			}
		}
		
		$('#date').datepicker();
		</script> 
                    </div>
                </div>
            </section>
        </aside>
<?php
//get the page footer to include
template_footer();
?>