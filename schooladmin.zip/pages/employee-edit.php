<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Employee - Add',$site->getSiteName());
//create a new object of the count model
$employees = new Employees;
$student = new Students;
$db = new Database;
$qualifi = new Designation;

//process the form
$error_msg = '';
if(isset($_POST['addTeacher'])) {
	//set variables and clean the data
	$name = $db->cleanData($_POST['name']);
	$phone = $db->cleanData($_POST['phone']);
	$email = $db->cleanData($_POST['email']);
	$address = $db->cleanData($_POST['address']);
	$experience = $db->cleanData($_POST['experience']);
	$certobtained = $db->cleanData($_POST['certobtained']);
	$qualification = $db->cleanData($_POST['qualification']);
	if($qualification !=0)
		$qualif = "<option value='{$qualification}'>{$qualifi->getQualificationById($qualification)->quaName}</option>";
	$jod = $db->cleanData($_POST['jod']);
	$class = $db->cleanData($_POST['class']);
	$designation = $db->cleanData($_POST['designation']);
	$dob = $db->cleanData($_POST['dob']);
	$username = $db->cleanData($_POST['username']);
	$religion = $db->cleanData($_POST['religion']);
	$gender = $db->cleanData($_POST['gender']);
	$schoolname = $db->cleanData($_POST['schoolname']);
	//continue with the processing of the data
	//check if the parent already exists in the database using the phone number
	$checkP = $db->select("SELECT phone FROM `employee` WHERE phone='$phone'");
	//generate unique id
	$uniqueid = $ACTION[1];
	//insert the guardian information
	$update = $db->update("UPDATE `employee` SET class='$class',fullname='$name',designation='$designation',dob='$dob',gender='$gender',
						religion='$religion',email='$email',phone='$phone',address='$address',djoin='$jod',qualification='$qualification',
						certificate='$certobtained',schoolname='$schoolname',full_qualification='$experience',username='$username'
						WHERE uniqueid='$uniqueid' LIMIT 1
					") or trigger_error($db->db_error());
	if($update) {
		//update the ward information
		if($class != 0){
			//clear the class section of any teacher there
			//	$employees->updateClassTeacherColumn($class);
			//class the students class and perform some update
			$student->updateStudentsTeacherInfo($class,$employees->getEmployeeById($ACTION[1])->teacherID);
		}
		//display success message
		$error_msg .= "<div class='btn bg-green'>Congrats! Employee information was successfully updated.</div><br><br>";
		$error_msg .= "<script>alert('Congrats! Employee information was successfully updated.');window.location.href='';</script>";
		$phone = '';
		$email = '';
		$name = '';
		$class = $employees->getEmployeeById($ACTION[1])->teacherClassOpt;
		$schoolname = '';
		$designation = $employees->getEmployeeById($ACTION[1])->teacherDesigOpt;
		$certobtained = '';
		$experience = '';
		$dob = '';
		$jod = '';
		$qualif = $employees->getEmployeeById($ACTION[1])->teacherQualificationOpt;
		$username = '';
		$address = '';
		$qualification = '';
		$religion = $employees->getEmployeeById($ACTION[1])->teacherReligionOpt;
		$gender = $employees->getEmployeeById($ACTION[1])->teacherGenderOpt;
	} else {
		$error_msg .= "<div class='btn btn-danger'>Sorry! There was an error updating employee information.</div><br><br>";
	}
} elseif(isset($ACTION[1]) and $employees->getEmployeeById($ACTION[1])->teacherResult == true) {
	$phone = $employees->getEmployeeById($ACTION[1])->teacherPhone;
	$email = $employees->getEmployeeById($ACTION[1])->teacherEmail;
	$name = $employees->getEmployeeById($ACTION[1])->teacherName;
	$class = $employees->getEmployeeById($ACTION[1])->teacherClassOpt;
	$designation = $employees->getEmployeeById($ACTION[1])->teacherDesigOpt;
	$experience = $employees->getEmployeeById($ACTION[1])->teacherExperience;
	$qualification = $employees->getEmployeeById($ACTION[1])->teacherQualification;
	$qualif = $employees->getEmployeeById($ACTION[1])->teacherQualificationOpt;
	$dob = $employees->getEmployeeById($ACTION[1])->teacherDobr;
	$schoolname = $employees->getEmployeeById($ACTION[1])->teacherSchool;
	$certobtained = $employees->getEmployeeById($ACTION[1])->teacherCert;
	$jod = $employees->getEmployeeById($ACTION[1])->teacherJobr;
	$username = $employees->getEmployeeById($ACTION[1])->teacherUser;
	$address = $employees->getEmployeeById($ACTION[1])->teacherAddress;
	$religion = $employees->getEmployeeById($ACTION[1])->teacherReligionOpt;
	$gender = $employees->getEmployeeById($ACTION[1])->teacherGenderOpt;
}
?>

	<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-user"></i> Update Employee Detail</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?php print SITE_URL; ?>/employee/index">Employees</a></li>
            <li class="active">Add Employee</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
			
			<?php if(isset($ACTION[1]) and $employees->getEmployeeById($ACTION[1])->teacherResult==true) { ?>
			
				<?php print $error_msg; ?>
                <form class="form-horizontal" role="form" method="post" enctype="multipart/form-data">
					<div class="col-sm-6">
                    <div class="form-group">
					<label for="name_id" class="col-sm-4 control-label">
                            Fullname                        </label>
                        <div class="col-sm-8">
                            <input class="form-control" required="required" id="name_id" value="<?php print $name; ?>" name="name" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    

                    

                    <div class="form-group">
						<label for="sex" class="col-sm-4 control-label">
                            Gender
						</label>
                        <div class="col-sm-8">
                            <select name="gender" required="required" id="sex" value="<?php print $gender; ?>" class="form-control">
							<?php print $gender; ?>
							<option selected="selected" value="Male">Male</option>
							<option value="Female">Female</option>
							</select>
						</div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
					<div class="form-group">                        <label for="phone" class="col-sm-4 control-label">
                            Phone                        </label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" value="<?php print $phone; ?>" id="phone" name="phone" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
					<div class="form-group">                        <label for="email" class="col-sm-4 control-label">
                            Email                        </label>
                        <div class="col-sm-8">
                            <input class="form-control" id="email" value="<?php print $email; ?>" name="email" type="email">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
					<div class="form-group">
						<label for="dob" class="col-sm-4 control-label">
                            Date of Birth 
						</label>
                        <div class="col-sm-8">
                            <input class="form-control" id="datebirth" name="dob" value="<?php print $dob; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                        </span>
                    </div>
					<div class="form-group">                        <label for="religion" class="col-sm-4 control-label">
                            Class                        </label>
                        <div class="col-sm-8">
                            <select tabindex="-1" name="class" id="class" class="form-control guargianID select2-offscreen">
								
							<option value="0">Select Class</option>
							<?php print $class; ?>
							<?php
								$sql3 = $db->select("SELECT * FROM `class`");
								if($db->scount($sql3) >0) {
									while($res3=$sql3->fetch_assoc()){
										print "<option value='".$res3['id']."'>{$res3['name']}</option>";
									}
								}
								?>
							</select>
						</div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
                    
					<div class="form-group">                        <label for="designation" class="col-sm-4 control-label">
                            Designation                        </label>
                        <div class="col-sm-5">
							<div id="designation_reload">
							<select tabindex="-1" required name="designation" id="designation" class="form-control guargianID select2-offscreen">
								
							<option value="0">Select Designation</option>
							<?php print $designation; ?>
							<?php
								$sql2 = $db->select("SELECT * FROM `designation`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['name']}</option>";
									}
								}
								?>
							</select>
							</div>
						</div>
						<li style="cursor:pointer;" data-placement="top" data-toggle="tooltip" data-original-title="View" title="Add New Designation" class="fa fa-plus fa-2x" onclick="openNewWindow('add-new','designation');"></li>
						<li style="cursor:pointer;" data-placement="top" data-toggle="tooltip" data-original-title="View" title="Reload Designations" class="fa fa-refresh fa-2x" onclick="reloadDiv('designation_reload','designation');"></li>
                        <span class="col-sm-4 control-label"></span>
                    </div>
                    

                    <div class="form-group">                        <label for="address" class="col-sm-4 control-label">
                            Address                        </label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" value="<?php print $address; ?>" id="address" name="address" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
					<hr>
                    <div class="form-group">                        <label for="username" class="col-sm-4 control-label">
                            Username                        </label>
                        <div class="col-sm-8">
                            <input class="form-control" autocomplete="off" value="<?php print $username; ?>" id="username" name="username" type="text">
                        </div>
                         <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">                        <label for="password" class="col-sm-4 control-label">
                            Password                        </label>
                        <div class="col-sm-8">
                            <input class="form-control" autocomplete="off" id="password" name="password" value="" type="password">
                        </div>
                         <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    
				
				</div><!-- /col-sm-8 -->
				
				<div class="col-sm-6">
					
					
					<div class="form-group">                        <label for="religion" class="col-sm-3 control-label">
                            Religion                        </label>
                        <div class="col-sm-5">
							<div id="religion_reload">
                            <select tabindex="-1" required name="religion" id="religion" class="form-control guargianID select2-offscreen">
								
							<option value="0">Select Religion</option>
							<?php print $religion; ?>
							<?php
								$sql2 = $db->select("SELECT * FROM `religion`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['name']}</option>";
									}
								}
								?>
							</select>
							</div>
						</div>
						<li style="cursor:pointer;" data-placement="top" data-toggle="tooltip" data-original-title="View" title="Add New Religion" class="fa fa-plus fa-2x" onclick="openNewWindow('add-new','religion');"></li>
						<li style="cursor:pointer;" data-placement="top" data-toggle="tooltip" data-original-title="View" title="Reload Religions" class="fa fa-refresh fa-2x" onclick="reloadDiv('religion_reload','religion');"></li>
                        
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
					
			<div class="form-group">                        <label for="jod" class="col-sm-3 control-label">
                            Joining Date                        </label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" id="jod" value="<?php print $jod; ?>" name="jod" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
					<div class="form-group">                        <label for="designation" class="col-sm-3 control-label">
                            Qualification                        </label>
                        <div class="col-sm-5">
				<div id="qualification_reload">
				<select tabindex="-1" required name="qualification" id="qualification" class="form-control guargianID select2-offscreen">
							
				<option value="0">Select Qualification</option>
				<?php print $qualif; ?>
					<?php
					$sql2 = $db->select("SELECT * FROM `qualification`");
					if($db->scount($sql2) >0) {
						while($res2=$sql2->fetch_assoc()){
							print "<option value='".$res2['id']."'>{$res2['name']}</option>";
						}
					}
					?>
				</select>
				</div>
			</div>
			<li style="cursor:pointer;" data-placement="top" data-toggle="tooltip" data-original-title="View" title="Add New Qualification" class="fa fa-plus fa-2x" onclick="openNewWindow('add-new','qualification');"></li>
			<li style="cursor:pointer;" data-placement="top" data-toggle="tooltip" data-original-title="View" title="Reload Qualifications" class="fa fa-refresh fa-2x" onclick="reloadDiv('qualification_reload','qualification');"></li>
                        
                        <span class="col-sm-4 control-label"></span>
                    </div>
			<div class="form-group">                        <label for="certobtained" class="col-sm-3 control-label">
                           Certification Obtained                        </label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" id="certobtained" value="<?php print $certobtained; ?>" name="certobtained" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
			<div class="form-group">
			<label for="schoolname" class="col-sm-3 control-label">
				Last School Attended
                          </label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" id="schoolname" value="<?php print $schoolname; ?>" name="schoolname" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
			
			<div class="form-group">                        <label for="experience" class="col-sm-3 control-label">
                            Experience                        </label>
                        <div class="col-sm-8">
                            <textarea class="form-control" style="resize:none;height:100px;" id="experience" name="experience"><?php print $experience; ?></textarea>
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
				</div>
					<div class="form-group">
                        <div class="col-sm-offset-6 col-sm-12">
                            <input class="btn btn-success" value="Update Employee Details" name="addTeacher" type="submit">
                        </div>
                    </div>
                </form>

            
						</div>
			

					<script type="text/javascript">
					$('#datebirth').datepicker({ startView: 2 });
					$('#jod').datepicker();
					function openNewWindow(page,type) {
						alert("Please after inserting "+type+" click on the refresh to load new "+type+".");
						window.open("<?php print SITE_URL; ?>/"+page+"?type="+type,"width=500px","height=300px");
					}
					function reloadDiv(div,item) {
						$.ajax({
							type: 'POST',
							url: "<?php print SITE_URL; ?>/z_call_refresh",
							data: "div="+div+"&item="+item,
							dataType: "html",
							success: function(results) {
							   $("#"+div+"").html(results);
							}
						});
					}
					</script>
					
					<?php
						} else {
							PageNotFound();
						}
					?>
                </div>
				</div>
				</div>
				</div>
            </section>
        </aside>
                 
				 
<?php	
//get the page footer to include
template_footer();
?>
