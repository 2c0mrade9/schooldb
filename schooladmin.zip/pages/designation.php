<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Designation - Add',$site->getSiteName());
//create a new object of the count model
$msg_log = '';
$models = new Models;
//update the class information
if(isset($_POST['insertDesignation'])) {
	$designation = ucwords($db->cleanData($_POST['designation']));
	$slug = $models->create_slug($designation);
	//check if all fields are filled
	$check = $db->select("SELECT slug FROM `designation` WHERE `slug`='$slug'");
	if($db->scount($check) > 0) {
		$msg_log .= "<div class='btn btn-danger'>Sorry! A similar Designation already exists in the database.</div><br><br>";
	} else {
		$insert = $db->insert("INSERT INTO `designation` (name,slug) VALUES (
			'$designation','$slug'
		)");
		
		if($insert) {
			$msg_log .= "<div class='btn bg-green'>Congrats! Designation was successfully inserted.</div><br><br>";
		} else {
			$msg_log .= "<div class='btn btn-danger'>Sorry! There was an error inserting the Designation.</div><br><br>";
		}
		$typeName = "";
		$classesID = 0;
		$amount = "";
		$note = "";
		
	}
}
?>
<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-money"></i> Designation</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?php print SITE_URL; ?>/designation/index"> Designations</a></li>
            <li class="active">Add new Designation</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            <div class="col-sm-6">
			
				<?php print $msg_log; ?>
				<form class="form-horizontal" role="form" method="post">

                    <div class="form-group">
						<label for="designation" class="col-sm-3 control-label">
                            Designation
						</label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" id="designation" name="designation" type="text">
                        </div>
                        <span class="col-sm-3 control-label">
                        </span>
                    </div>
					<div class="form-group">
                        <div class="col-sm-offset-3 col-sm-8">
							<input class="btn btn-success" value="Insert Designation" name="insertDesignation" type="submit">
                        </div>
                    </div>
				</form>
            </div>
			<div class="col-sm-6">
				<div id="designationHistory"></div>
			</div>
			<script>
			$("#designation").focus();
			
			designationHistory();
			function designationHistory() {
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_call_designation",
					data: "designationHistory&call_all",
					dataType: "html",
					success: function(data) {
					   $('#designationHistory').html(data);
					}
				});
			}
			</script>
        </div>
    </div>
</div>
 
                    </div>
                </div>
            </section>
        </aside>
	  
<?php
//get the page footer to include
template_footer();
?>