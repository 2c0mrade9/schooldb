<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
require 'core/checkaccess.php';
$db=new Database;
if(isset($_POST['classId']) and isset($_POST['className'])) {
	$classesID = $db->cleanData($_POST['classId']);
	//query the database
	$sql2 = $db->select("SELECT * FROM `class` WHERE `id`='$classesID'");
	if($db->scount($sql2) >0) {
		while($res2=$sql2->fetch_assoc()){
			print strtolower(str_replace(" ","",$res2['name'])).".";
		}
	} else if($classesID == "all_classes") {
		print strtolower("ac").".";
	} else if($classesID == "all_jhs") {
		print strtolower("aj").".";
	} else if($classesID == "all_primary") {
		print strtolower("ap").".";
	} else if($classesID == "all_lower_primary") {
		print strtolower("al").".";
	} else if($classesID == "all_upper_primary") {
		print strtolower("au").".";
	}

} elseif(isset($_POST['subject_code']) and isset($_POST['subject']) and isset($_POST['completeCode'])) {
	$subject_code = $db->cleanData($_POST['subject_code']);
	$subject = $db->cleanData($_POST['subject']);
	//query the database
	$first = strtolower(str_replace(" ","",$subject_code));
	$second = substr(strtolower(str_replace(" ","",$subject)), 0, 50);
	//print name
	print ($first.''.$second).".".date("Y");
}
?>