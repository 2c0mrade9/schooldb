<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
//include the checkaccess file
include_once "core/checkaccess.php";
//delete file
$username = $_SESSION['Username'];

if(isset($_POST['pid']) and isset($_POST['table'])) {
	$id= $db->cleanData($_POST['pid']);
	$item= stripslashes($_POST['item_p']);
	$tablename= strtolower($db->cleanData($_POST['table']));
	$time = date("d-m-Y H:i:s");
	
	if($tablename=="joe_article_cat") {
		$db->update("UPDATE $tablename SET status='0' WHERE id=$id");
		$db->update("UPDATE joe_articles set status='0' WHERE CategoryID=$id");
	} elseif($tablename=="joe_pages") {
		$db->update("UPDATE $tablename SET PageStatus='0' WHERE id=$id");
		$db->update("UPDATE joe_pages SET PageStatus='0' WHERE ParentID=$id");
	} elseif($tablename=="joe_product_cat") {
		$db->update("UPDATE $tablename SET status='0' WHERE id=$id");
		$db->update("UPDATE joe_product SET status='0' WHERE category=$id");
	} else {
		$db->update("UPDATE $tablename SET status='0' WHERE id=$id");
	}
	$db->insert("INSERT INTO `delete_history` (delby,content,date) values('$username','Deleted $item',now())");
}
if(isset($_POST['table']) && isset($_POST['checklist'])) {
	$data= $db->cleanData($_POST['checklist']);
	$tablename= $db->cleanData($_POST['table']);
	$time = date("d-m-Y H:i:s");
	
	for($i=0;$i<count($data);$i++){
		if($tablename=="joe_article_cat") {
			$db->update("UPDATE $tablename SET status='0' WHERE id=$data[$i]");
			$db->update("UPDATE joe_articles set status='0' WHERE CategoryID=$data[$i]");
		} elseif($tablename=="joe_pages") {
			$db->update("UPDATE $tablename SET PageStatus='0' WHERE id=$data[$i]");
			$db->update("UPDATE joe_pages SET PageStatus='0' WHERE ParentID=$data[$i]");
		} elseif($tablename=="joe_product_cat") {
			$db->update("UPDATE $tablename SET status='0' WHERE id=$data[$i]");
			$db->update("UPDATE joe_product SET status='0' WHERE category=$data[$i]");
		} else
			$db->update("UPDATE $tablename SET status='0' WHERE id=$data[$i]");		
	}
}
?>
