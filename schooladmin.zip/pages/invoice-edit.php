<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Invoice - Add',$site->getSiteName());
//create a new object of the count model
$db = new Database;
$classes = new Classes;
$feetype = new FeesType;
$student = new Students;
$invoices = new Invoices;

//initialization
$feeTypeId = "0";
$studentID = "0";
$classesID = "0";
$term = "0";
		
if(isset($_POST['amount']) and isset($_POST['classesID']) and isset($_POST['updateInvoice'])) {
	$amount = $db->cleanData($_POST['amount']);
	$feeTypeId = $feetype->getFeeTypeById($db->cleanData($_POST['feeTypeId']))->feeTypeName;
	$studentID = $student->getStudentById($db->cleanData($_POST['studentID']))->studentName;
	$studentEmail = $student->getStudentById($db->cleanData($_POST['studentID']))->studentEmail;
	$studentPhone = $student->getStudentById($db->cleanData($_POST['studentID']))->studentPhone;
	$classesID = $classes->getClassById($db->cleanData($_POST['classesID']))->className;
	$classid = $db->cleanData($_POST['classesID']);
	$date = $db->cleanData($_POST['date']);
	$academicYear = $db->cleanData($_POST['academicYear']);
	$term = $db->cleanData($_POST['term']);
	if($feeTypeId == "NotSet" || $studentID == "0" || $studentID == "NotSet" || $classesID == "NotSet" || $term == "0") {
		print "<script>alert('Sorry! All fields are required');</script>";
	} else {
		//insert into the database
		$admin = $_SESSION['Username'];
		$unqid = $ACTION[1];
		$update = $db->update("UPDATE `payments` 
				SET
					`feetypeid`='".$db->cleanData($_POST['feeTypeId'])."',
					`feetype`='$feeTypeId',
					`studentid`='$studentID',
					`studentunq`='".$db->cleanData($_POST['studentID'])."',
					`studentemail`='$studentEmail',
					`studentphone`='$studentPhone',
					`class`='$classesID',
					`classid`='$classid',
					`amount`='$amount',
					`academicyear`='$academicYear',
					`term`='$term',
					`updater`='$admin',
					`dateupd`=now()
				WHERE
					`studentunq`='$unqid'
				LIMIT 1
			");
		//redirect
		if($update) {
			print '<script>window.location.href="'.SITE_URL.'/invoice-view/'.$unqid.'?updated"</script>';
		}
	}
}
?>

	 <aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header active bg-purple">
        <h3 class="box-title"><i class="fa icon-invoice"></i> Invoice</h3>

       
        <ol style="display: block;" class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?php print SITE_URL; ?>/invoice/index">Invoice</a></li>
            <li class="active">Add Invoice</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
			<?php if(isset($ACTION[1]) and $invoices->getInvoiceById($ACTION[1])->invoiceResult==true) { ?>
            <div class="col-sm-5" style="border:solid #000000 0px">
				
                <form class="form-horizontal" role="form" method="post">
					<div class="form-group">
						<label for="classesID" class="col-sm-4 control-label">
                            Academic Year 
						</label>
                        <div class="col-sm-8">

                            <select tabindex="-1" required="required" onchange="return clearHistory();" name="academicYear" id="academicYear" class="form-control guargianID select2-offscreen">
								<option value="0">Select Academic Year</option>
								<?php
								print $invoices->getInvoiceById($ACTION[1])->invoiceAcademicYearO;
								$currentYear = date("Y")-4;
								for($i = 0; $i < 10; $i++) {
									$currentYear++;
									$previousYear = $currentYear - 1;
									if(($previousYear."/".$currentYear) == ''.(date("Y")).'/'.(date("Y")+1).'')
										print "<option value='".($previousYear)."/".($currentYear)."' selected='selected'>".($previousYear)."/".($currentYear)."</option>";
									else
										print "<option value='".($previousYear)."/".($currentYear)."'>".($previousYear)."/".($currentYear)."</option>";
								}
								?>
							</select>
							</div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
					<div class="form-group">
						<label for="classesID" class="col-sm-3 control-label">
							Term
						</label>
                        <div class="col-sm-8">

                            <select tabindex="-1" required="required" onchange="return getHistory();" name="term" id="term" class="form-control guargianID select2-offscreen">
								<option <?php if($invoices->getInvoiceById($ACTION[1])->invoiceTermR == 0) print 'selected="selected"'; ?> value="0">Select Academic Term</option>
								<option <?php if($invoices->getInvoiceById($ACTION[1])->invoiceTermR == 1) print 'selected="selected"'; ?> value="1">Term One</option>
								<option <?php if($invoices->getInvoiceById($ACTION[1])->invoiceTermR == 2) print 'selected="selected"'; ?> value="2">Term Two</option>
								<option <?php if($invoices->getInvoiceById($ACTION[1])->invoiceTermR == 3) print 'selected="selected"'; ?> value="3">Term Three</option>
								<option <?php if($invoices->getInvoiceById($ACTION[1])->invoiceTermR == 4) print 'selected="selected"'; ?> value="4">Term Four</option>
							</select>
							</div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
                    <div class="form-group">                        <label for="classesID" class="col-sm-3 control-label">
                            Class                        </label>
                        <div class="col-sm-8">

                            <select tabindex="-1" required="required" onchange="return clearHistory();" name="classesID" id="classesID" class="form-control guargianID select2-offscreen">
								<option value="0">Select Class</option>
								<?php
								$classid = $invoices->getInvoiceById($ACTION[1])->invoiceStudentClassId;
								$selectclass = $db->select("SELECT * FROM `class` WHERE `id`='$classid'");
								if($db->scount($selectclass) >0) {
									while($resclass=$selectclass->fetch_assoc()){
										print "<option value='".$resclass['id']."' selected='selected'>{$resclass['name']}</option>";
									}
								}
								$sql2 = $db->select("SELECT * FROM `class`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['name']}</option>";
									}
								}
								?>
							</select>
							</div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">                        <label for="studentID" class="col-sm-3 control-label">
                            Student                        </label>
                        <div class="col-sm-8">

                            <select tabindex="-1" required onchange="return clearHistory();" name="studentID" id="studentID" class="form-control guargianID select2-offscreen">
								<option value="0">Select Student</option>
								<?php
								$studid = $invoices->getInvoiceById($ACTION[1])->invoiceStudentUnq;
								$selectstud = $db->select("SELECT * FROM `students` WHERE `studentunq`='$studid'");
								if($db->scount($selectstud) >0) {
									while($resstud=$selectstud->fetch_assoc()){
										print "<option value='".$resstud['studentunq']."' selected='selected'>{$resstud['surname']} {$resstud['firstname']}</option>";
									}
								}
								?>
							</select>
						</div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">
						<label for="feetype" class="col-sm-3 control-label">
                            Fee Type
						</label>
                        <div class="col-sm-8">
                            <select tabindex="-1" required name="feeTypeId" onchange="return getHistory();" id="feeTypeId" class="form-control guargianID select2-offscreen">
								<option value="0">Select Fees Type</option>
								<?php
								$typeid = $invoices->getInvoiceById($ACTION[1])->invoiceFeeTypeID;
								$selecttype = $db->select("SELECT * FROM `finance_feestype` WHERE `id`='$typeid'");
								if($db->scount($selecttype) >0) {
									while($restype=$selecttype->fetch_assoc()){
										print "<option value='".$restype['id']."' selected='selected'>{$restype['type']}</option>";
									}
								}
								$sql3 = $db->select("SELECT * FROM `finance_feestype`");
								if($db->scount($sql3) >0) {
									while($res3=$sql3->fetch_assoc()){
										print "<option value='".$res3['id']."'>{$res3['type']}</option>";
									}
								}
								?>
							</select>
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">                        <label for="amount" class="col-sm-3 control-label">
                            Amount                        </label>
                        <div class="col-sm-8">
                            <input value="<?php print $invoices->getInvoiceById($ACTION[1])->invoiceAmount; ?>" class="form-control" required="required" onkeyup="return getHistory();" id="amount" name="amount" type="number">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">                        <label for="date" class="col-sm-3 control-label">
                            Date                        </label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" value="<?php print $invoices->getInvoiceById($ACTION[1])->invoiceDateR; ?>" id="date" name="date" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-8">
                            <input class="btn btn-success" value="Update Invoice" name="updateInvoice" type="submit">
                        </div>
                    </div>

                </form>
				 
            </div>
			<div class="col-sm-7">
				<div id="feeTypeHistory"></div>
			</div>
			<script type="text/javascript">
		getHistory();
		function getHistory() {
			
			var feeTypeId = $("#feeTypeId").val();
			var studentID = $("#studentID").val();
			var term = $("#term").val();
			var classesID = $("#classesID").val();
			var academicYear = $("#academicYear").val();
			if(classesID == '0') {
				alert("Please Select Class");
				$("#classesID").focus();
			} else
			if(studentID == '0') {
				alert("Please Select Student");
				$("#studentID").focus();
			} else
			if(studentID != '0' && feeTypeId != "0") {
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_student_payment_history",
					data: "classID="+classesID+"&feeTypeId=" + feeTypeId + "&studentID=" + studentID + "&term=" + term + "&academicYear=" +academicYear,
					dataType: "html",
					success: function(data) {
					   $('#feeTypeHistory').html(data);
					}
				});
			}
			
		}
		function clearHistory() {
			$('#feeTypeHistory').html('');
		}
		$('#date').datepicker();
		</script> 
			<?php } else {
					print '<div id="printablediv">
					<section class="content invoice">';
					PageNotFound();
					print '</section>';
					print '</div>';
				} ?>
        </div>
    </div>
		</div>

		
                    </div>
                </div>
            </section>
        </aside>
<?php
//get the page footer to include
template_footer();
?>