<?php
$title = '';
if(isset($_GET['type'])) {
	$title = ucfirst($_GET['type']);
}
?>
<!DOCTYPE html>
<html style="min-height: 964px;">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="UTF-8">
        <title> <?php print $title; ?> - Add | <?php print SITE_NAME; ?></title>
		<link href="<?php print SITE_CSS_PATH; ?>/bootstrap.css" rel="stylesheet">
		<script type="text/javascript" src="<?php print SITE_JS_PATH; ?>/jquery.js"></script>
	</head>
<body>
<div style="margin:10px;">
	<div style="text-align:center;font-weight:bolder;text-transform:uppercase;font-size:18px;">
	<?php print $title; ?> - Add</div>
	<table width="100%">
		<tr>
			<td>
				<div id="form">
				<div class="form-group">
					<label for="<?php print $title; ?>" class="col-sm-4 control-label">
                           <strong><?php print $title; ?></strong>
					</label>
                       <div class="col-sm-12">
                           <input value="" required="required" class="form-control" id="<?php print $title; ?>" name="<?php print $title; ?>" type="text">
                       </div>
                   </div>
				<div class="form-group">
                    <div class="col-sm-offset-3 col-sm-8">
						<input id="pagename" value="<?php print strtolower($title); ?>" name="pagename" type="hidden">
						<input onclick="insertInformation();" class="btn btn-success" value="Insert <?php print $title; ?>" name="insert<?php print $title; ?>" type="submit">
                    </div>
                </div>
				</div>
				<div id="results"></div>
				<hr>
				
					<a class="btn btn-info" href="<?php print SITE_URL; ?>/add-new?type=designation">
					<i class="fa fa-edit"></i> 
					New Designation
					</a>
					<a class="btn btn-info" href="<?php print SITE_URL; ?>/add-new?type=qualification">
					<i class="fa fa-edit"></i> 
					New Qualification
					</a>
					<a class="btn btn-info" href="<?php print SITE_URL; ?>/add-new?type=religion">
					<i class="fa fa-edit"></i> 
					New Religion
					</a>
				<script>
				function insertInformation() {
					var name = $("#<?php print $title; ?>").val();
					if(name.length < 5) {
						alert("Sorry! Please enter name of <?php print $title; ?>");
						$("#<?php print $title; ?>").focus();
					} else {
						$.ajax({
							type: 'POST',
							url: "<?php print SITE_URL; ?>/z_insert_new",
							data: "type=<?php print $title; ?>&value="+name,
							dataType: "html",
							success: function(results) {
							   $("#results").html(results);
							   close();
							}
						});
					}
				}
				</script>
			</td>
		</tr>
	</table>
</div>

</body>
</html>
		
		