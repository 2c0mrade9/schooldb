<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Search Results',$site->getSiteName());
//create a new object of the count model
$msg_log = '';
$models = new Models;
?>

<aside class="right-side">
    <section class="content">
		<div class="box">
			<div class="box-header bg-purple">
				<h3 class="box-title"><i class="fa fa-search"></i> Search Results</h3>

				   
				<ol class="breadcrumb">
					<li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
					<li class="active"> Search</li>
				</ol>
			</div><!-- /.box-header -->
			<!-- form start -->
			<div class="box-body">
				<div class="row">
					<div class="col-sm-12">
						<section>
							<div class="col-xs-12 bg-aqua" align="center" style="background:#fff;padding:5px;border-radius:4px;">
								<form action="javascript:search_result();" id="search_form" name="search_form">
								<table border="0">
								<tr>
								<td>
									<span style="font-weight:normal;font-size:16px;">Search: </span>
								</td>
								<td>
									<input type="text" name="q" onkeyup="return search_results();" id="q" value="<?php $db = new Database; if(isset($_GET['q'])) print $db->cleanData($_GET['q']); ?>" id="q" style="padding:3px;border-radius:3px;font-size:14px;width:500px;">
								</td>
								</tr>
								<tr>
									<td>
										<span style="font-weight:normal;font-size:16px;">Filter Search: </span>
									</td>
									<td>
										<select id="s" style="width:200px" onchange="return search_results();" name="search_type" class="form-control">
										<?php
										if(isset($_GET['search_type']) and !empty($_GET['search_type'])) {
											print "<option value='".$_GET['search_type']."' selected='selected'>".ucwords($_GET['search_type'])."</option>";
										}										
										?>
										<option value="Students">Students</option>
										<option value="Guardian">Parent/Guardian</option>
										<option value="Employees">Employees</option>
										<option value="Designation">Designation</option>
										<option value="Class">Class</option>
										</select>
									</td>
								</tr>
								<tr>
									<td></td>
									<td><input class="btn" value="Search" type="submit"></td>
								</tr>
								</table>
								</form>
							</div>
						</section>
						<hr>
						<div class="form-group">
							<br clear="both"><br clear="both">
							<div id="reg_result"></div>
						</div>
					</div>
				</div>
			</div>
			<script>
			$("#q").focus();
			search_results();
			function search_result() {
				var q = $("#q").val();
				if(q.length < 3) {
					$('#reg_result').html('<div class="btn btn-danger">Sorry! A minimum of 3 characters is required for the search term.</div>');
				} else {
					search_results();
				}
			}
			function search_results() {
				var q = $("#q").val();
				var s = $("#s").val();
				$.ajax({
					type: "POST",  
					url: "<?php print SITE_URL; ?>/z_search_results",  
					data: "q="+q+"&s="+s,
					beforeSend: function() {
						$('#reg_result').html('<div style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
					},  success: function(response){
						$('#reg_result').html(response);
					}
				});
			}
			</script>
			<script type="text/javascript">
				$(function() {
					$("#example1").dataTable();
				});
			</script>
				 
		</div>
</section>
</aside>
	  
	  
<?php
//get the page footer to include
template_footer();
?>