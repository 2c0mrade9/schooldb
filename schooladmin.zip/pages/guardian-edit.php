<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Parents -  Add',$site->getSiteName());
//create a new object of the count model
$guardian = new Guardian;
$student = new Students;
$models = new Models;

//process the form
$error_msg = '';
if(isset($_POST['addGuardian']) and isset($ACTION[1])) {
	//stripslashes and other sql injections
	$phone = $db->cleanData($_POST['phone']);
	$religion = $db->cleanData($_POST['religion']);
	$address = stripslashes($_POST['address']);
	$email = $db->cleanData($_POST['email']);
	$place = $db->cleanData($_POST['place']);
	$hometown = $db->cleanData($_POST['hometown']);
	$profession = $db->cleanData($_POST['profession']);
	$name = $db->cleanData($_POST['name']);
	$admin = $_SESSION['Username'];
	$alias = $models->create_slug($name);
	if(is_numeric($ACTION[1])) {
		if(strlen($name) > 3) {
			//check if the parent already exists in the database using the phone number
			$admin = $_SESSION["Username"];
			//insert the guardian information
			$update = $db->insert("UPDATE `guardian` SET fullname='$name',alias='$alias',profession='$profession',
					religion='$religion',phone='$phone',email='$email',address='$address',residence='$place',hometown='$hometown',
					occupation='$profession',moddate=now(),modadmin='$admin' WHERE id='".$ACTION[1]." LIMIT 1'") or trigger_error($db->db_error());
			if($update) {
				$religion = $guardian->getGuardianById($ACTION[1])->guardReligionOpt;
				//display success message
				$error_msg .= "<div class='btn btn-success'>Congrats! Guardian Information was successfully updated.</div><br><br>";
			} else {
				$error_msg .= "<div class='btn btn-danger'>Sorry! There was an error inserting guardian information.</div><br><br clear='both'>";
			}
		} else {
			$error_msg = "<div class='btn btn-danger'>Sorry! You parsed an empty field.</div><br><br>";	
		}
	} else {
		$error_msg = "<div class='btn btn-danger'>Sorry! You parsed a wrong Guardian ID.</div><br><br>";	
	}
} elseif(isset($ACTION[1]) and is_numeric($ACTION[1]) and $guardian->getGuardianById($ACTION[1])->guardResult == true) {
	$phone = $guardian->getGuardianById($ACTION[1])->guardPhone;
	$email = $guardian->getGuardianById($ACTION[1])->guardEmail;
	$address = $guardian->getGuardianById($ACTION[1])->guardAddress;
	$place = $guardian->getGuardianById($ACTION[1])->guardResidence;
	$religion = $guardian->getGuardianById($ACTION[1])->guardReligionOpt;
	$regid = $guardian->getGuardianById($ACTION[1])->guardReligionId;
	$name = $guardian->getGuardianById($ACTION[1])->guardName;
	$profession = $guardian->getGuardianById($ACTION[1])->guardOccup;
	$hometown = $guardian->getGuardianById($ACTION[1])->guardHometown;
}
?>

	<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-user"></i> Parents</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?PHP PRINT SITE_URL; ?>/parents/index">Parents</a></li>
            <li class="active">Add Parents</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            <div class="col-sm-6">
				<?php if(isset($ACTION[1]) and  is_numeric($ACTION[1]) and $guardian->getGuardianById($ACTION[1])->guardResult == true) { ?>
				<?php print $error_msg; ?>
                <form class="form-horizontal" role="form" method="post" enctype="multipart/form-data">

                    <div class="form-group"><label for="name_id" class="col-sm-4 control-label">
                            Guardian Name                        </label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" id="name_id" name="name" value="<?php print $name; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">
						<label for="father_name" class="col-sm-4 control-label">
							Guardian Profession</label>
                        <div class="col-sm-8">
                            <input class="form-control" id="profession" name="profession" value="<?php print $profession; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
					<div class="form-group">
						<label for="s2id_autogen1" class="col-sm-4 control-label">
                            Religion
						</label>
                        <div class="col-sm-8">
                            <div class="select2-wrapper">
                               
								<select tabindex="-1" name="religion" class="form-control guargianID">
								<option value="0">Please Select Religion</option>
								<?php print $religion; ?>
								<?php
								
								$rel = $db->select("SELECT * FROM `religion` WHERE id!='$regid' and `status`='1'");
								while($religionres=$rel->fetch_assoc()){
									print "<option value='".$religionres['id']."'>{$religionres['name']}</option>";
								}
								?>
								</select>
								
							</div>
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
                    
					<div class="form-group">
						<label for="s2id_autogen1" class="col-sm-4 control-label">
                            Ward
						</label>
                        <div class="col-sm-8">
                            <div class="select2-wrapper">
								<div class="call_wards"></div>
								<div class="call_all_wards"></div>
							</div>
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
                    
                    <div class="form-group">                        <label for="email" class="col-sm-4 control-label">
                            Email                        </label>
                        <div class="col-sm-8">
                            <input class="form-control" autocomplete="off" id="email" name="email" value="<?php print $email; ?>" type="email">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">                        <label for="phone" class="col-sm-4 control-label">
                            Phone                        </label>
                        <div class="col-sm-8">
                            <input class="form-control" autocomplete="off"  id="phone" name="phone" value="<?php print $phone; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">                        <label for="address" class="col-sm-4 control-label">
                            Address                        </label>
                        <div class="col-sm-8">
                            <textarea name="address" rows="5" id="address" class="form-control"><?php print $address; ?></textarea>
                        </div>
                        <span class="col-sm-4 control-label">
						</span>
                    </div>
					<div class="form-group">                        <label for="place" class="col-sm-4 control-label">
                            Place of Residence                        </label>
                        <div class="col-sm-8">
                            <input class="form-control" id="place" name="place" value="<?php print $place; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
						</span>
                    </div>

					<div class="form-group">                        
					<label for="hometown" class="col-sm-4 control-label">
                            Hometown</label>
                        <div class="col-sm-8">
                            <input class="form-control" id="hometown" name="hometown" value="<?php print $hometown; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
						</span>
                    </div>

                    <!--<div class="form-group">                        <label for="photo" class="col-sm-4 control-label col-xs-8 col-md-2">
                            Photo                        </label>
                        <div class="col-sm-4 col-xs-6 col-md-4">
                            <input class="form-control" id="uploadFile" placeholder="Choose File" disabled="disabled">  
                        </div>

                        <div class="col-sm-4 col-xs-6 col-md-2">
                            <div class="fileUpload btn btn-success form-control">
                                <span class="fa fa-repeat"></span>
                                <span>Upload</span>
                                <input id="uploadBtn" class="upload" name="image" type="file">
                            </div>
                        </div>
                         <span class="col-sm-4 control-label col-xs-6 col-md-4">
                           
                                                    </span>
                    </div>-->

                    <div class="form-group">
                        <div class="col-sm-offset-4 col-sm-4">
                            <input class="btn btn-success" value="Update Parent/Guardian Info" name="addGuardian" type="submit">
                        </div>
                    </div>

                </form>
				<script>
				call_wards();
				call_all_wards('<?php print $ACTION[1]; ?>');
				function add_ward(wid) {
					$.ajax({
						type: 'POST',
						url: "<?php print SITE_URL; ?>/z_ward_add",
						data: "add_ward&pid=<?php print $ACTION[1]; ?>&wid="+wid,
						dataType: "html",
						success: function(data) {
							call_wards();
						}
					});
				}
				function remove_ward(wid) {
					$.ajax({
						type: 'POST',
						url: "<?php print SITE_URL; ?>/z_ward_remove",
						data: "remove_ward&id="+wid,
						dataType: "html",
						success: function(data) {
							call_wards();
						}
					});
				}
				function call_wards() {
					$.ajax({
						type: 'POST',
						url: "<?php print SITE_URL; ?>/z_ward_call",
						data: "call_wards&pid=<?php print $ACTION[1]; ?>",
						dataType: "html",
						success: function(data) {
						   $(".call_wards").html(data);
						   call_all_wards('<?php print $ACTION[1]; ?>');
						}
					});
				}
				function call_all_wards(pid) {
					$.ajax({
						type: 'POST',
						url: "<?php print SITE_URL; ?>/z_ward_call_all",
						data: "call_all_wards&pid="+pid,
						dataType: "html",
						success: function(data) {
						   $(".call_all_wards").html(data);
						}
					});
				}
				</script>
				<?php } else { ?>
					<?php pageNotFound(); ?>
				<?php } ?>
            </div> <!-- col-sm-8 -->
			<div class="col-sm-6">
				<input class="btn btn-warning" value="Add New" name="addGuardian" onclick="javascript:window.location.href='<?php print SITE_URL; ?>/parents-add'">
				<br clear="all">
				<span style="padding:15px 15px 15px 15px;font-weight:bold;font-size:20px;">LIST OF ALL PARENTS</span><br clear="all"><br clear="all">
				<div id="listGuardian"></div>
			</div>
        </div><!-- row -->
    </div><!-- Body -->
</div><!-- /.box -->
</div>
</div>
</section>
</aside>
<script type="text/javascript">
$("#name_id").focus();
listGuardian();
function listGuardian() {
	$.ajax({
		type: 'POST',
		url: "<?php print SITE_URL; ?>/z_call_guardian",
		data: "listGuardian&call_all",
		dataType: "html",
		success: function(data) {
		   $('#listGuardian').html(data);
		}
	});
}
document.getElementById("uploadBtn").onchange = function() {
    document.getElementById("uploadFile").value = this.value;
};
</script>

<?php
//get the page footer to include
template_footer();
?>