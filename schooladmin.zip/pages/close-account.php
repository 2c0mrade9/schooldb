<?php
//call the checkaccess file
require 'core/checkaccess.php';
//initialization
$msg = "";
?>
<!DOCTYPE html>
<html class="white-bg-login" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>CLOSE ACCOUNT | <?PHP PRINT SITE_NAME; ?></title>
    <link rel="SHORTCUT ICON" href="<?php print SITE_IMAGE_PATH; ?>/site.png">
    <!-- bootstrap 3.0.2 -->
    <link href="<?php print SITE_CSS_PATH; ?>/bootstrap.css" rel="stylesheet" type="text/css">
    <!-- font Awesome -->
    <link href="<?php print SITE_CSS_PATH; ?>/font-awesome.css" rel="stylesheet" type="text/css">
    <!-- Style -->
    <link href="<?php print SITE_CSS_PATH; ?>/style.css" rel="stylesheet" type="text/css">
    <!-- iNilabs css -->
    <link href="<?php print SITE_CSS_PATH; ?>/inilabs.css" rel="stylesheet" type="text/css">
    <link href="<?php print SITE_CSS_PATH; ?>/responsive.css" rel="stylesheet" type="text/css">
</head>

<body class="white-bg-login" style="background:url(<?php print SITE_IMAGE_PATH; ?>/loginbg.jpg) repeat scroll #1A2229;">

    <div class="col-md-4 col-md-offset-4 marg" style="margin-top:30px;">
        <center><img src="<?php print SITE_IMAGE_PATH; ?>/site.png" height="50" width="50"></center>
		<center><h4><?php print SITE_NAME; ?></h4></center>
    </div>

     
<div class="form-box" id="login-box" style="height:auto;width:600px;bottom:0px;">
	<div class="header bg-fuchsia">CLOSE ACCOUNT MENU</div>
	
    <form method="post" action="<?php print SITE_URL; ?>/close-account-confirm">
        <!-- style="margin-top:40px;" -->
        <div class="body white-bg">
			<div style="text-align:justify;font-size:16px;" class="alert">
				YOU ARE WARMLY WELCOMED TO THE CLOSE ACCOUNT PAGE.
				PLEASE NOTE THAT, WHATEVER ACTION THAT YOU TAKE HERE 
				<STRONG><EM>CANNOT BE REVERSED AUTOMATICALLY</EM></STRONG> UNLESS YOU CALL ON THE 
				<STRONG><EM>SYSTEMS	ADMINISTRATOR.</EM></STRONG><BR><Br>
				BEAR IN MIND THAT, IT WILL ALSO CAUSE A DRASTIC CHANGES TO YOUR 
				<STRONG><EM>FINANCIAL SECTION;</EM></STRONG> AS IT WILL MOVE TO THE NEXT ACADEMIC YEAR 
				AND AS SUCH
				<STRONG>ALL ARREARS OF STUDENTS</STRONG> WILL BE ADDED TO THE NEXT ACADEMIC YEAR.
				<BR><BR>
				<STRONG>ACADEMIC YEAR: <?php print AC_YEAR; ?><BR>
				ACADEMIC TERM: <?php print AC_TERM; ?></STRONG>
				<hr>
				PLEASE CHECK ALL THE FEES THAT SHOULD BE PAID BY EACH CLASS.
				<strong><a href="<?php print SITE_URL; ?>/classes/index">CLICK HERE TO CONFIRM THE FEES PAYMENT</a></strong>
				OR CLICK ON CONTINUE IF YOU ARE SURE OF WHAT OUGHT TO BE PAID.
				<hr>
				<center>
				<input type="hidden" name="yesContinue" id="yesContinue" value="true">
				<button class="header bg-green" style="cursor:pointer;width:100%" align="center" id="contCLOSE">CONTINUE</button>
				<span class="header bg-red" style="cursor:pointer;" onclick="return contCANCEL();" id="contCANCEL">CANCEL</span>
				</center>
			</div>
		</div>
    </form>
	<br clear="all">
	<div class="body white-bg bg-green" align="center"><strong>CREATED BY: </strong><?php print $site->getSiteAuthor(); ?></div>
	<script>
	function contCLOSE() {
		window.location="<?php print SITE_URL; ?>/close-account-confirm?first"; 
	}
	function contCANCEL() {
		if(confirm("ARE YOU SURE YOU WANT TO CANCEL THE PROCESS?")) {
			window.location="<?php print SITE_URL; ?>/dashboard"; 
		}
	}
	</script>
</div>

</body></html>