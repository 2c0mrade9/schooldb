<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$models = new Models;
$guardian = new Guardian;
require 'core/checkaccess.php';
//remove parent associated with ward
if(isset($_POST['remove_ward']) and isset($_POST['id']) and !isset($_POST['adding_new']) and is_numeric($_POST['id'])) {
	$db->update("UPDATE students SET parent='0' WHERE id='".$db->cleanData($_POST['id'])."'");
} elseif(isset($_POST['remove_ward']) and isset($_POST['wid']) and is_numeric($_POST['wid']) and isset($_POST['adding_new'])) {
	$db->update("DELETE FROM guardian_add WHERE parent='".$db->cleanData($_POST['pid'])."' AND ward='".$db->cleanData($_POST['wid'])."'");
}
?>