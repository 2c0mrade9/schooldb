<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$models = new Models;
$guardian = new Guardian;
require 'core/checkaccess.php';
//remove parent associated with ward
if(isset($_POST['add_ward']) and isset($_POST['pid']) and is_numeric($_POST['pid']) and isset($_POST['wid']) and !isset($_POST['adding_new'])) {
	if(is_numeric($_POST['wid'])) {
		//add new ward 
		$db->update("UPDATE students SET parent='".$db->cleanData($_POST['pid'])."' WHERE id='".$db->cleanData($_POST['wid'])."'");
	}
} elseif(isset($_POST['adding_new']) and isset($_POST['pid']) and isset($_POST['wid'])) {
	//add new information of database
	$db->insert("INSERT INTO guardian_add (parent,ward) VALUES ('".$db->cleanData($_POST['pid'])."','".$db->cleanData($_POST['wid'])."') ");
}
?>