<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Fees Type - Edit',$site->getSiteName());
//create a new object of the count model
$feestype = new FeesType;
$msg_log = '';
//update the class information
if(isset($_POST['updatesFeesType'])) {
	$typeName = $db->cleanData($_POST['feetype']);
	$note = $db->cleanData($_POST['note']);
	$amount = $db->cleanData($_POST['amount']);
	$feeTypeId = $db->cleanData($_POST['feeTypeId']);
	if(!is_numeric($amount)) {
		print '<script>alert("Sorry! Please the amount field must be numeric.");$("#amount").focus;</script>';
	} else {
		//update the information
		$update = $db->update("UPDATE `finance_feestype` SET `type`='$typeName',`note`='$note',`amount`='$amount' WHERE `id`='$feeTypeId'");
		if($update) {
			$msg_log .= "<div class='btn bg-green'>Congrats! Fee Type information was successfully updated.</div><br><br>";
		} else {
			$msg_log .= "<div class='btn btn-danger'>Sorry! There was an error updating the fee type information.</div><br><br>";
		}
	}
}
?>
<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-money"></i> Fee Type</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?php print SITE_URL; ?>/fees-type/index"> Fee Types</a></li>
            <li class="active">Edit Fees Type</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            <div class="col-sm-6">
				<?php if(isset($ACTION[1]) and is_numeric($ACTION[1]) and $feestype->getFeeTypeById($ACTION[1])->fTypeResult==true) { ?>
				
				<?php print $msg_log; ?>
				<form class="form-horizontal" role="form" method="post">

                    <div class="form-group">                        <label for="feetype" class="col-sm-3 control-label">
                            Fees Type                        </label>
                        <div class="col-sm-8">
                            <input value="<?php print $feestype->getFeeTypeById($ACTION[1])->feeTypeName; ?>" required="required" class="form-control" id="feetype" name="feetype" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">
						<label for="feetype" class="col-sm-3 control-label">
                            Amount
						</label>
                        <div class="col-sm-8">
                            <input value="<?php print $feestype->getFeeTypeById($ACTION[1])->feeTypeAmount; ?>" required="required" class="form-control" id="amount" name="amount" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                        </span>
                    </div>
                    <div class="form-group">                        <label for="note" class="col-sm-3 control-label">
                            Note                        </label>
                        <div class="col-sm-8">
                            <textarea class="form-control" style="resize:none;height:100px;" id="note" name="note"><?php print $feestype->getFeeTypeById($ACTION[1])->feeTypeNote; ?></textarea>
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-8">
						<input type="hidden" name="feeTypeId" id="feeTypeId" value="<?php print $ACTION[1]; ?>">
                            <input class="btn btn-success" value="Update Fee Type" name="updatesFeesType" type="submit">
                        </div>
                    </div>

                </form>
				<?php
					} else {
						PageNotFound();
					}
				?>
            </div>
			<div class="col-sm-6">
				<div class="col-sm-12">
					<h4 style="font-weight:bolder;text-transform:uppercase;text-align:center;"><?php if(isset($ACTION[1]) and $ACTION[1]==1) print 'Please edit the School Fees class by class!'; ?></h4>
				</div>
				<div id="feeTypeHistory"></div>
			</div>
			<Script>
			getFeeTypes();
			function getFeeTypes() {
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_call_fee_types",
					data: "getFeeTypes&call_all",
					dataType: "html",
					success: function(data) {
					   $('#feeTypeHistory').html(data);
					}
				});
			}
			</script>
			
        </div>
    </div>
</div>
 
                    </div>
                </div>
            </section>
        </aside>
	  
<?php
//get the page footer to include
template_footer();
?>