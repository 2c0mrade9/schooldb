<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Parents -  Add',$site->getSiteName());
//create a new object of the count model
$guardian = new Guardian;
$student = new Students;
$models = new Models;

$_SESSION['parent_id'] = rand(12, 9999999);

//process the form
$error_msg = '';
if(isset($_POST['addGuardian'])) {
	//stripslashes and other sql injections
	$ward = $db->cleanData($_POST['ward']);
	$phone = $db->cleanData($_POST['phone']);
	$religion = $db->cleanData($_POST['religion']);
	$address = strtoupper(stripslashes($_POST['address']));
	$email = $db->cleanData($_POST['email']);
	$place = ucwords($db->cleanData($_POST['place']));
	$hometown = ucwords($db->cleanData($_POST['hometown']));
	$profession = ucwords($db->cleanData($_POST['profession']));
	$name = ucwords($db->cleanData($_POST['name']));
	$admin = $_SESSION['Username'];
	$alias = $models->create_slug($name);
	if(strlen($name) > 3) {
		
		//check if the parent already exists in the database using the phone number
		$checkP = $db->select("SELECT alias, phone FROM `guardian` WHERE alias='$alias' and phone='$phone'");
		if($db->scount($checkP) > 0) {
			$error_msg .= "<div class='btn btn-danger'>Sorry! A parent exists in the database with the same number. <a href='".SITE_URL."/guardian-view/$phone' target='_blank'>View Parent</a></div><br><br>";
		} else {
			//generate unique id
			$uniqueid = rand(0,9999);
			//check if the UNIQUE ID already exists
			if($db->scount($db->select("SELECT uniqueid FROM guardian WHERE uniqueid='$uniqueid'")) > 0)
				$uniqueid = rand(0,9999);
			else
			$uniqueid = $uniqueid;
			//get the admin username
			$admin = $_SESSION["Username"];
			//insert the guardian information
			$insert = $db->insert("INSERT INTO `guardian` (uniqueid,fullname,alias,profession,religion,phone,email,address,residence,hometown,occupation,ward,rdate,admin)
				VALUES('FVIPG$uniqueid','$name','$alias','$profession','$religion','$phone','$email','$address','$place','$hometown','$profession','$ward',now(),'$admin')
			");
			$insert_id = $db->getInsertId();
			if($insert) {
				//update the ward information
				$guardian->updateWards($_SESSION['parent_id'],$insert_id);
				
				//display success message
				$error_msg .= "<div class='btn btn-success'>Congrats! New Guardian Inserted Into Database.</div><br><br>";
				$error_msg .= "<script>listGuardian();</script>";
				$ward = '';
				$phone = '';
				$email = '';
				$address = '';
				$hometown='';
				$place = '';
				$religion = '';
				$name = '';
				$profession = '';
			} else {
				$error_msg .= "<div class='btn btn-danger'>Sorry! There was an error inserting guardian information.</div><br><br clear='both'>";
			}
		}
	} else {
		$error_msg = "<div class='btn btn-danger'>Sorry! You parsed an empty field.</div><br><br>";	
	}
} else {
	$ward = '';
	$phone = '';
	$email = '';
	$address = '';
	$place = '';
	$religion = '';
	$name = '';
	$profession = '';
	$hometown = '';
}
?>

	<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-user"></i> Add Guardian / Guardian</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?PHP PRINT SITE_URL; ?>/parents/index">Parents</a></li>
            <li class="active">Add Parents</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            <div class="col-sm-6">
				<?php print $error_msg; ?>
				<div class="col-sm-offset-0 col-sm-4">
					<input class="btn btn-success" value="ADD NEW" onclick="return addnew();" name="addGuardian" type="submit">
                </div>
				<br clear="all"><br clear="all">
                <form class="form-horizontal" role="form" method="post" enctype="multipart/form-data">

                    <div class="form-group"><label for="name_id" class="col-sm-4 control-label">
                            Guardian Name                        </label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" id="name_id" name="name" value="<?php print $name; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">
						<label for="father_name" class="col-sm-4 control-label">
							Guardian Profession</label>
                        <div class="col-sm-8">
                            <input class="form-control" id="profession" name="profession" value="<?php print $profession; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
					<div class="form-group">
						<label for="s2id_autogen1" class="col-sm-4 control-label">
                            Religion
						</label>
                        <div class="col-sm-8">
                            <div class="select2-wrapper">
                               
								<select tabindex="-1" name="religion" id="guargianID" class="form-control guargianID select2-offscreen">
								<option value="0">Please Select Religion</option>
								<?php print $religion; ?>
								<?php
								
								$rel = $db->select("SELECT * FROM `religion` WHERE `status`='1'");
								while($religionres=$rel->fetch_assoc()){
									print "<option value='".$religionres['id']."'>{$religionres['name']}</option>";
								}
								?>
								</select>
								
							</div>
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
                    
					<div class="form-group">
						<label for="s2id_autogen1" class="col-sm-4 control-label">
                            Ward
						</label>
                        <div class="col-sm-8">
                            <div class="select2-wrapper">
								<div class="call_wards"></div>
								<div class="call_all_wards"></div>
							</div>
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
                    
                    <div class="form-group">                        <label for="email" class="col-sm-4 control-label">
                            Email                        </label>
                        <div class="col-sm-8">
                            <input class="form-control" autocomplete="off" id="email" name="email" value="<?php print $email; ?>" type="email">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">                        <label for="phone" class="col-sm-4 control-label">
                            Phone                        </label>
                        <div class="col-sm-8">
                            <input class="form-control" autocomplete="off"  id="phone" name="phone" value="<?php print $phone; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">                        <label for="address" class="col-sm-4 control-label">
                            Address                        </label>
                        <div class="col-sm-8">
                            <textarea name="address" rows="5" id="address" class="form-control"><?php print $address; ?></textarea>
                        </div>
                        <span class="col-sm-4 control-label">
						</span>
                    </div>
					<div class="form-group">                        <label for="place" class="col-sm-4 control-label">
                            Place of Residence                        </label>
                        <div class="col-sm-8">
                            <input class="form-control" id="place" name="place" value="<?php print $place; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
						</span>
                    </div>

					<div class="form-group">                        
					<label for="hometown" class="col-sm-4 control-label">
                            Hometown</label>
                        <div class="col-sm-8">
                            <input class="form-control" id="hometown" name="hometown" value="<?php print $hometown; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
						</span>
                    </div>

                    <!--<div class="form-group">                        <label for="photo" class="col-sm-4 control-label col-xs-8 col-md-2">
                            Photo                        </label>
                        <div class="col-sm-4 col-xs-6 col-md-4">
                            <input class="form-control" id="uploadFile" placeholder="Choose File" disabled="disabled">  
                        </div>

                        <div class="col-sm-4 col-xs-6 col-md-2">
                            <div class="fileUpload btn btn-success form-control">
                                <span class="fa fa-repeat"></span>
                                <span>Upload</span>
                                <input id="uploadBtn" class="upload" name="image" type="file">
                            </div>
                        </div>
                         <span class="col-sm-4 control-label col-xs-6 col-md-4">
                           
                                                    </span>
                    </div>-->

                    <div class="form-group">
                        <div class="col-sm-offset-4 col-sm-4">
                            <input class="btn btn-success" value="Insert Parent/Guardian Info" name="addGuardian" type="submit">
                        </div>
                    </div>

                </form>
            </div> <!-- col-sm-8 -->
			<div class="col-sm-6">
				<span style="padding:15px 15px 15px 15px;font-weight:bold;font-size:20px;">LIST OF ALL PARENTS</span><br clear="all"><br clear="all">
				<div id="listGuardian"></div>
			</div>
        </div><!-- row -->
    </div><!-- Body -->
</div><!-- /.box -->
</div>
</div>
</section>
</aside>
<script type="text/javascript">
$("#name_id").focus();
listGuardian();
call_all_wards(5);
function call_all_wards(ppid) {
	$.ajax({
		type: 'POST',
		url: "<?php print SITE_URL; ?>/z_ward_call_all",
		data: "call_all_wards&_fetched&ppid="+ppid,
		dataType: "html",
		success: function(data) {
		   $(".call_all_wards").html(data);
		}
	});
}
function add_ward(wid) {
	$.ajax({
		type: 'POST',
		url: "<?php print SITE_URL; ?>/z_ward_add",
		data: "add_ward&adding_new&pid=<?php print $_SESSION['parent_id']; ?>&wid="+wid,
		dataType: "html",
		success: function(data) {
			call_wards();
			call_all_wards('<?php print $_SESSION['parent_id']; ?>');
		}
	});
}
function call_wards() {
	$.ajax({
		type: 'POST',
		url: "<?php print SITE_URL; ?>/z_ward_call",
		data: "adding_new&call_wards&pid=<?php print $_SESSION['parent_id']; ?>",
		dataType: "html",
		success: function(data) {
		   $(".call_wards").html(data);
		}
	});
}
function remove_ward_add(wid) {
	$.ajax({
		type: 'POST',
		url: "<?php print SITE_URL; ?>/z_ward_remove",
		data: "remove_ward&pid=<?php print $_SESSION['parent_id']; ?>&adding_new&wid="+wid,
		dataType: "html",
		success: function(data) {
			call_wards();
		}
	});
}
function listGuardian() {
	$.ajax({
		type: 'POST',
		url: "<?php print SITE_URL; ?>/z_call_guardian",
		data: "listGuardian&call_all",
		dataType: "html",
		success: function(data) {
		   $('#listGuardian').html(data);
		}
	});
}

function addnew() {
	var n = $("#name_id").val();
	if(n.length > 0) {
		if(confirm("You have unsaved information. Do you want to discard the current entry?")){
			window.location.href='';
		}
	} else {
		window.location.href='';
	}
}
document.getElementById("uploadBtn").onchange = function() {
    document.getElementById("uploadFile").value = this.value;
};
</script>

<?php
//get the page footer to include
template_footer();
?>