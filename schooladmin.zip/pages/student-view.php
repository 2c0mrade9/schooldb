<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('student - View',$site->getSiteName());
//create a new object of the count model
$student = new Students;
$guardian = new Guardian;
$remarks = new Remarks;
?>

		<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
    <div class="well bg-purple">
        <div class="row">
            <div class="col-sm-6">
                <button class="btn-cs btn-sm-cs" onclick="javascript:printDiv('printablediv')"><span class="fa fa-print"></span> Print </button>
                <button class="btn-cs btn-sm-cs" data-toggle="modal" data-target="#idCard"><span class="fa fa-floppy-o"></span> ID Card </button>
                <a href="<?php print SITE_URL; ?>/student-edit/<?php print $ACTION[1]; ?>" class="btn-cs btn-sm-cs" style="text-decoration: none;" role="button"><i class="fa fa-edit"></i> Edit</a>
				<a href="<?php print SITE_URL; ?>/student-add" class="btn-cs btn-sm-cs" style="text-decoration: none;" role="button"><i class="fa fa-plus"></i> Add</a>
				<a href="<?php print SITE_URL; ?>/student-add" class="btn-cs btn-sm-cs" style="text-decoration: none;" role="button"><i class="fa fa-money"></i> Fees Payment</a>
			</div>
            <div class="col-sm-6">
                <ol class="breadcrumb">
                    <li><a href="<?php print SITE_URL; ?>"><i class="fa fa-laptop"></i> Dashboard</a></li>
                    <li class="active"><a href="<?php print SITE_URL; ?>/student/index">Student</a></li>
                    <li class="active">View</li>
                </ol>
            </div>
        </div>   
    </div>
    
	<?php if(isset($ACTION[1]) and $db->cleanData($ACTION[1]) and $student->getStudentById($ACTION[1])->stuResult==true) { ?>
    <div id="printablediv">
        <section class="panel">
            <div class="profile-view-head bg-blue">
                <a href="#">
                    <img src="<?php print SITE_IMAGE_PATH; ?>/default.png" alt="">                </a>

                <h1><?php print $student->getStudentById($ACTION[1])->studentName; ?></h1>
                <p><?php print $student->getStudentById($ACTION[1])->studentClass2; ?></p>
            </div>
            <div class="panel-body profile-view-dis" style="color:#000;font-size:14px">
                <h1  style="color:green">PERSONAL INFORMATION</h1>
                <div class="row">
					 <div class="profile-view-tab">
                        <p><span>Student ID</span>: <?php print $student->getStudentById($ACTION[1])->studentId; ?></p>
                    </div>
					<div class="profile-view-tab">
                        <p><span>Date of Birth </span>: <?php print $student->getStudentById($ACTION[1])->studentDob; ?></p>
                    </div>
					<div class="profile-view-tab">
                        <p><span>Religion </span>: <?php print $student->getStudentById($ACTION[1])->studentReligion; ?></p>
                    </div>
					<div class="profile-view-tab">
                        <p><span>Phone </span>: <?php print $student->getStudentById($ACTION[1])->studentPhone; ?></p>
                    </div>
                    <div class="profile-view-tab">
                        <p><span>Gender </span>: <?php print $student->getStudentById($ACTION[1])->studentGender; ?></p>
                    </div>
                    
                    <div class="profile-view-tab">
                        <p><span>Email </span>: <?php print $student->getStudentById($ACTION[1])->studentEmail; ?></p>
                    </div>
                    <div class="profile-view-tab">
                        <p><span>Place of Residence </span>: <?php print $student->getStudentById($ACTION[1])->studentPlace; ?></p>
                    </div>
                    <div class="profile-view-tab">
                        <p><span>Address </span>: <?php print $student->getStudentById($ACTION[1])->studentAddress; ?></p>
                    </div>
                    
                </div>
				
				<?php if($remarks->getRemarksByid($ACTION[1],"students")->remResult==true) { ?>
				<hr>
				<div class="profile-view">
					<h1 style="color:green">REMARKS</h1>
					<table border="0" cellpadding="10px">
						<tr>
							<td width="20%" valign="top">
								<strong>Head Teachers Remarks </strong>
							</td>
							<td>
								<?php print $remarks->getRemarksByid($ACTION[1],"students")->headTeacher; ?>
							</td>
						</tr>
						<tr>
							<td  valign="top">
								<strong>Proprietriess Remarks </strong>
							</td>
							<td>
								<?php print $remarks->getRemarksByid($ACTION[1],"students")->proprietress; ?>
							</td>
						</tr>
					</table>
                </div>
				
				<?php } ?>
				
				<?php if($guardian->getGuardianById($student->getStudentById($ACTION[1])->studentGuardian)->guardResult==true) { ?>
				<hr>
				<h1 style="color:green">PARENTS INFORMATION</h1>
                
				
                <div class="row">
                    <div class="profile-view-tab">
                        <p><span>Guardian </span>: <?php print $guardian->getGuardianById($student->getStudentById($ACTION[1])->studentGuardian)->guardName; ?></p>
                    </div>
                    <div class="profile-view-tab">
                        <p><span>Guardian's Profession </span>: <?php print $guardian->getGuardianById($student->getStudentById($ACTION[1])->studentGuardian)->guardOccup; ?></p>
                    </div>
                    <div class="profile-view-tab">
                        <p><span>Email </span>: <?php print $guardian->getGuardianById($student->getStudentById($ACTION[1])->studentGuardian)->guardEmail; ?></p>
                    </div>
                    <div class="profile-view-tab">
                        <p><span>Phone </span>: <?php print $guardian->getGuardianById($student->getStudentById($ACTION[1])->studentGuardian)->guardPhone; ?></p>
                    </div>
                    <div class="profile-view-tab">
                        <p><span>Address </span>: <?php print $guardian->getGuardianById($student->getStudentById($ACTION[1])->studentGuardian)->guardAddress; ?></p>
                    </div>
					<div class="profile-view-tab">
                        <p><span>Religion </span>: <?php print $guardian->getGuardianById($student->getStudentById($ACTION[1])->studentGuardian)->guardReligion; ?></p>
                    </div>
					<div class="profile-view-tab">
                        <p><span>Place of Residence </span>: <?php print $guardian->getGuardianById($student->getStudentById($ACTION[1])->studentGuardian)->guardResidence; ?></p>
                    </div>

                </div>
				
				<?php } ?>
				
            </div>
        </section>
    </div>

    
    <!-- Modal content start here -->
    <div class="modal fade" id="idCard">
      <div class="modal-dialog">
        <div class="modal-content" style="background-color">
            <div id="idCardPrint">
              <div class="modal-header">
                Student ID Card
				</div>
              <div class="modal-body"> 
                    <table>
                        <tbody><tr>
                            <td>
                                <h4 style="margin:0;">
                                <img src="<?php print SITE_IMAGE_PATH; ?>/site.png" style="margin-bottom:10px;" alt="" height="25px" width="25px">                                </h4>
                            </td>
                            <td style="padding-left:5px;">
                                <h4><?PHP PRINT SITE_NAME; ?></h4>
                            </td>
                        </tr>
                    </tbody></table>

                <table class="idcard-Table">
                    <tbody><tr>
                        <td>
                            <h4>
                        <img src="<?php print SITE_IMAGE_PATH; ?>/default.png" style="border: 8px solid #2F6C7F" alt="">                            </h4> 
                        </td>
                        <td class="row-style">
                            <h3><?php print $student->getStudentById($ACTION[1])->studentName; ?></h3>
                            <h5>Class : <?php print $student->getStudentById($ACTION[1])->studentClass2; ?></h5>
                            <h5>Email : <?php print $student->getStudentById($ACTION[1])->studentEmail; ?></h5>
                            <h5>Phone : <?php print $student->getStudentById($ACTION[1])->studentPhone; ?></h5>
							 <h5>Guardian : <?php print $guardian->getGuardianById($student->getStudentById($ACTION[1])->studentGuardian)->guardName; ?>
							 <?php print $guardian->getGuardianById($student->getStudentById($ACTION[1])->studentGuardian)->guardPhone; ?>
							 </h5>
                        </td>
                    </tr>
                </tbody></table>    
              </div>
            </div>
          <div class="modal-footer">
            <button type="button" style="margin-bottom:0px;" class="btn btn-default" onclick="javascript:closeWindow()" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-success" onclick="javascript:printDiv('idCardPrint')">Print</button>
          </div>
        </div>
      </div>
    </div>
    <!-- Modal content End here -->

    <script language="javascript" type="text/javascript">
        function printDiv(divID) {
            //Get the HTML of div
            var divElements = document.getElementById(divID).innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            document.body.innerHTML = 
              "<html><head><title></title></head><body>" + 
              divElements + "</body>";

            //Print Page
            window.print();

            //Restore orignal HTML
            document.body.innerHTML = oldPage;
        }
        function closeWindow() {
            location.reload(); 
        }
       
    </script>
		
		<?php
			} else {
				PageNotFound();
			}
		?>

    
 
                    </div>
                </div>
            </section>
        </aside>
		
<?php
//get the page footer to include
template_footer();
?>