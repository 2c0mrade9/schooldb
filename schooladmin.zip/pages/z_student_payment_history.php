<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$feestype = new FeesType;
$classes = new Classes;
$invoices = new Invoices;
$student = new Students;
require 'core/checkaccess.php';

if(!isset($_POST['onlyBalance']) and isset($_POST['feeTypeId']) and isset($_POST['studentID'])) {
	
	$feeTypeId = $db->cleanData($_POST['feeTypeId']);
	$studentID = $db->cleanData($_POST['studentID']);
	$academicYear = $db->cleanData($_POST['academicYear']);
	$term = $db->cleanData($_POST['term']);
	$classID = $db->cleanData($_POST['classID']);
	
	//query the database
	$sql = $db->select("SELECT * FROM `payments` 
		WHERE 
			`feetypeid`='$feeTypeId' AND 
			`studentunq`='$studentID' AND
			`academicyear`='$academicYear' AND 
			`term`='$term' AND 
			`status`='1' 
		ORDER BY `id` DESC");	
	//count
	if($db->scount($sql) > 0) {
?>
		<div class="tab-content col-sm-12">
			<div id="all" class="tab-pane active">
			<?php
			//get the amount due
			if($feeTypeId==1)
				print '<h3>AMOUNT DUE: GHC'.$student->getStudentById($studentID)->studentBalance.'</h3>';
			else
				print '<h3>AMOUNT DUE: GHC'.$feestype->getFeeTypeById($feeTypeId)->feeTypeAmount.'</h3>';
			?>
			<div id="hide-table">
				<div id="example1_wrapper" class="dataTables_wrapper form-inline" role="grid">
				<table id="example1" class="table table-striped table-bordered table-hover dataTable no-footer">
					<thead>
					<tr role="row">
						<td>ID</td>
						<td width="20%">INV ID</td>
						<td width="20%">DATE</td>
						<td width="25%">FEES TYPE</td>
						<td width="30%">AMOUNT</td>
					</tr>
					</thead>
					<tbody aria-relevant="all" aria-live="polite" role="alert">
					<?php 
						//using the while loop
						while($result = $sql->fetch_assoc()) {
							print "<tr align='left' class='gradeU'>";
							print "<td><strong>{$result['id']}</strong></td>";
							print "<td><strong>{$result['unqid']}</strong></td>";
							print "<td><strong>".date("d M Y", strtotime($result['date']))."</strong></td>";
							print "<td><strong>".$feestype->getFeeTypeById($result['feetypeid'])->feeTypeName."</strong></td>";
							print "<td><strong>GHc {$result['amount']}</strong></td>";
							print "</tr>";
						}
					?>
					</tbody>
				</table>
				<table class="table table-striped table-bordered table-hover dataTable no-footer">
					<tr>
						<th class="col-sm-8 col-xs-8" width="60%">TOTAL PAYMENT (GHC)</th>
						<th align="right">GHc
						<?php print $invoices->generatePaymentStatus($term,$academicYear,$studentID,$classID,$feeTypeId)->totalPaymentMade; ?>
						</th>
					</tr>
				</table>
				<table class="table table-striped table-bordered table-hover dataTable no-footer">
					<tr>
                        <th class="col-sm-8 col-xs-8" width="15%">BALANCE (GHC)</th>
                        <td class="col-sm-4 col-xs-4" align="right">GHc<?php print $student->getStudentById($studentID)->studentBalance; ?></td>
                    </tr>
				</table>
				</div>
			</div>
			</div>
		</div>
<?php
	} else {
		//get the amount due
		if($feeTypeId==1)
			print '<h3>AMOUNT DUE: GHC '.$student->getStudentById($studentID)->studentBalance.'</h3>';
		else
			print '<h3>AMOUNT DUE: GHC '.$feestype->getFeeTypeById($feeTypeId)->feeTypeAmount.'</h3>';
		print '<div class="btn btn-warning">No financial records for the selected fee type.</div>';
?>
	<table class="table table-striped table-bordered table-hover dataTable no-footer">
	<tr>
		<th class="col-sm-8 col-xs-8" width="60%">TOTAL PAYMENT (GHC)</th>
		<th align="right">GHc
		<?php print $invoices->generatePaymentStatus($term,$academicYear,$studentID,$classID,$feeTypeId)->totalPaymentMade; ?>
		</th>
	</tr>
	</table>
	<table class="table table-striped table-bordered table-hover dataTable no-footer">
		<tr>
            <th class="col-sm-8 col-xs-8" width="15%">BALANCE (GHC)</th>
            <td class="col-sm-4 col-xs-4" align="right">GHc <?php print $student->getStudentById($studentID)->studentBalance; ?></td>
        </tr>
	</table>
<?php
	}
} if(isset($_POST['onlyBalance'])) {
	$feeTypeId = $db->cleanData($_POST['feeTypeId']);
	$studentID = $db->cleanData($_POST['studentID']);
	$academicYear = $db->cleanData($_POST['academicYear']);
	$term = $db->cleanData($_POST['term']);
	$amount = (int) $db->cleanData($_POST['amount']);
	$classID = $db->cleanData($_POST['classID']);
	
	$balance  = $student->getStudentById($studentID)->studentBalance;
	
	if($amount > $balance) {
		print '<br><div class="btn btn-warning"><strong>Sorry! The new amount paid is 
		higher than the balance. <br>Take note that the system will equate it to
		the balance.</strong></div>';
	}
}
?>