<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$feestype = new FeesType;
$classes = new Classes;
$invoices = new Invoices;
require 'core/checkaccess.php';

if(isset($_POST['getFeeTypes']) and isset($_POST['call_all'])) {
	
	//query the database
	$sql = $db->select("SELECT * FROM `finance_feestype` WHERE status='1' ORDER BY `id` ASC");	
	//count
	if($db->scount($sql) > 0) {
?>
		<h5 class="page-header">
			<a class="btn btn-warning" href="<?php print SITE_URL; ?>/fees-type/index">
				<i class="fa fa-edit"></i> 
				View Fee Types
			</a>
			<a class="btn btn-warning" href="<?php print SITE_URL; ?>/fees-type-add">
				<i class="fa fa-plus"></i> 
				Add Fees Type
			</a>
		</h5>
		<div class="col-sm-12">
			<div id="all" class="tab-pane active">
			<h3>Fee Types</h3>
			<div id="hide-table">
				<table id="example1" class="table table-striped table-bordered table-hover dataTable no-footer col-sm-12">
					<thead>
					<tr role="row">
						<td>ID</td>
						<td width="35%">FEE TYPE</td>
						<td width="25%">AMOUNT</td>
						<td width="30%">SLUG</td>
						<td>ACTION</td>
					</tr>
					</thead>
					<tbody aria-relevant="all" aria-live="polite" role="alert">
					<?php 
						//using the while loop
						while($result = $sql->fetch_assoc()) {
							print "<tr align='left' class='gradeU'>";
							print "<td><strong>{$result['id']}</strong></td>";
							print "<td><strong>{$result['type']}</strong></td>";
							print "<td><strong>GHc{$result['amount']}</strong></td>";
							print "<td><strong>{$result['slug']}</strong></td>";
							print '<td><a href="'.SITE_URL.'/fees-type-view/'.$result['id'].'" class="btn btn-info" data-placement="top" data-toggle="tooltip" data-original-title="View" title="View"><i class="fa fa-check-square-o"></i></a>';
							print "</td>";
							print "</tr>";
						}
					?>
					</tbody>
				</table>
			</div>
			</div>
		</div>
<?php
	} else {
?>
	<h5 class="page-header">
			<a class="btn btn-warning" href="<?php print SITE_URL; ?>/fees-type/index">
				<i class="fa fa-edit"></i> 
				View Fee Types
			</a>
			<a class="btn btn-warning" href="<?php print SITE_URL; ?>/fees-type-add">
				<i class="fa fa-plus"></i> 
				Add Fees Type
			</a>
		</h5>
	<h3>Fee Types</h3>
	<table class="table table-striped table-bordered table-hover dataTable no-footer">
	<tr>
		<th align="right">
		There are no Fee Types currently in the database</th>
	</tr>
	</table>

<?php
	}
}
?>