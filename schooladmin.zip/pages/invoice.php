<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Invoice',$site->getSiteName());
//create a new object of the count model
$invoices = new Invoices;
$feestype = new FeesType;
$classes = new Classes;
?>
	<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
					<div class="box">
						<div class="box-header bg-purple">
							<h3 class="box-title"><i class="fa fa-users"></i> Invoices</h3>
							<a href="<?php print SITE_URL; ?>/invoice" class="btn-cs btn-sm-cs" style="text-decoration: none;margin-top:10px" role="button"><i class="fa fa-credit-card"></i> Reload Page</a>
						   
							<ol class="breadcrumb">
								<li><a href="<?php print SITE_URL; ?>"><i class="fa fa-laptop"></i> Dashboard</a></li>
								<li class="active">Invoices</li>
							</ol>
						</div><!-- /.box-header -->
						<!-- form start -->
						<div class="box-body">
							<div class="row">
								<div class="col-sm-12">
									
									<h5 class="page-header">
										<a class="btn btn-success" href="<?php print SITE_URL; ?>/invoice-create">
											<i class="fa fa-plus"></i> 
											Add an Invoice/New Payment
										</a>
									</h5>
									
						
									
									<div class="col-sm-12">
									
									
									<div class="form-group">
										<h4 for="feetype">
											<strong>Filter Invoice:</strong>
										</h4>
										<div class="col-sm-2">
											<select tabindex="-1" name="academicYear" id="academicYear" class="form-control guargianID select2-offscreen">
												<?php
												print "<option selected='selected' value='".AC_YEAR."'>".AC_YEAR."</option>";
												$currentYear = date("Y")-3;
												if(isset($_GET['y'])) {
													print "<option value='".$_GET['y']."' selected='selected'>{$_GET['y']}</option>";
												}
												print "<option value='".AC_YEAR."'>Select Academic Year</option>";
												for($i = 0; $i < 6; $i++) {
													$currentYear++;
													$previousYear = $currentYear - 1;
													if(($previousYear."/".$currentYear) == ''.(date("Y")).'/'.(date("Y")+1).'') {
														if(isset($_GET['y']))
															print "<option value='".($previousYear)."/".($currentYear)."'>".($previousYear)."/".($currentYear)."</option>";
													} else
														print "<option value='".($previousYear)."/".($currentYear)."'>".($previousYear)."/".($currentYear)."</option>";
												}
												?>
											</select>
										</div>
										<div class="col-sm-2">

										<select tabindex="-1" name="term" id="term" class="form-control guargianID select2-offscreen">
											<option <?php if(defined("AC_TERM")) print 'selected="selected"'; ?> value="<?php print AC_TERM; ?>">Term <?php print AC_TERM; ?></option>
											<?php print "<option value='".AC_TERM."'>Select Current Academic Term</option>"; ?>
											<option <?php if(isset($_GET['t']) and $_GET['t'] == 1) print 'selected="selected"'; ?> value="1">Term One</option>
											<option <?php if(isset($_GET['t']) and $_GET['t'] == 2) print 'selected="selected"'; ?> value="2">Term Two</option>
											<option <?php if(isset($_GET['t']) and $_GET['t'] == 3) print 'selected="selected"'; ?> value="3">Term Three</option>
											<option <?php if(isset($_GET['t']) and $_GET['t'] == 4) print 'selected="selected"'; ?> value="4">Term Four</option>
										</select>
										</div>
										<div class="col-sm-2">
											<select tabindex="-1" name="feeTypeId" id="feeTypeId" class="form-control guargianID select2-offscreen">
												<option value="0">Select Fees Type</option>
												<?php
												if(isset($_GET['ty']) and is_numeric($_GET['ty'])) {
													$type = $db->cleanData($_GET['ty']);
													$typesql3 = $db->select("SELECT * FROM `finance_feestype` WHERE `id`='$type'");
													if($db->scount($typesql3) >0) {
														while($tres3=$typesql3->fetch_assoc()){
															print "<option value='".$tres3['id']."' selected='selected'>{$tres3['type']}</option>";
														}
													}
												}
												if(isset($_GET['ty']) and is_numeric($_GET['ty'])) {
													$addition = "where id!='".$db->cleanData($_GET['ty'])."'";
												} else {
													$addition = 'where 1';
												}
												$sql3 = $db->select("SELECT * FROM `finance_feestype` $addition");
												if($db->scount($sql3) >0) {
													while($res3=$sql3->fetch_assoc()){
														print "<option value='".$res3['id']."'>{$res3['type']}</option>";
													}
												}
												?>
											</select>
										</div>
										
										<div class="col-sm-2">

										<select tabindex="-1" name="classesID" id="classesID" class="form-control guargianID select2-offscreen">
											<option value="0">Select Class</option>
											<?php
											if(isset($_GET['c']) and is_numeric($_GET['c'])) {
												$classid = $db->cleanData($_GET['c']);
												$selectclass = $db->select("SELECT * FROM `class` WHERE `id`='$classid'");
												if($db->scount($selectclass) >0) {
													while($resclass=$selectclass->fetch_assoc()){
														print "<option value='".$resclass['id']."' selected='selected'>{$resclass['name']}</option>";
													}
												}
											}
											if(isset($_GET['c']) and is_numeric($_GET['c'])) {
													$addition = "where id!='".$db->cleanData($_GET['c'])."'";
												} else {
													$addition = 'where 1';
												}
											$sql2 = $db->select("SELECT * FROM `class` $addition");
											if($db->scount($sql2) >0) {
												while($res2=$sql2->fetch_assoc()){
													print "<option value='".$res2['id']."'>{$res2['name']}</option>";
												}
											}
											?>
										</select>
										</div>
										<div class="col-sm-2">

										<select tabindex="-1" name="split" id="split" class="form-control guargianID select2-offscreen">
											<option value="no">Split Results?</option>
											<option <?php if(isset($_GET['split']) 
													and $_GET['split']=="yes") print "selected='selected'"; ?> value="yes">YES</option>
											<option <?php if(isset($_GET['split']) 
													and $_GET['split']=="no") print "selected='selected'"; ?> value="no">NO</option>
											
										</select>
										</div>
										
									<span class="col-sm-4 control-label"></span>
									</div>
									
									<br clear="all">
									<div class="col-sm-12" align="right">
											<input class="btn btn-success" value="Filter Invoice" onclick="filterInvoice(); " type="submit">
										</div>
									<br clear="all"><br clear="all">
									
									<div class="nav-tabs-custom">
										<?php // if(isset($_GET['filter'])) { ?>
										<div style="padding-left:5px;font-size:15px;font-weight:bolder;font-family:arial" class="box-title">
											<?php if(isset($_GET['y'])) { ?>
											<span style="margin-right:15px;">Academic Year: <?php print $_GET['y']; ?></span>
											<?php } else {
												print '&nbsp;&nbsp;<span style="margin-right:15px;">Academic Year/Term: '.AC_YEAR.'</span>';
											} ?>
											<?php if(isset($_GET['t'])) { ?>
											| &nbsp;&nbsp;<span style="margin-right:15px;">Academic Term: 
											<?php if($_GET['t']==1) print 'One'; elseif($_GET['t'] == 2) print 'Two'; elseif($_GET['t'] == 3) print 'Three'; elseif($_GET['t'] == 4) print 'Four'; else print 'All Terms'; ?>
											<?php } else {
												print '| &nbsp;&nbsp;<span style="margin-right:15px;">Academic Term: '.AC_TERM.'</span>';
											} ?>
											</span>
											<?php if(isset($_GET['ty']) and in_array($_GET['ty'],array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20))) { ?>
											| &nbsp;&nbsp;<span style="margin-right:15px;">Fee Type: <?php print $feestype->getFeeTypeById($_GET['ty'])->feeTypeName; ?></span>
											<?php } else {
												print '| &nbsp;&nbsp;<span style="margin-right:15px;">Fee Type: '.$feestype->getFeeTypeById(1)->feeTypeName.'</span>';
											} ?>
											<?php if(isset($_GET['c']) and in_array($_GET['c'],array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20))) { ?>
											| &nbsp;&nbsp;<span style="margin-right:15px;">Class: <?php print $classes->getClassById($_GET['c'])->className; ?></span>
											<?php } else {
												print '| &nbsp;&nbsp;<span style="margin-right:15px;">Class: All Classes</span>';
											} ?>

										</div>
										<?php // } ?>
										<hr>
										
										<div class="box-header bg-red">
											<h3 class="box-title">
												All Invoices
											</h3>
										</div>
										
										<div class="tab-content">
										<div id="all" class="tab-pane active">
										<div id="hide-table">
											<div id="example1_wrapper" class="dataTables_wrapper form-inline" role="grid">
											
												<div class="display_all_results">Display the Results</div>
												<script>
												Display();
												function Display() {
													var year = $("#academicYear").val();
													var term = $("#term").val();
													var split = $("#split").val();
													var type = $("#feeTypeId").val();
													var classes = $("#classesID").val();
													$.ajax({
														type: "POST",
														data: "showcase&y="+year+"&t="+term+"&ty="+type+"&c="+classes+"&split="+split,
														url: "<?php print SITE_URL; ?>/z_call_invoice",
														success: function(response) {
															$(".display_all_results").html(response);
														}
													});
													
												}
												</script>											
											<table class="table table-striped table-bordered table-hover dataTable no-footer">
												<tr role="row" style="font-weight:bold;font-size:18px">
													<td width="40%" colspan="3"><strong>TOTALS</strong></td>
													<td width="15%"></td>
													<td width="10%"></td>
													<td width="8%"></td>
													<td width="8%"><?php// print $invoices->generateTotals("","LIMIT 5000","DESC"); ?></td>
													<td></td>
												</tr>
											</table>
										
											</div>
										</div>

										</div>
									</div>
									</div> <!-- nav-tabs-custom -->
									</div>
									
								</div>
							</div>
						</div><?php //body div ?>
					</div><?php //box div ?>
				</div><?php //col-sm-12 div ?>
			</div><?php //row div ?>
		</section>
	</aside>
		<script type="text/javascript">
            $(function() {
                $("#example1").dataTable();
                $('#example2').dataTable({
                    "bPaginate": true,
                    "bLengthChange": false,
                    "bFilter": false,
                    "bSort": true,
                    "bInfo": true,
                    "bAutoWidth": false
                });
            });
			function filterInvoice() {
				var year = $("#academicYear").val();
				var term = $("#term").val();
				var type = $("#feeTypeId").val();
				var split = $("#split").val();
				var classes = $("#classesID").val();
				
				window.location.href="<?php print SITE_URL; ?>/invoice?filter&y="+year+"&t="+term+"&ty="+type+"&c="+classes+"&split="+split;
			}
        </script>
<?php
//get the page footer to include
template_footer();
?>