<?php
//include the header of the website
require 'core/checkaccess.php';
$pageDescription = $site->getSiteDescription();
template_header('Home Page',$site->getSiteName());
//create a new object of the count model
$count = new CountModel;
$students = new Students;
$employees = new Employees;
$guardian = new Guardian;
?>

<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        

	  <div class="row">
		<div class="col-lg-3 col-xs-6">
			<div class="small-box ">
				<a class="small-box-footer" href="<?php print SITE_URL; ?>/student/index">
					<div class="icon bg-aqua" style="padding: 9.5px 18px 8px 18px;">
						<i class="fa fa-users"></i>
					</div>
					<div class="inner ">
						<h3>
							<?php print $count->TableCount('students', "where status='1'")->table_count; ?>
						</h3>
						<p>
							Students                    </p>
					</div>
				</a>
			</div>
		</div>

		<div class="col-lg-3 col-xs-6">
			<div class="small-box ">
				<a class="small-box-footer" href="<?php print SITE_URL; ?>/employee/index">
					<div class="icon bg-red" style="padding: 9.5px 18px 8px 18px;">
						<i class="fa fa-list"></i>
					</div>
					<div class="inner ">
						<h3>
							<?php print $count->TableCount('employee', "where status='1'")->table_count; ?>
						</h3>
						<p>
							Employees                    </p>
					</div>
				</a>
			</div>
		</div>

		<div class="col-lg-3 col-xs-6">
			<div class="small-box ">
				<a class="small-box-footer" href="<?php print SITE_URL; ?>/parents/index">
					<div class="icon bg-yellow">
						<i class="fa fa-user"></i>
					</div>
					<div class="inner ">
						<h3>
							<?php print $count->TableCount('guardian', "where status='1'")->table_count; ?>
						</h3>
						<p>
							Parents                    </p>
					</div>
				</a>
			</div>
		</div>

		<div class="col-lg-3 col-xs-6">
			<div class="small-box ">
				<a class="small-box-footer" href="<?php print SITE_URL; ?>/subject/index">
					<div class="icon bg-blue" style="padding: 9.5px 18px 8px 18px;">
						<i class="fa fa-sitemap"></i>
					</div>
					<div class="inner ">
						<h3>
							<?php print $count->TableCount('subjects')->table_count; ?>
						</h3>
					  <p>
						Subject
					</p>
					</div>
				</a>
			</div>
		</div>
	  </div>


 
		  <div class="row"> 
			<div class="col-sm-3">
					  <section class="panel">
				  <div class="profile-db-head">
					<a href="<?php print SITE_URL; ?>/profile/index">
					  <img src="<?php print SITE_IMAGE_PATH; ?>/site.png" alt="">            </a>

					<h1><?php print SITE_NAME; ?></h1>
					<p><?php print $_SESSION['Username']; ?></p>

				  </div>
				  <table class="table table-hover">
					  <tbody>
						  <tr>
							<td>
							  <i class="glyphicon glyphicon-user" style="color:#FDB45C;"></i>
							</td>
							<td>Username</td>
							<td><?php print $_SESSION['Username']; ?></td>
						  </tr>
						  <tr>
							  <td>
								<i class="fa fa-envelope" style="color:#FDB45C;"></i>
							  </td>
							  <td>Email</td>
							<td><?php print $site->getSiteEmail(); ?></td>
						  </tr>
						  <tr>
							<td>
							  <i class="fa fa-phone" style="color:#FDB45C;"></i>
							</td>
							<td>Phone</td>
							<td><?php print $site->getSitePhone(); ?></td>
						  </tr>
						  <tr>
							<td>
							  <i class=" fa fa-globe" style="color:#FDB45C;"></i>
							</td>
							<td>Address</td>
							<td><?php print $site->getSiteAddress; ?></td>
						  </tr>
					  </tbody>
				  </table>
				</section>
				  </div>

			<div class="col-sm-9">
			  <div class="box">
				<div class="box-header" style="background-color:#FDB45C;">
					<h3 class="box-title">
						Students
					</h3>
				</div>

				<div class="box-body" style="padding: 0px;">
					<table class="table table-hover">
						<thead>
							<tr>
								<td>ID</td>
								<td>FULLNAME</td>
								<td>CLASS</td>
								<td>GUARDIAN/PHONE</td>
								<td>PHONE</td>
								<td>ACTION</td>
							</tr>
						</thead>
					  <tbody>
						<?php print $students->getStudents("", "LIMIT 5", "DESC"); ?>
						</tbody>
					</table>
				</div>
				

			  </div>
			</div>
			<div class="col-sm-9" style="float:right">
			  <div class="box">
				<div class="box-header" style="background-color:#FDB45C;">
					<h3 class="box-title">
						Employees
					</h3>
				</div>

				<div class="box-body" style="padding: 0px;">
					<table class="table table-hover">
						<thead>
							<tr>
								<td>ID</td>
								<td>FULLNAME</td>
								<td>DESIGNATION</td>
								<td>QUALIFICATION</td>
								<td>CLASS</td>
								<td>PHONE</td>
								<td>ACTION</td>
							</tr>
						</thead>
					  <tbody>
						<?php print $employees->getEmployees("", "LIMIT 5", "DESC"); ?>
						</tbody>
					</table>
				</div>
			
			  </div>
			</div>
			<div class="col-sm-9" style="float:right">
			  <div class="box">
				<div class="box-header" style="background-color:#FDB45C;">
					<h3 class="box-title">
						Parents / Guardians
					</h3>
				</div>

				<div class="box-body" style="padding: 0px;">
					<table class="table table-hover">
						<thead>
							<tr>
								<td>ID</td>
								<td>FULLNAME</td>
								<td>WARD</td>
								<td>PHONE</td>
								<td>ACTION</td>
							</tr>
						</thead>
					  <tbody>
						<?php print $guardian->getGuardians("", "LIMIT 5", "DESC"); ?>
						</tbody>
					</table>
				</div>
			
			  </div>
			</div>

		  </div>

 
                    </div>
                </div>
            </section>
        </aside>
	
<?php
//get the page footer to include
template_footer();
?>