<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Salary Settings - Create',$site->getSiteName());
//create a new object of the count model
$msg_log = '';
$models = new Models;
?>
<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-money"></i>Employee Salary Settings</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?php print SITE_URL; ?>/payhead-add/index"> Pay Heads</a></li>
            <li class="active">Add new Salary Settings</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            <div class="col-sm-4">
			
				<div id="results"></div>
				<form class="form-horizontal" role="form" action="javascript:insertSalarySettings();" method="post">

                    <div class="form-group">
						<label for="payhead" class="col-sm-4 control-label">
                           Designation
						</label>
                        <div class="col-sm-8">
                           <select tabindex="-1" required="required" name="designID" id="designID" class="form-control guargianID select2-offscreen">
								<option value="0">Select Designation</option>
								<?php
								$sql2 = $db->select("SELECT * FROM `designation`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['name']}</option>";
									}
								}
								?>
							</select>
                        </div>
                        <span class="col-sm-3 control-label">
                        </span>
                    </div>
					<div class="form-group" id="employee_name">
						<label for="amount" class="col-sm-4 control-label">
                            Employee
						</label>
                        <div class="col-sm-8">
                            <div id="employee_list"></div>
                        </div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
					 <div class="form-group">
						<label for="payhead" class="col-sm-4 control-label">
                           Payment Type
						</label>
                        <div class="col-sm-8">
                           <select tabindex="-1" required="required" name="payhead" id="payhead" class="form-control guargianID select2-offscreen">
								<option value="0">Select Payment Type</option>
								<?php
								$sql2 = $db->select("SELECT * FROM `payhead`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['name']}</option>";
									}
								}
								?>
							</select>
                        </div>
                        <span class="col-sm-3 control-label">
                        </span>
                    </div>
					<div class="form-group">
						<label for="amount" class="col-sm-4 control-label">
                            Amount
						</label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" style="" id="amount" name="amount">
                        </div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
					<div class="form-group">
                        <div class="col-sm-offset-4 col-sm-8">
							<input class="btn btn-success" value="Insert Salary Setting" name="" type="submit">
                        </div>
                    </div>
				</form>
            </div>
			<div class="col-sm-8">
				<div id="loadSalariesView"></div>
			</div>
			<script>
			$("#designID").focus();
			$("#employee_name").hide();
			
			loadSalaries();
			function loadSalaries() {
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_call_salary_settings",
					data: "loadSalaries&call_all",
					dataType: "html",
					success: function(data) {
					   $('#loadSalariesView').html(data);
					}
				});
			}
			$('#designID').change(function(event) {
				var designID = $(this).val();
				if(designID == '0') {
					$(designID).val(0);
				} else {
					$.ajax({
						type: 'POST',
						url: "<?php print SITE_URL; ?>/z_call_employees",
						data: "designID=" + designID,
						dataType: "html",
						success: function(results) {
							$("#employee_name").show();
							$('#employee_list').html(results);
						}
					});
				}
			});
			
			function insertSalarySettings() {
				var designID = $("#designID").val();
				var amount = $("#amount").val();
				var employeeID = $("#employeeID").val();
				var payhead = $("#payhead").val();
				
				loadSalaries();
				
				if(designID==0) {
					$("#results").html("<div class='btn btn-danger'>Sorry! Please select designation.</div><br><br>");
				} else if(employeeID==0) {
					$("#results").html("<div class='btn btn-danger'>Sorry! Please select employee.</div><br><br>");
				} else if(employeeID=="undefined") {
					$("#results").html("<div class='btn btn-danger'>Sorry! Please select employee.</div><br><br>");
				} else if(payhead==0) {
					$("#results").html("<div class='btn btn-danger'>Sorry! Please select employee pay head.</div><br><br>");
				} else {
					$('#results').html('<div id="loading-bar" style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
					$.ajax({
						type: 'POST',
						url: "<?php print SITE_URL; ?>/z_insert_salary_settings",
						data: "designID=" + designID+"&amount="+amount+"&employeeID="+employeeID+"&payhead="+payhead,
						dataType: "html",
						success: function(results) {
							alert("Congrats! Salary Settings was successfully inserted.");
							location.reload();
						}
					});
				}
			}
			</script>
        </div>
    </div>
</div>
 
                    </div>
                </div>
            </section>
        </aside>
	  
<?php
//get the page footer to include
template_footer();
?>