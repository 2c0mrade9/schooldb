<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Students',$site->getSiteName());
//create a new object of the count model
$invoice = new Invoices;
?>

		<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
					<div class="box">
						<div class="box-header bg-purple">
							<h3 class="box-title"><i class="fa fa-users"></i> List Fees Payments</h3>

						   
							<ol class="breadcrumb">
								<li><a href="<?php print SITE_URL; ?>"><i class="fa fa-laptop"></i> Dashboard</a></li>
								<li><a href="<?php print SITE_URL; ?>/accounts"><i class="fa fa-money"></i> Accounts</a></li>
								<li class="active">Fees Payments</li>
							</ol>
						</div><!-- /.box-header -->
						<!-- form start -->
						<div class="box-body">
							<div class="row">
								<div class="col-sm-12">

									<h5 class="page-header">
										<a class="btn btn-success" href="<?php print SITE_URL; ?>/invoice-create">
											<i class="fa fa-plus"></i> 
											Record Fees Payment
										</a>
									</h5>
									
									<div class="col-sm-6 col-sm-offset-3 list-group" >
										<div class="list-group-item list-group-item-warning bg-aqua">
											<form style="" class="form-horizontal" role="form" method="post">  
												<div class="form-group">              
													<label for="classesID" class="col-sm-2 col-sm-offset-2 control-label">
														Class
													</label>
													<div class="col-sm-6">
														<select name="classesID" id="classesID" onchange="window.location.href=this.value" class="form-control">
														<option value="0">Select Class</option>
														<option value="<?php print SITE_URL."/fees-payments/view-all"; ?>">View All Students</option>
														<?php
														$db=new Database;
														$sql = $db->select("SELECT * FROM `class`");
														if($db->scount($sql) > 0) {
															while($res=$sql->fetch_assoc()){
																print "<option value='".SITE_URL."/fees-payments/".$res['id']."'>{$res['name']}</option>";
															}
														}
														?>
														</select>
													</div>
												</div>
											</form>
										</div>
									</div>
									
									<div class="col-sm-12">

									<div class="nav-tabs-custom">
										<div class="box-header bg-red">
											<h3 class="box-title">
												All Students
											</h3>
										</div>
										
										<?PHP
										if(isset($ACTION[1])) {
										?>
										<div class="tab-content">
										<div id="all" class="tab-pane active">
										<?PHP
										if($ACTION[1] != "index") {
										?>
										<div id="hide-table">
											<div id="example1_wrapper" class="dataTables_wrapper form-inline" role="grid">
											<table aria-describedby="example1_info" id="example1" class="table table-striped table-bordered table-hover dataTable no-footer">
												<thead>
												<tr role="row">
													<td width="5%">#</td>
													<td width="10%">Fee Type</td>
													<td width="10%">Date</td>
													<td width="15%">Payment Status</td>
													<td width="15%">Student</td>
													<td width="10%">Due Amount</td>
													<td width="8%">Amount</td>
													<td width="8%">Balance</td>
													<td>ACTION</td>
												</tr>
												</thead>

												<tbody aria-relevant="all" aria-live="polite" role="alert">
													<?php
													if(is_numeric($ACTION[1])) {
														print $invoice->getStudentsFeesPayments("`class`='{$ACTION[1]}'", "LIMIT 5000", "DESC"); 
													} else if($ACTION[1] == "view-all") {
														print $invoice->getStudentsFeesPayments("", "LIMIT 5000", "DESC"); 
													}
													?>
												</tbody>
											</table>
											</div>
										</div>
										<?php } ?>
										</div>
									</div>
										<?php
										} else {
											PageNotFound();
										}
										?>

									</div> <!-- nav-tabs-custom -->
									</div>
									
								</div>
							</div>
						</div><?php //body div ?>
					</div><?php //box div ?>
				</div><?php //col-sm-12 div ?>
			</div><?php //row div ?>
		</section>
	</aside>
		<script type="text/javascript">
            $(function() {
                $("#example1").dataTable();
                $('#example2').dataTable({
                    "bPaginate": true,
                    "bLengthChange": false,
                    "bFilter": false,
                    "bSort": true,
                    "bInfo": true,
                    "bAutoWidth": false
                });
            });
        </script>
<?php
//get the page footer to include
template_footer();
?>