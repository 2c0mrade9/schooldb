<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Subject - Add',$site->getSiteName());
//create a new object of the count model
$models = new Models;
$msg_log = '';
//update the class information
if(isset($_POST['addSubject'])) {
	$teacher = $db->cleanData($_POST['teacher']);
	$subject = ucwords($db->cleanData($_POST['subject']));
	$class = $db->cleanData($_POST['class']);
	$codecheck = $models->create_slug($class."-".strtolower($subject)."-".date("Y"));
	//checkdate
	$check = $db->select("SELECT code FROM `subjects` WHERE `code`='$codecheck'");
	if($db->scount($check) > 0) {
		$msg_log .= "<div class='btn btn-danger'>Sorry! A similar subject with the same code already exists in the database.</div><br><br>";
	} else {
		if(is_numeric($class)) {
			$insert = $db->insert("INSERT INTO `subjects` (code,year,name,class,teacher) VALUES (
				'$codecheck','".date("Y")."','$subject','$class','$teacher'
			)");
		} else if($class == "all_classes") {
			$classlist = array(1,2,3,4,5,6,7,8,9);
			foreach($classlist as $classes) {
				$code = "ac".$codecheck;
				$insert = $db->insert("INSERT INTO `subjects` (code,year,name,class,teacher) VALUES (
					'$code','".date("Y")."','$subject','$classes','$teacher'
				)");
			}
		} else if($class == "all_jhs") {
			$classlist = array(7,8,9);
			foreach($classlist as $classes) {
				$code = "aj".$codecheck;
				$insert = $db->insert("INSERT INTO `subjects` (code,year,name,class,teacher) VALUES (
					'$code','".date("Y")."','$subject','$classes','$teacher'
				)");
			}
		} else if($class == "all_lower_primary") {
			$classlist = array(1,2,3);
			foreach($classlist as $classes) {
				$code = "al".$codecheck;
				$insert = $db->insert("INSERT INTO `subjects` (code,year,name,class,teacher) VALUES (
					'$code','".date("Y")."','$subject','$classes','$teacher'
				)");
			}
		} else if($class == "all_upper_primary") {
			$classlist = array(4,5,6);
			foreach($classlist as $classes) {
				$code = "au".$codecheck;
				$insert = $db->insert("INSERT INTO `subjects` (code,year,name,class,teacher) VALUES (
					'$code','".date("Y")."','$subject','$classes','$teacher'
				)");
			}
		} else if($class == "all_primary") {
			$classlist = array(1,2,3,4,5,6);
			foreach($classlist as $classes) {
				$code = "ap".$codecheck;
				$insert = $db->insert("INSERT INTO `subjects` (code,year,name,class,teacher) VALUES (
					'$code','".date("Y")."','$subject','$classes','$teacher'
				)");
			}
		}
		if($insert) {
			$msg_log .= "<div class='btn bg-green'>Congrats! Subject information was successfully inserted.</div><br><br>";
		} else {
			$msg_log .= "<div class='btn btn-danger'>Sorry! There was an error inserting the Subject information.</div><br><br>";
		}
	}
	
}
?>
<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-comments"></i> Subject</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?php print SITE_URL; ?>/subject/index"> Subjects</a></li>
            <li class="active">Add new Subject</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            <div class="col-sm-5">
			
				<?php print $msg_log; ?>
				<form class="form-horizontal" role="form" method="post">
                    <div class="form-group">                        <label for="classesID" class="col-sm-3 control-label">
                            Class Name                        </label>
                        <div class="col-sm-8">
                           <select name="class" tabindex='-1' id="classId" class="form-control guargianID">
							<option selected="selected" value="0">Select Class</option>
							<option value="all_classes">All Classes (Class 1 - JHS 3)</option>
							<option value="all_jhs">JHS 1 - JHS 3</option>
							<option value="all_primary">Primary 1 - Primary 6</option>
							<option value="all_lower_primary">Primary 1 - Primary 3</option>
							<option value="all_upper_primary">Primary 4 - Primary 6</option>
							<option value="0">----------------------------------------------------</option>
							<?php
								$sql = $db->select("SELECT * FROM `class`");
								if($db->scount($sql) >0) {
									while($res=$sql->fetch_assoc()){
										print "<option value='".$res['id']."'>{$res['name']}</option>";
									}
								}
								?>
							</select>
							</div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
					<div class="form-group">                        <label for="subject" class="col-sm-3 control-label">
                            Subject Name                        </label>
                        <div class="col-sm-8">
                            <input class="form-control" required="required" placeholder="Please enter subject name" onkeyup="checkClass();" id="subject" name="subject" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
                    <div class="form-group">                        <label for="teacherID" class="col-sm-3 control-label">
                            Teacher Name                        </label>
                        <div class="col-sm-8">
                        <select name="teacher" tabindex='-1' id="teacher" class="form-control guargianID">
							<option selected="selected" value="0">Select Teacher</option>
							<?php
								$sql2 = $db->select("SELECT * FROM `employee`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['fullname']}</option>";
									}
								}
								?>
							</select>
						</div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
        
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-7">
                            <input class="btn btn-success" onclick="generate_code();" id="addButton" value="Add subject" name="addSubject" type="submit">
                        </div>
                    </div>

                </form>
				
				

						</div>
						<div class="col-sm-7">
							<div id="getSubjectsAll"></div>
						</div>
					</div>
				</div>
			</div>
 
                    </div>
                </div>
            </section>
        </aside>
		
		<script>
		$("#subject").focus();
		getAllSubjects();
		function getAllSubjects() {
		$.ajax({
			type: 'POST',
			url: "<?php print SITE_URL; ?>/z_call_subjects",
			data: "getSubjects&call_all",
			dataType: "html",
				success: function(data) {
				   $('#getSubjectsAll').html(data);
				}
			});
		}
		$('#classId').change(function(event) {
			var classId = $(this).val();
			$("#subject").val("");
			if(classId === '0') {
				$('#subject_code').val(0);
			} else {
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_subject_code",
					data: "className&classId=" + classId,
					success: function(results) {
					   $('#subject_code').val(results);
					   $('#generateKey').removeAttr("disabled","disabled");
					}
				});
			}
		});
		</script>
	  
<?php
//get the page footer to include
template_footer();
?>