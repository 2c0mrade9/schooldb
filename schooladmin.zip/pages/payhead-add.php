<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('PayHead - Add',$site->getSiteName());
//create a new object of the count model
$msg_log = '';
$models = new Models;
//update the class information
if(isset($_POST['insertPayhead'])) {
	$payhead = ucwords($db->cleanData($_POST['payhead']));
	$note = ucwords($db->cleanData($_POST['note']));
	$slug = $models->create_slug($payhead);
	//check if all fields are filled
	$check = $db->select("SELECT slug FROM `payhead` WHERE `slug`='$slug'");
	if($db->scount($check) > 0) {
		$msg_log .= "<div class='btn btn-danger'>Sorry! A similar Pay Head already exists in the database.</div><br><br>";
	} else {
		$insert = $db->insert("INSERT INTO `payhead` (name,slug,note) VALUES (
			'$payhead','$slug','$note'
		)");
		
		if($insert) {
			$msg_log .= "<div class='btn bg-green'>Congrats! Pay Head was successfully inserted.</div><br><br>";
		} else {
			$msg_log .= "<div class='btn btn-danger'>Sorry! There was an error inserting the Payhead.</div><br><br>";
		}
		$payhead = "";	
	}
}
?>
<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-money"></i>Employee Payhead</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?php print SITE_URL; ?>/payhead-add/index"> Pay Heads</a></li>
            <li class="active">Add new Payhead</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            <div class="col-sm-5">
			
				<?php print $msg_log; ?>
				<form class="form-horizontal" role="form" method="post">

                    <div class="form-group">
						<label for="payhead" class="col-sm-4 control-label">
                            Employee Pay Type/Head
						</label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" id="payhead" name="payhead" type="text">
                        </div>
                        <span class="col-sm-3 control-label">
                        </span>
                    </div>
					<div class="form-group">
					<label for="note" class="col-sm-4 control-label">
                            Description                        </label>
                        <div class="col-sm-8">
                            <textarea class="form-control" style="resize:none;height:100px;" id="note" name="note"></textarea>
                        </div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
					<div class="form-group">
                        <div class="col-sm-offset-4 col-sm-8">
							<input class="btn btn-success" value="Insert PayHead" name="insertPayhead" type="submit">
                        </div>
                    </div>
				</form>
            </div>
			<div class="col-sm-7">
				<div id="payheadview"></div>
			</div>
			<script>
			$("#payhead").focus();
			
			payhead();
			function payhead() {
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_call_payhead",
					data: "payhead&call_all",
					dataType: "html",
					success: function(data) {
					   $('#payheadview').html(data);
					}
				});
			}
			</script>
        </div>
    </div>
</div>
 
                    </div>
                </div>
            </section>
        </aside>
	  
<?php
//get the page footer to include
template_footer();
?>