<?php 
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$models = new Models;
require 'core/checkaccess.php';

if(isset($_POST['designID']) and isset($_POST['employeeID']) and isset($_POST['amount']) and isset($_POST['payhead']) and is_numeric($_POST['payhead'])) {
	if(is_numeric($_POST['designID']) and is_numeric($_POST['amount'])) {
		
		$balance = "";
		$d = $db->cleanData($_POST['designID']);
		$m = $db->cleanData($_POST['months']);
		$e = $db->cleanData($_POST['employeeID']);
		$a = $db->cleanData($_POST['amount']);
		$p = $db->cleanData($_POST['payhead']);
		$y = $db->cleanData($_POST['year']);
		$ay = AC_YEAR;
		$admin = $_SESSION['Username'];
		//check if the user has a salary settings table
		$check = $db->select("SELECT * FROM `salary_settings` WHERE `designation`='$d' AND `payhead`='$p' AND `employeeid`='$e'");
		if($db->scount($check) > 0) {
			$result = $check->fetch_assoc();
			//fetch the balance in the employee salary settings table
			$bal = $result['balance'];
			if($bal > 0) {
				$balance = ($result['amount'] - $a) + $bal;
			} else {
				$balance = $result['amount'] - $a;
			}
			//update the salary settings table
			$db->update("UPDATE `salary_settings` SET `balance`='$balance' WHERE `designation`='$d' AND `payhead`='$p' AND `employeeid`='$e' LIMIT 1");
			//insert the data inside the database payroll table
			$insert = $db->insert("INSERT INTO `payroll` (month,acc_year,designation,payhead,employeeid,amount,year,rdate,rname) VALUES (
				'$m','$ay','$d','$p','$e','$a','$y',now(),'$admin'
			)") or trigger_error($db->db_error());
			
			if($insert) {
				print "<div class='btn bg-green'>Congrats! Salary has been issued successfully.</div><br><Br>";
			} else {
				print "<div class='btn btn-danger'>Sorry! There was an error recording the Salary Payment.</div><br>";
			}
		} else {
			print "<div class='btn btn-danger'>Sorry! You have not set the Salary Settings for this Employee.<br><Br>
				<a href='".SITE_URL."/salary-settings?add_new'>Add Salary Settings Now?</a>
			</div><Br><Br>";
		}
								
	} else {
		print "<div class='btn btn-danger'>Sorry! You have supplied an invalid inputs. Amount must be only Numerics (0-9)</div><br><br>";
	}
} else {
	print "<div class='btn btn-danger'>Sorry! You have supplied an invalid inputs.</div><Br><Br>";
}

?>