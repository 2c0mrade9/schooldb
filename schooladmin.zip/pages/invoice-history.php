<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Invoice',$site->getSiteName());
//create a new object of the count model
$invoices = new Invoices;
$student = new Students;
$feestype = new FeesType;
$classes = new Classes;
?>
	<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
					<div class="box">
						<div class="box-header bg-purple">
							<h3 class="box-title"><i class="fa fa-users"></i> Invoices</h3>
							<?php if(isset($ACTION[1])) { ?>
								<a href="<?php print SITE_URL; ?>/invoice-create/<?php print $ACTION[1]; ?>" class="btn-cs btn-sm-cs" style="text-decoration: none;margin-top:10px;" role="button"><i class="fa fa-credit-card"></i> Record New Payments</a>
							<?php } ?>
							<ol class="breadcrumb">
								<li><a href="<?php print SITE_URL; ?>"><i class="fa fa-laptop"></i> Dashboard</a></li>
								<li class="active"><a href="<?php print SITE_URL; ?>/invoice/index">List Invoices</a></li>
							</ol>
						</div><!-- /.box-header -->
						<?php if(isset($_GET['n']) and !isset($ACTION[1]) and isset($_GET['ty']) and isset($_GET['cid']) and isset($_GET['tyid']) and $student->getStudentById($_GET['n'])->stuResult==true) { ?>
						<!-- form start -->
						<div class="box-body">
							<div class="row">
								<div class="col-sm-12">

									<h5 class="page-header">
										<a href="<?php print SITE_URL; ?>/invoice-create">
											<i class="fa fa-plus"></i> 
											Add an Invoice/New Payment
										</a>
									</h5>
									
						
									<div class="col-sm-8 invoice-col">
		   
										<address style="font-size:15px;">
											<strong>Fullname :</strong> :<?php print $student->getStudentById($_GET['n'])->studentSname; ?> <?php print $student->getStudentById($_GET['n'])->studentFname; ?><br>
											<strong>Class :</strong> <?php print $student->getStudentById($_GET['n'])->studentClass2; ?><br>
											<strong>Payment Type :</strong> <?php print $db->cleanData($_GET['ty']); ?><br>
											<strong>Academic Year / Term :</strong> 
											<?php print $db->cleanData($_GET['y']); ?> -
											<?php 
												if($db->cleanData($_GET['t']) == 1)
													print 'Term One';
												elseif($db->cleanData($_GET['t']) == 2)
													print 'Term Two';
												elseif($db->cleanData($_GET['t']) == 3)
													print 'Term Three';
												elseif($db->cleanData($_GET['t']) == 4)
													print 'Term Four';
												else 
													print 'Term One';
											?><br>
										</address>
									</div><!-- /.col -->
									<div class="col-sm-12">
									
									<div class="nav-tabs-custom">
										<div class="box-header bg-red" style="font-size:15px;">
											<h3 class="box-title">
												Diplaying  Payment History.
											</h3>
										</div>
										
										<div class="tab-content">
										<div id="all" class="tab-pane active">
										<div id="hide-table">
											<div id="example1_wrapper" class="dataTables_wrapper form-inline" role="grid">
											<table aria-describedby="example1_info" id="example1" class="table table-striped table-bordered table-hover dataTable no-footer">
												<thead>
												<tr role="row">
													<td width="5%">#</td>
													<td width="10%">Fee Type</td>
													<td width="13%">Date</td>
													<td width="15%">Payment Status</td>
													<td width="15%">Student</td>
													<td width="10%">Amount Due</td>
													<td width="7%">Amount Paid</td>
													<td>Balance</td>
													<td>ACTION</td>
												</tr>
												</thead>

												<tbody aria-relevant="all" aria-live="polite" role="alert">
													<?php print $invoices->getInvoices("`feetypeid`='{$_GET['tyid']}' AND 
														`studentunq`='{$_GET['n']}' AND", "LIMIT 5000", "DESC"); ?>
												</tbody>
											</table>
											<table class="table table-striped table-bordered table-hover dataTable no-footer">
												<tr>
													<th class="col-sm-8 col-xs-8" width="15%">TOTAL PAYMENT (GHC)</th>
													<th align="right">GHc<?php print $invoices->generatePaymentStatus($_GET['t'],$_GET['y'],$_GET['n'],$_GET['cid'],$_GET['tyid'])->totalPaymentMade; ?></th>
												</tr>
											</table>
											</div>
										</div>

										</div>
									</div>
									</div> <!-- nav-tabs-custom -->
									</div>
									
								</div>
							</div>
						</div><?php //body div ?>
						
						<?php
							}elseif(isset($ACTION[1]) and $student->getStudentById($ACTION[1])->stuResult == true) {
						?>
							<br clear="all">
							<?php if(isset($_GET['ty']) || isset($_GET['y'])) { ?>
								<a href="<?php print SITE_URL; ?>/invoice-history/<?php print $ACTION[1]; ?>" class="btn-cs btn-sm-cs" style="text-decoration: none;margin-top:10px;" role="button"><i class="fa fa-refresh"></i> Refresh Page</a>
							<?php } ?>
							<div class="">
								<div class="" style="padding-left:10px;">
								<hr>
								<h3 style="font-size:15px;">
								<strong>Fullname:</strong> <?php print $student->getStudentById($ACTION[1])->studentSname; ?>
								<?php print $student->getStudentById($ACTION[1])->studentFname; ?><br>
								<strong>Class:</strong> <?php print $student->getStudentById($ACTION[1])->studentClass2; ?><br>
								<strong>Payment Type:</strong> <?php print $db->cleanData($ACTION[1]); ?><br>
								<strong>Academic Year/Term:</strong> 
								<?php print $db->cleanData($site->getSiteAcademicYear); ?> -
								<?php 
									if($db->cleanData($site->getSiteTerm()) == 1)
										print 'Term One';
									elseif($db->cleanData($site->getSiteTerm()) == 2)
										print 'Term Two';
									elseif($db->cleanData($site->getSiteTerm()) == 3)
										print 'Term Three';
									elseif($db->cleanData($site->getSiteTerm()) == 4)
										print 'Term Four';
									else 
										print 'Term One';
								?><br>
								</h3>
								</div>
								<hr>
								<div class="nav-tabs-custom" style="padding-left:10px;">
									
									
									<div class="form-group">
										<h4 for="feetype">
											<strong>Filter Invoice:</strong>
										</h4>
										<div class="col-sm-3">
											<select tabindex="-1" name="academicYear" id="academicYear" class="form-control guargianID select2-offscreen">
												<?php
												$currentYear = date("Y")-4;
												if(isset($_GET['y']) and !empty($_GET['y'])) {
													print "<option value='".$_GET['y']."' selected='selected'>{$_GET['y']}</option>";
												}
												print "<option value='".date('Y')."/".(date('Y')+1)."'>Select Academic Year</option>";
												for($i = 0; $i < 10; $i++) {
													$currentYear++;
													$previousYear = $currentYear - 1;
													if(($previousYear."/".$currentYear) == ''.(date("Y")).'/'.(date("Y")+1).'') {
														if(isset($_GET['y']) and !empty($_GET['y']))
															print "<option value='".($previousYear)."/".($currentYear)."'>".($previousYear)."/".($currentYear)."</option>";
														else
															print "<option value='".($previousYear)."/".($currentYear)."' selected='selected'>".($previousYear)."/".($currentYear)."</option>";
													} else
														print "<option value='".($previousYear)."/".($currentYear)."'>".($previousYear)."/".($currentYear)."</option>";
												}
												?>
											</select>
										</div>
										<div class="col-sm-3">

										<select tabindex="-1" name="term" id="term" class="form-control guargianID select2-offscreen">
											<option <?php if(isset($_GET['t']) and $_GET['t'] == 0) print 'selected="selected"'; ?> value="0">Select Term</option>
											<option <?php if(isset($_GET['t']) and $_GET['t'] == 1) print 'selected="selected"'; ?> value="1">Term One</option>
											<option <?php if(isset($_GET['t']) and $_GET['t'] == 2) print 'selected="selected"'; ?> value="2">Term Two</option>
											<option <?php if(isset($_GET['t']) and $_GET['t'] == 3) print 'selected="selected"'; ?> value="3">Term Three</option>
											<option <?php if(isset($_GET['t']) and $_GET['t'] == 4) print 'selected="selected"'; ?> value="4">Term Four</option>
										</select>
										</div>
										<div class="col-sm-3">
											<select tabindex="-1" name="feeTypeId" id="feeTypeId" class="form-control guargianID select2-offscreen">
												<option value="0">Select Fees Type</option>
												<?php
												if(isset($_GET['ty']) and is_numeric($_GET['ty'])) {
													$type = $_GET['ty'];
													$typesql3 = $db->select("SELECT * FROM `finance_feestype` WHERE `id`='$type'");
													if($db->scount($typesql3) >0) {
														while($tres3=$typesql3->fetch_assoc()){
															print "<option value='".$tres3['id']."' selected='selected'>{$tres3['type']}</option>";
														}
													}
												}
												$sql3 = $db->select("SELECT * FROM `finance_feestype`");
												if($db->scount($sql3) >0) {
													while($res3=$sql3->fetch_assoc()){
														print "<option value='".$res3['id']."'>{$res3['type']}</option>";
													}
												}
												?>
											</select>
										</div>
										
										<div class="col-sm-3" align="right">
											<input class="btn btn-success" value="Filter Invoice" onclick="filterInvoice(); " type="submit">
										</div>

										
									<span class="col-sm-4 control-label"></span>
									</div>
								
								<br clear="all">
								<hr>
								<?php
								if(isset($_GET['ty']) and is_numeric($_GET['ty']))
									$add_where = "`id`='{$_GET['ty']}' AND ";
								else
									$add_where = "";
								
								$sql = $db->select("SELECT * FROM `finance_feestype` WHERE $add_where `status`='1'");
								if($db->scount($sql) > 0) {
									while($result = $sql->fetch_assoc()) {
								?>
								<?php if(isset($_GET['filter'])) { ?>
									<div style="padding-left:5px;font-size:15px;font-weight:bolder;font-family:arial" class="box-title">
										<?php if(isset($_GET['y'])) { ?>
										<span style="margin-right:15px;">Academic Year: <?php print $_GET['y']; ?></span>
										<?php } ?>
										<?php if(isset($_GET['t'])) { ?>
										| &nbsp;&nbsp;<span style="margin-right:15px;">Academic Term: 
										<?php if($_GET['t']==1) print 'One'; elseif($_GET['t'] == 2) print 'Two'; elseif($_GET['t'] == 3) print 'Three'; elseif($_GET['t'] == 4) print 'Four'; else print 'All Terms'; ?>
										</span>
										<?php if(isset($_GET['ty']) and in_array($_GET['ty'],array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20))) { ?>
										| &nbsp;&nbsp;<span style="margin-right:15px;">Fee Type: <?php print $feestype->getFeeTypeById($_GET['ty'])->feeTypeName; ?></span>
										<?php } ?>
										
										<?php } ?>
									</div>
									<hr>
								<?php } ?>
								<div class="nav-tabs-custom">
									<div class="box-header bg-red" style="font-size:15px;">
										<h2 class="box-title">
											Diplaying <strong><?php print $result['type']; ?></strong> Payment History. 
											<a title="Click to view all <?php print $result['type']; ?> payments" class="btn bg-green" data-placement="top" href="<?php print SITE_URL."/invoice-history/".$ACTION[1]; ?>/?t=<?php print $site->getSiteTerm; ?>&y=<?php print $site->getSiteAcademicYear; ?>&ty=<?php print $result['id']; ?>&filter">VIEW ALL</a>
										</h2>
									</div>
										
									<div class="tab-content">
									<div id="all" class="tab-pane active">
									<div id="hide-table">
										<div id="example1_wrapper" class="dataTables_wrapper form-inline" role="grid">
										<table aria-describedby="example<?php print $result['id']; ?>_info" id="example<?php print $result['id']; ?>" class="table table-striped table-bordered table-hover dataTable no-footer">
											<thead>
											<tr role="row">
													<td width="5%">#</td>
													<td width="10%">Fee Type</td>
													<td width="13%">Date</td>
													<td width="15%">Payment Status</td>
													<td width="20%">Student</td>
													<td width="10%">Amount Due</td>
													<td width="7%">Amount Paid</td>
													<td>Balance</td>
													<td>ACTION</td>
												</tr>
											</thead>
												<tbody aria-relevant="all" aria-live="polite" role="alert">
													<?php 
													if(isset($_GET['filter']) and isset($_GET['y']) and isset($_GET['t']) and isset($_GET['ty'])) {
														if(is_numeric($_GET['t']) and is_numeric($_GET['ty'])) {
															if($_GET['t'] == 0 and $_GET['ty'] == 0)
																print $invoices->getInvoices("`studentunq`='{$ACTION[1]}' AND `academicyear`='{$_GET['y']}' AND `term`='all_terms'", "LIMIT 5000", "DESC", "true", "true");
															elseif($_GET['t'] != 0 and $_GET['ty'] == 0)
																print $invoices->getInvoices("`studentunq`='{$ACTION[1]}' AND `academicyear`='{$_GET['y']}' AND `term`='{$_GET['t']}'", "LIMIT 5000", "DESC", "true", "true");
															elseif($_GET['t'] != 0 and $_GET['ty'] != 0)
																print $invoices->getInvoices("`feetypeid`='{$_GET['ty']}' AND `studentunq`='{$ACTION[1]}' AND `academicyear`='{$_GET['y']}' AND `term`='{$_GET['t']}'", "LIMIT 5000", "DESC", "true", "true");
															elseif($_GET['t'] == 0 and $_GET['ty'] != 0)
																print $invoices->getInvoices("`feetypeid`='{$_GET['ty']}' AND `studentunq`='{$ACTION[1]}' AND `academicyear`='{$_GET['y']}'", "LIMIT 5000", "DESC", "true", "true");
														} else {
															print '<tr><td colspan="8">Sorry! You have parsed an invalid query.</td></tr>';
														}
													} else {
														print $invoices->getInvoices("`feetypeid`='{$result['id']}' AND `studentunq`='{$ACTION[1]}'", "LIMIT 5000", "DESC", "true", "true");
													}
													?>
												</tbody>
										</table>
										
										<?php
										if(isset($_GET['ty']) and $_GET['ty']==1) { ?>
										<table class="table table-striped table-bordered table-hover dataTable no-footer">
											<tr>
												<th class="col-sm-8 col-xs-8" width="15%">AMOUNT DUE (GHC)</th>
												<td colspan="7" style="font-weight:bolder">GHc <?php print $classes->getClassById($student->getStudentById($ACTION[1])->studentClassR)->classFees; ?></td>
											</tr>
										</table>
										<?php } ?>
										<table class="table table-striped table-bordered table-hover dataTable no-footer">
											<tr>
												<th class="col-sm-8 col-xs-8" width="15%">TOTAL PAYMENT (GHC)</th>
												<th align="right">GHc
												<?php
												if(isset($_GET['y']) and !empty($_GET['y']))
													$year = $db->cleanData($_GET['y']);
												else
													$year = date('Y')."/".(date('Y')+1);
												
												if(isset($_GET['ty']) and is_numeric($_GET['ty']))
													$feetyp=$_GET['ty'];
												else
													$feetyp = $result['id'];
												
												if(isset($_GET['t']) and is_numeric($_GET['t']))
													$termCurrent=$_GET['t'];
												else
													$termCurrent = $site->getSiteTerm();
												
												print $invoices->generatePaymentStatus($termCurrent,$year,$ACTION[1],$student->getStudentById($ACTION[1])->studentClassR,$feetyp)->totalPaymentMade; ?>
												</th>
											</tr>
										</table>
										<table class="table table-striped table-bordered table-hover dataTable no-footer">
											<tr>
												<th class="col-sm-8 col-xs-8" width="15%">BALANCE (GHC)</th>
												<td colspan="7" style="font-weight:bolder">GHc <?php print $student->getStudentById($ACTION[1])->studentBalance; ?></td>
											</tr>
										</table>
										</div>
									</div>
									</div>
								</div>
								
							</div> <!-- nav-tabs-custom -->
									<?php } } ?>
									<script>
								function filterInvoice() {
									var year = $("#academicYear").val();
									var term = $("#term").val();
									var type = $("#feeTypeId").val();
									var classes = $("#classesID").val();
									
									window.location.href="<?php print SITE_URL; ?>/invoice-history/<?php print $ACTION[1]; ?>/?filter&y="+year+"&t="+term+"&ty="+type;
								}
								</script>
						</div>
							
						<?php
							} else {
								PageNotFound();
							}
						?>
						
					</div><?php //box div ?>
				</div><?php //col-sm-12 div ?>
			</div><?php //row div ?>
		</section>
	</aside>
		<script type="text/javascript">
            $(function() {
				<?php
				$sql2 = $db->select("SELECT * FROM `finance_feestype` WHERE `status`='1'");
				if($db->scount($sql2) > 0) {
					while($result2 = $sql2->fetch_assoc()) {
						print '$("#example'.$result2['id'].'").dataTable();';
					}
				}
				?>
            });
        </script>
<?php
//get the page footer to include
template_footer();
?>