<?php
// $db=new Database;
// $sql=$db->select("select * from class");
// while($r = $sql->fetch_assoc()){
	// $db->update("update students set fees_balance='{$r['fees']}' where class='{$r['id']}'");
// }
?>