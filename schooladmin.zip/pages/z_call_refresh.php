<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$models = new Models;
require 'core/checkaccess.php';
if(isset($_POST['div']) and isset($_POST['item'])) {
	$item = strtolower($db->cleanData($_POST['item']));
	//query the database
	if($item == "designation")
		$table = "designation";
	elseif($item == "religion")
		$table = "religion";
	elseif($item == "qualification")
		$table = "qualification";
	else
		$table = "none-found";
	
	if($table == "none-found") {
		print "<div class='btn btn-danger'>Sorry! You have supplied an invalid inputs.</div>";
	} else {
		
		$sql = $db->select("SELECT * FROM `$table`") or trigger_error($db->db_error());
		if($db->scount($sql) > 0) {
?>

	<select tabindex="-1" required name="<?php print $item; ?>" id="<?php print $item; ?>" class="form-control guargianID">						
		<option value="0">Select <?php print $item; ?></option>
		<?php 
		while($res2=$sql->fetch_assoc()){
			print "<option value='".$res2['id']."'>{$res2['name']}</option>";
		}
		?>
	</select>
<?php
	
		} else {
?>
	<select tabindex="-1" required name="<?php print $item; ?>" id="<?php print $item; ?>" class="form-control guargianID">						
		<option value="0">Select <?php print $item; ?></option>
	</select>
<?php 
		}
	}
	
}
?>