<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
require 'core/checkaccess.php';
$db=new Database;
if(isset($_POST['classesID'])) {
	$classesID = $db->cleanData($_POST['classesID']);
	//query the database
	$sql = $db->select("SELECT studentunq,surname,firstname,class,status FROM `students` WHERE `class`='$classesID' AND `status`='1'");
	//count
	if($db->scount($sql) >0) {
?>
	<select tabindex="-1" required name="studentID" id="studentID" class="form-control guargianID select2-offscreen">
		<option value="0">Select Student</option>
<?php
		//using the while loop
		while($res = $sql->fetch_assoc()){
			//display the information
			print '<option value="'.$res['studentunq'].'">'.$res['surname'].' '.$res['firstname'].'</option>';
		}
?>
</select>
<?php
	} else {
		
	}
}
?>