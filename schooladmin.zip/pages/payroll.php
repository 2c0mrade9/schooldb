<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Make Salary Payment - Create',$site->getSiteName());
//create a new object of the count model
$msg_log = '';
$models = new Models;
?>
<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-money"></i>Salary Payment</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?php print SITE_URL; ?>/payroll/index"> Salary Payments</a></li>
            <li class="active">Pay Salary</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            <div class="col-sm-4">
				<div class="col-sm-12">
				</div>
				<hr>
				<div id="results"></div>
				<div class="form-horizontal" role="form" action="" method="post">

                    <div class="form-group">
						<label for="payhead" class="col-sm-4 control-label">
                           Designation
						</label>
                        <div class="col-sm-8">
                           <select tabindex="-1" required="required" name="designID" id="designID" class="form-control guargianID select2-offscreen">
								<option value="0">Select Designation</option>
								<?php
								$sql2 = $db->select("SELECT * FROM `designation`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['name']}</option>";
									}
								}
								?>
							</select>
                        </div>
                        <span class="col-sm-3 control-label">
                        </span>
                    </div>
					<div class="form-group" id="employee_name">
						<label for="amount" class="col-sm-4 control-label">
                            Employee
						</label>
                        <div class="col-sm-8">
                            <div id="employee_list"></div>
                        </div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
					 <div class="form-group">
						<label for="payhead" class="col-sm-4 control-label">
                           Payment Type
						</label>
                        <div class="col-sm-8">
                           <select tabindex="-1" required="required" name="payhead" id="payhead" class="form-control guargianID select2-offscreen">
								<option value="0">Select Payment Type</option>
								<?php
								$sql2 = $db->select("SELECT * FROM `payhead`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['name']}</option>";
									}
								}
								?>
							</select>
                        </div>
                        <span class="col-sm-3 control-label">
                        </span>
                    </div>
					<div class="form-group">
						<label for="payhead" class="col-sm-4 control-label">
                           Month
						</label>
                        <div class="col-sm-8">
                           <select tabindex="-1" required="required" onchange="return callEmployeePaymentsDetails();" name="month" id="months" class="form-control guargianID select2-offscreen">
								<option value="0">Select Month</option>
								<?php
								$sql2 = $db->select("SELECT * FROM `months`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['name']}</option>";
									}
								}
								?>
							</select>
                        </div>
                        <span class="col-sm-3 control-label">
                        </span>
                    </div>
					<div class="form-group">
						<label for="payhead" class="col-sm-4 control-label">
                           Year
						</label>
                        <div class="col-sm-8">
						<select tabindex="-1" onchange="return callEmployeePaymentsDetails();" style="width:120px" id="year" class="form-control guargianID select2-offscreen">
							<option value="<?php print date("Y"); ?>"><?php print date("Y"); ?></option>
							<option value="<?php print date("Y"); ?>">---------------------------------------------</option>
							
							<?php
							for($i = date("Y")+2; $i >= 2000; $i--) {
								print "<option value='".$i."'>{$i}</option>"; 
							}
							?>
						</select>
						</div>
					</div>
					<div class="form-group">
						<label for="amount" class="col-sm-4 control-label">
                            Amount
						</label>
                        <div class="col-sm-8">
                            <input required="required" onkeyup="return callEmployeePaymentsDetails();" class="form-control" style="" id="amount" name="amount">
                        </div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
					<div class="form-group">
                        <div class="col-sm-offset-4 col-sm-8">
							<input class="btn btn-success" onclick="insertSalarySettings();" value="Insert Salary Setting" name="" type="submit">
                        </div>
                    </div>
				</div>
            </div>
			<div class="col-sm-8">
				<h5 class="page-header">
				<table border="0" width="100%">
				<tr>
					<td width="25%">
					<a class="btn btn-warning" href="#">
						<i class="fa fa-money"></i> 
						Paid Salaries
					</a>
					</td>
					<td>
						<i style="padding-top:10px;cursor:pointer;" title="Click to Refresh List" onclick="return reloadPage();" class="fa fa-refresh fa-1x"></i>
					</td>
					<td colspan="2"></td>
					</tr>
					<tr>
					<td align="right" style="width:200px">
					<select tabindex="-1"  style="width:200px" id="filter_by_eid" class="form-control guargianID select2-offscreen">
						<option value="0">Select All Employees</option>
						<?php
						$sql2 = $db->select("SELECT * FROM `employee`");
						if($db->scount($sql2) >0) {
							while($res2=$sql2->fetch_assoc()){
								print "<option value='".$res2['uniqueid']."'>{$res2['fullname']}</option>";
							}
						}
						?>
					</select>
					</td>
					<td>
						<select tabindex="-1"  style="width:120px" id="filter_by_year" class="form-control guargianID select2-offscreen">
							<option value="<?php print date("Y"); ?>"><?php print date("Y"); ?></option>
							<option value="<?php print date("Y"); ?>">---------------------------------------------</option>
							<?php
							for($i = date("Y")+2; $i >= 2000; $i--) {
								print "<option value='".$i."'>{$i}</option>"; 
							}
							?>
						</select>
					</td>
					<td align="left" style="width:300px">
					
					<select tabindex="-1"  style="width:150px" id="filter_by_month" class="form-control guargianID select2-offscreen">
						<option value="0">Select Month</option>
						<?php
						$sql2 = $db->select("SELECT * FROM `months`");
						if($db->scount($sql2) >0) {
							while($res2=$sql2->fetch_assoc()){
								print "<option value='".$res2['id']."'>{$res2['name']}</option>";
							}
						}
						?>
					</select>
					</td>
					<td>
						<input class="btn btn-success" style="width:100px" onclick="filter_by_eid();" value="Filter">
					</td>
				</tr>
				</table>
				</h5>
				<div class="filter_result"></div>
				<div id="payrollview"></div>
			</div>
			<script>
			$("#designID").focus();
			$("#employee_name").hide();
			
			loadSalaries();
			function loadSalaries() {
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_call_payroll",
					data: "loadSalaries&call_all",
					dataType: "html",
					success: function(data) {
					   $('#payrollview').html(data);
					}
				});
			}
			
			function filter_by_eid() {
				var eid = $("#filter_by_eid").val();
				var mid = $("#filter_by_month").val();
				var yid = $("#filter_by_year").val();
				
				$(".filter_result").html("");
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_call_payroll",
					data: "loadSalaries&call_all&filter&eid="+eid+"&mid="+mid+"&yid="+yid,
					dataType: "html",
					success: function(data) {
					   $('#payrollview').html(data);
					}
				});
			}
			
			$('#designID').change(function(event) {
				var designID = $(this).val();
				if(designID == '0') {
					$(designID).val(0);
				} else {
					$.ajax({
						type: 'POST',
						url: "<?php print SITE_URL; ?>/z_call_employees",
						data: "designID=" + designID,
						dataType: "html",
						success: function(results) {
							$("#employee_name").show();
							$('#employee_list').html(results);
						}
					});
				}
			});
			
			function callEmployeePayments() {
				var employeeID = $("#employeeID").val();
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_call_payroll",
					data: "empPayment&employeeID=" + employeeID,
					dataType: "html",
					success: function(results) {
						$('#payrollview').html(results);
					}
				});
			}
			
			function callEmployeePaymentsDetails() {
				var employeeID = $("#employeeID").val();
				var mid = $("#months").val();
				var yid = $("#year").val();
				
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_call_payroll",
					data: "details&empPayment&employeeID="+employeeID+"&mid="+mid+"&yid="+yid,
					dataType: "html",
					success: function(results) {
						$('#payrollview').html(results);
					}
				});
			}
			
			$('#employeeID').change(function(event) {
				var employeeID = $(this).val();
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_call_payroll",
					data: "loadSalaries&call_all&filter&employeeID=" + employeeID,
					dataType: "html",
					success: function(results) {
						$('#payrollview').html(results);
					}
				});
			});
			
			function insertSalarySettings() {
				var designID = $("#designID").val();
				var amount = $("#amount").val();
				var employeeID = $("#employeeID").val();
				var payhead = $("#payhead").val();
				var months = $("#months").val();
				var year = $("#year").val();
				
				loadSalaries();
				
				if(designID==0) {
					$("#results").html("<div class='btn btn-danger'>Sorry! Please select designation.</div><br><br>");
					$("#designID").focus();
				} else if(employeeID==0) {
					$("#results").html("<div class='btn btn-danger'>Sorry! Please select employee.</div><br><br>");
					$("#employeeID").focus();
				} else if(employeeID=="undefined") {
					$("#results").html("<div class='btn btn-danger'>Sorry! Please select employee.</div><br><br>");
					$("#employeeID").focus();
				} else if(payhead==0) {
					$("#results").html("<div class='btn btn-danger'>Sorry! Please select employee pay head.</div><br><br>");
					$("#payhead").focus();
				} else if(months==0) {
					$("#results").html("<div class='btn btn-danger'>Sorry! Please select month.</div><br><br>");
					$("#months").focus();
				}  else if(year==0) {
					$("#results").html("<div class='btn btn-danger'>Sorry! Please select year.</div><br><br>");
					$("#year").focus();
				} else {
					$('#results').html('<div id="loading-bar" style="font-family:Verdana, Geneva, sans-serif; font-size:12px; color:black;">Please wait <img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" align="absmiddle" /></div><br clear="all">');
					$.ajax({
						type: 'POST',
						url: "<?php print SITE_URL; ?>/z_insert_salary",
						data: "designID=" + designID+"&amount="+amount+"&employeeID="+employeeID+"&payhead="+payhead+"&months="+months+"&year="+year,
						dataType: "html",
						success: function(results) {
							alert("Congrats! Salary has been issued successfully.");
							window.location.href="";
							$("#amount").val('');
							$("#payhead").val('');
							$("#employeeID").val('');
							$("#designID").val('');
							loadSalaries();
						}
					});
				}
			}
			function reloadPage() {
				var designID = $("#designID").val();
				var amount = $("#amount").val();
				var employeeID = $("#employeeID").val();
				var payhead = $("#payhead").val();
				var months = $("#months").val();
				
				if(designID != 0 || amount.length != 0 || payhead != 0 || month != 0) {
					if(confirm("You have an unsaved document. Do you want to still reload page?")) {
						location.reload();
					}
				}
			}
			</script>
        </div>
    </div>
</div>
 
                    </div>
                </div>
            </section>
        </aside>
	  
<?php
//get the page footer to include
template_footer();
?>