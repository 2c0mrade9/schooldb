<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$models = new Models;

require 'core/checkaccess.php';
if(isset($_POST['designID']) and is_numeric($_POST['designID'])) {
	$designID = strtolower($db->cleanData($_POST['designID']));
	//query the database
	$sql = $db->select("SELECT * FROM `employee` WHERE `designation`='$designID' AND status='1'");
	if($db->scount($sql) > 0) {
?>

	<select <?php if(isset($_POST['empid'])) { ?>readonly<?php } ?> tabindex="-1" required onchange="return callEmployeePayments();" name="employeeID" id="employeeID" class="form-control guargianID">						
		<?php if(!isset($_POST['empid'])) { ?>
		<option value="0">Select Employee Name</option>
		<?php } ?>
		<?php 
		while($res2=$sql->fetch_assoc()){
			$sel = '';
			if(isset($_POST['empid'])) {
				if($res2["uniqueid"] == $_POST['empid'])
					$sel = "selected='selected'";
			}
			print "<option $sel value='".$res2['uniqueid']."'>{$res2['fullname']}</option>";
		}
		?>
	</select>
	
<?php
	
		} else {
?>
	<select tabindex="-1" required name="employeeID" id="employeeID" class="form-control guargianID">						
		<option value="0">Select Employee Name</option>
	</select>
<?php 
	}
	
}
?>