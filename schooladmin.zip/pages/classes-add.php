<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Class - View',$site->getSiteName());
//create a new object of the count model
$classes = new Classes;
$models = new Models;
$msg_log = '';
//update the class information
if(isset($_POST['insertClass'])) {
	$className = $db->cleanData($_POST['classes']);
	$teacherID = $db->cleanData($_POST['teacherID']);
	$note = $db->cleanData($_POST['note']);
	$amount = $db->cleanData($_POST['amount']);
	$slug = $models->create_slug($className);
	//checkdate
	$check = $db->select("SELECT name FROM `class` WHERE `slug`='$slug'");
	if($db->scount($check) > 0) {
		$msg_log .= "<div class='btn btn-danger'>Sorry! A similar class already exists in the database.</div><br><br>";
	} else {
		$insert = $db->insert("INSERT INTO `class` (slug,name,teacher,fees,note) VALUES (
			'$slug','$className','$teacherID','$amount','$note'
		)");
		if($insert) {
			$msg_log .= "<div class='btn btn-success'>Congrats! Class information was successfully inserted.</div><br><br>";
		} else {
			$msg_log .= "<div class='btn btn-danger'>Sorry! There was an error inserting the class information.</div><br><br>";
		}
	}
	
}
?>
<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-sitemap"></i> Class</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?php print SITE_URL; ?>/classes/index"> Class</a></li>
            <li class="active">Viewing Class</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            <div class="col-sm-6">
			
				<?php print $msg_log; ?>
				<form class="form-horizontal" role="form" method="post">

                    <div class="form-group">                        <label for="classes" class="col-sm-3 control-label">
                            Class                        </label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" id="classes" name="classes" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">
					<label for="teacherID" class="col-sm-3 control-label">
                            Teacher Name</label>
                        <div class="col-sm-8">
                            
                            <select tabindex="-1" required name="teacherID" id="teacherID" class="form-control guargianID select2-offscreen">
							
							<option value="0">Select Teacher</option>
							<?php
								$sql2 = $db->select("SELECT id,fullname FROM `teacher`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['fullname']}</option>";
									}
								}
								?>
							</select>
							</div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">                        <label for="note" class="col-sm-3 control-label">
                            Note                        </label>
                        <div class="col-sm-8">
                            <textarea class="form-control" style="resize:none;height:100px;" id="note" name="note"></textarea>
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
					<div class="form-group">                        <label for="classes" class="col-sm-3 control-label">
                            Fees Payable                        </label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" id="amount" name="amount" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-8">
                            <input class="btn btn-success" value="Insert Class Information" name="insertClass" type="submit">
                        </div>
                    </div>

                </form>

            </div>
			
			<div class="col-sm-6">
				<div id="getCLassesHistory"></div>
			</div>
			
        </div>
    </div>
</div>
					<script>
					$("#classes").focus();
					getAllClasses();
					function getAllClasses() {
						$.ajax({
							type: 'POST',
							url: "<?php print SITE_URL; ?>/z_call_classes",
							data: "getAllClasses&call_all",
							dataType: "html",
							success: function(data) {
							   $('#getCLassesHistory').html(data);
							}
						});
					}
					</script>
                    </div>
                </div>
            </section>
        </aside>
	  
<?php
//get the page footer to include
template_footer();
?>