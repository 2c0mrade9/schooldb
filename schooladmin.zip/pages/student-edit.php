<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Sudent - Edit',$site->getSiteName());
//create a new object of the count model
$student = new Students;
$remarks = new Remarks;

//initializing
$error_msg = '';
//process the form for the adding of student
if(isset($_POST['updateStudentInfo']) and isset($_POST['sname'])) {
	//process the data parsed
	//clean the data parsed
	$sname = $db->cleanData($_POST['sname']);
	$fname = $db->cleanData($_POST['fname']);
	$religion = $db->cleanData($_POST['religion']);
	$class = $db->cleanData($_POST['class']);
	$guardian = $db->cleanData($_POST['guardian']);
	$address = $db->cleanData($_POST['address']);
	$studentId = $db->cleanData($_POST['studentId']);
	$proprietriess = stripslashes($_POST['proprietriess']);
	$headteacher = stripslashes($_POST['headteacher']);
	$gender = $db->cleanData($_POST['gender']);
	$phone = $db->cleanData($_POST['phone']);
	$place = $db->cleanData($_POST['place']);
	$dob = $db->cleanData($_POST['dob']);
	$language = $db->cleanData($_POST['language']);
	$email = $db->cleanData($_POST['email']);
	//check if the user already exists in the database using the surname, class and dob and fname
	$check = $db->select("SELECT * FROM `students` WHERE `studentunq`='$studentId'");
	//count the number of rows
	if($db->scount($check) != 1) {
		$error_msg = "<div class='btn btn-danger'>Sorry! The Student ID provided is invalid database.</div><br><br>";
	} else {
		//set variables
		$admin = $_SESSION["Username"];
		//$admin = "emman";
		//use a mechanism to obtain some basic variables
		$employees = new Employees;
		$classes = new Classes;
		
		//class teacher
		$classTeacher = $classes->getClassById($class,false)->classTeacher;
		
		//insert the data into the database
		$update = $db->insert("UPDATE `students` 
			SET `surname`='$sname',`firstname`='$fname',`parent`='$guardian',`teacher`='$classTeacher',`dob`='$dob',
				`gender`='$gender',`religion`='$religion',`email`='$email',`phone`='$phone',`language`='$language',
				`address`='$address',`residence`='$place',`class`='$class',`headteacher_remarks`='$headteacher',
				`proprietries_remarks`='$proprietriess'
				WHERE `studentunq`='$studentId'");
		
		if($update) {
			$error_msg = "<div class='btn bg-green'>Congrats! Student Information successfully updated.</div><br><br>";
			//set all the variables to null
			if(!empty($guardian) and $guardian!=0) {
				$db->update("DELETE FROM `guardian_ward` WHERE `ward`='$studentId'");
				$db->update("INSERT INTO `guardian_ward` (guard,ward)values('$guardian','$studentId')");
			}
		} else {
			$error_msg = "<div class='btn btn-danger'>Sorry! There was an error inserting student information.</div><br><br>";
		}
	}
	
}

?>
<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-user"></i> Student</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li><a href="<?php print SITE_URL; ?>/student/view-all">Students</a></li>
            <li class="active">Edit Student</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            <div class="col-sm-8">
				<h5 class="page-header">
					<a class="btn btn-success" href="<?php print SITE_URL; ?>/student-add">
					<i class="fa fa-plus"></i> 
					Add a Student
					</a>
				</h5>
			</div>
				<?php if(isset($ACTION[1]) and $db->cleanData($ACTION[1]) and $student->getStudentById($ACTION[1])->stuResult==true) { ?>
				<div class="col-sm-8">
				<?php print $error_msg; ?>
				</div>
                <form class="form-horizontal" role="form" method="post" enctype="multipart/form-data">
                   <div class="col-sm-6">
                    <div class="form-group"><label for="name_id" class="col-sm-4 control-label">
                            Surname                        </label>
                        <div class="col-sm-6">
                            <input class="form-control" required="required" id="name_id" name="sname" value="<?php print $student->getStudentById($ACTION[1])->studentSname; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                        </span>
                    </div>
					
					<div class="form-group">                        <label for="classesID" class="col-sm-4 control-label">
                            Class                        </label>
                        <div class="col-sm-6">
                           <select tabindex="-1" required name="class" id="class" class="form-control guargianID select2-offscreen">
							<?php
								if($student->getStudentById($ACTION[1])->studentClassR != 0) {
										$getClass = $db->select("SELECT id,name FROM `class` WHERE `id`='{$student->getStudentById($ACTION[1])->studentClassR}' LIMIT 1");
										if($db->scount($getClass) > 0) {
											$result = $getClass->fetch_assoc();
											print "<option selected='selected' value='".$result['id']."'>{$result['name']}</option>";
										}
									}
								?>
							<option value="0">Select Class</option>
							<?php
								$db2=new Database;
								$sql2 = $db2->select("SELECT * FROM `class`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['name']}</option>";
									}
								}
								?>
							</select>
						</div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
					<div class="form-group"> <label for="sex" class="col-sm-4 control-label">
                            Gender</label>
                        <div class="col-sm-6">
                            <select name="gender" tabindex='-1' required="required" id="gender" class="form-control guargianID">
							<option value="Null">Please Select</option>
							<option <?php if($student->getStudentById($ACTION[1])->studentGender == "Male") print 'selected'; ?> value="Male">Male</option>
							<?php print $gender; ?>
							<option <?php if($student->getStudentById($ACTION[1])->studentGender == "Female") print 'selected'; ?> value="Female">Female</option>
							</select>                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>

                    </div>
                    <div class="form-group">                        <label for="email" class="col-sm-4 control-label">
                            Email                        </label>
                        <div class="col-sm-6">
                            <input class="form-control" id="email" name="email" value="<?php print $student->getStudentById($ACTION[1])->studentEmail; ?>" type="email">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>

                    <div class="form-group">
						<label for="address" class="col-sm-4 control-label">
							Address
						</label>
						<div class="col-sm-6">
							<textarea name="address" id="address" rows="3" style="border:solid 1px #cccccc;border-radius:4px;padding:5px;"><?php print $student->getStudentById($ACTION[1])->studentAddress; ?></textarea>
                        </div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
					
					<div class="form-group">                        <label for="s2id_autogen1" class="col-sm-4 control-label">
                            Guardian                        </label>
                        <div class="col-sm-6">
                            <div class="select2-wrapper">
                               
								<select tabindex="-1" name="guardian" id="guargianID" class="form-control guargianID select2-offscreen">
								<?php
									if($student->getStudentById($ACTION[1])->studentGuardian != 0) {
										$getGuard = $db->select("SELECT id,fullname FROM `guardian` WHERE `id`='{$student->getStudentById($ACTION[1])->studentGuardian}' LIMIT 1");
										if($db->scount($getGuard) > 0) {
											$result = $getGuard->fetch_assoc();
											print "<option selected='selected' value='".$result['id']."'>{$result['fullname']}</option>";
										}
									}
								?>
								<option value="0">Please Select</option>
								<?php
								$db=new Database;
								$sql = $db->select("SELECT * FROM `guardian`");
								while($res=$sql->fetch_assoc()){
									print "<option value='".$res['id']."'>{$res['fullname']} ({$res['phone']})</option>";
								}
								?>
								</select>
							</div>
                        </div>
                        <span class="col-sm-4 control-label">
                        </span>
                    </div>
					<div class="form-group">
						<label for="headteacher" class="col-sm-4 control-label">
							Headteacher Remarks
						</label>
						<div class="col-sm-6">
							<textarea name="headteacher" id="headteacher"  <?php if(!isset($_SESSION['headt'])) print "readonly"; ?> rows="6" style="border:solid 1px #cccccc;border-radius:4px;padding:5px;"><?php print $remarks->getRemarksByid($ACTION[1],"students")->headTeacher; ?></textarea>
                        </div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
					<div class="form-group">
                        <div class="col-sm-offset-12 col-sm-12">
							<input type="hidden" name="studentId" id="studentId" value="<?php print $ACTION[1]; ?>">
                            <input class="btn btn-success" name="updateStudentInfo" value="Update Student Information" type="submit">
                        </div>
                    </div>
					</div> <!-- col-sm-8 -->
					
					
					<div class="col-sm-6">
					<div class="form-group"><label for="name_id" class="col-sm-4 control-label">
                            First Name / Other Names                        </label>
                        <div class="col-sm-6">
                            <input class="form-control" required="required" id="name_id" name="fname" value="<?php print $student->getStudentById($ACTION[1])->studentFname; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                        </span>
                    </div>
					
					<div class="form-group"><label for="dob" class="col-sm-4 control-label">
                            Date of Birth</label>
                        <div class="col-sm-6">
                            <input class="form-control" required="required" id="dob" name="dob" value="<?php print $student->getStudentById($ACTION[1])->studentDobR; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
					
					<div class="form-group"><label for="phone" class="col-sm-4 control-label">
                            Phone                        </label>
                        <div class="col-sm-6">
                            <input class="form-control" id="phone" name="phone" value="<?php print $student->getStudentById($ACTION[1])->studentPhone; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                                                    </span>
                    </div>
					<div class="form-group"><label for="place" class="col-sm-4 control-label">
                            Place of Residence</label>
                        <div class="col-sm-6">
                            <input class="form-control" id="place" name="place" value="<?php print $student->getStudentById($ACTION[1])->studentPlace; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                        </span>
                    </div>
					
					<div class="form-group"> 
					<label for="phone" class="col-sm-4 control-label">
                            Languages Spoken                        </label>
                        <div class="col-sm-6">
                            <input class="form-control" id="language" name="language" value="<?php print $student->getStudentById($ACTION[1])->studentLanguage; ?>" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                    </span>
                    </div>
					
					<div class="form-group">                        <label for="religion" class="col-sm-4 control-label">
                            Religion                        </label>
                        <div class="col-sm-6">
                            <select tabindex="-1" required name="religion" id="religion" class="form-control guargianID select2-offscreen">
							<?php
									if($student->getStudentById($ACTION[1])->studentReligionR != 0) {
										$getReligion = $db->select("SELECT id,name FROM `religion` WHERE `id`='{$student->getStudentById($ACTION[1])->studentReligionR}' LIMIT 1");
										if($db->scount($getReligion) > 0) {
											$result = $getReligion->fetch_assoc();
											print "<option selected='selected' value='".$result['id']."'>{$result['name']}</option>";
										}
									}
								?>
							<option value="0">Select Religion</option>
							<?php
								$db2=new Database;
								$sql2 = $db2->select("SELECT * FROM `religion`");
								if($db->scount($sql2) >0) {
									while($res2=$sql2->fetch_assoc()){
										print "<option value='".$res2['id']."'>{$res2['name']}</option>";
									}
								}
								?>
							</select>
						</div>
                        <span class="col-sm-4 control-label">
						</span>
                    </div>
					
					<div class="form-group">
						<label for="proprietress" class="col-sm-4 control-label">
							Proprietress Remarks
						</label>
						<div class="col-sm-6">
							<textarea name="proprietriess" <?php if(!isset($_SESSION['prop'])) print "readonly"; ?> id="proprietriess" rows="8" style="border:solid 1px #cccccc;border-radius:4px;padding:5px;"><?php print $remarks->getRemarksByid($ACTION[1],"students")->proprietress; ?></textarea>
                        </div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
					
					</div>
					
					
                </form>

            
        </div><!-- row -->
    </div><!-- Body -->
</div><!-- /.box -->

					<script type="text/javascript">
					$('#dob').datepicker({ startView: 2, format: "yyyy-mm-dd" });
					</script>
		<?php
			} else {
				PageNotFound();
			}
		?>
                    </div>
                </div>
            </section>
        </aside>
<?php
//get the page footer to include
template_footer();
?>