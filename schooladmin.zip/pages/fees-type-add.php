<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Fees Type - Add',$site->getSiteName());
//create a new object of the count model
$msg_log = '';
$models = new Models;
//update the class information
if(isset($_POST['insertFeesType'])) {
	$typeName = $db->cleanData($_POST['feetype']);
	$note = $db->cleanData($_POST['note']);
	$amount = $db->cleanData($_POST['amount']);
	$slug = $models->create_slug($typeName);
	//check if all fields are filled
	$check = $db->select("SELECT type FROM `finance_feestype` WHERE `slug`='$slug'");
	if($db->scount($check) > 0) {
		$msg_log .= "<div class='btn btn-danger'>Sorry! A similar fee type already exists in the database.</div><br><br>";
	} else {
		$insert = $db->insert("INSERT INTO `finance_feestype` (slug,type,note,amount) VALUES (
			'$slug','$typeName','$note','$amount'
		)");
		
		if($insert) {
			$msg_log .= "<div class='btn bg-green'>Congrats! Fee type information was successfully inserted.</div><br><br>";
		} else {
			$msg_log .= "<div class='btn btn-danger'>Sorry! There was an error inserting the fee type information.</div><br><br>";
		}
		$typeName = "";
		$classesID = 0;
		$amount = "";
		$note = "";
		
	}
}
?>
<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
<div class="box">
    <div class="box-header bg-purple">
        <h3 class="box-title"><i class="fa fa-money"></i> Fee Type</h3>

       
        <ol class="breadcrumb">
            <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
            <li class="active"><a href="<?php print SITE_URL; ?>/fees-type/index"> Fee Type</a></li>
            <li class="active">Add new Fee Type</li>
        </ol>
    </div><!-- /.box-header -->
    <!-- form start -->
    <div class="box-body">
        <div class="row">
            <div class="col-sm-6">
			
				<?php print $msg_log; ?>
				<form class="form-horizontal" role="form" method="post">

                    <div class="form-group">
						<label for="feetype" class="col-sm-3 control-label">
                            Fees Type
						</label>
                        <div class="col-sm-8">
                            <input required="required" class="form-control" id="feetype" name="feetype" type="text">
                        </div>
                        <span class="col-sm-3 control-label">
                        </span>
                    </div>
					<div class="form-group">
						<label for="feetype" class="col-sm-3 control-label">
                            Amount
						</label>
                        <div class="col-sm-8">
                            <input required="required" onkeyup="removeDisabled();" class="form-control" id="amount" name="amount" type="text">
                        </div>
                        <span class="col-sm-4 control-label">
                        </span>
                    </div>
					<div class="form-group">                        <label for="note" class="col-sm-3 control-label">
                            Note                        </label>
                        <div class="col-sm-8">
                            <textarea class="form-control" style="resize:none;height:100px;" id="note" name="note"></textarea>
                        </div>
                        <span class="col-sm-4 control-label"></span>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-8">
                            <input class="btn btn-success" value="Insert Fee Type" id="insertFeesType" name="insertFeesType" type="submit">
                        </div>
                    </div>

                </form>
            </div>
			<div class="col-sm-5">
				<div id="feeTypeHistory"></div>
			</div>
			<script>
			$("#feetype").focus();
			$("#insertFeesType").attr("disabled","disabled");
			function removeDisabled() {
				var coun = $("#amount").val();
				if(coun.length > 0) {
					$("#insertFeesType").removeAttr("disabled");
				}
			}
			getFeeTypes();
			function getFeeTypes() {
				$.ajax({
					type: 'POST',
					url: "<?php print SITE_URL; ?>/z_call_fee_types",
					data: "getFeeTypes&call_all",
					dataType: "html",
					success: function(data) {
					   $('#feeTypeHistory').html(data);
					}
				});
			}
			</script>
        </div>
    </div>
</div>
 
                    </div>
                </div>
            </section>
        </aside>
	  
<?php
//get the page footer to include
template_footer();
?>