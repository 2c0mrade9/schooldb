<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$models = new Models;
require 'core/checkaccess.php';
if(isset($_POST['type']) and isset($_POST['value'])) {
	$type = strtolower($db->cleanData($_POST['type']));
	$value = $db->cleanData($_POST['value']);
	$slug = $models->create_slug($value);
	//query the database
	if($type == "designation")
		$table = "designation";
	elseif($type == "religion")
		$table = "religion";
	elseif($type == "qualification")
		$table = "qualification";
	else
		$table = "none-found";
	
	if($table == "none-found") {
		print "<div class='btn btn-danger'>Sorry! You have supplied an invalid inputs.</div>";
	} else {
		
		$check = $db->select("SELECT slug FROM `$table` WHERE `slug`='$slug'");

		if($db->scount($check) > 0) {
			print "<div class='btn btn-danger'>Sorry! A similar ".ucwords($type)." already exists in the database.</div>";
		} else {
			$insert = $db->insert("INSERT INTO `$table` (name,slug) VALUES (
				'$value','$slug'
			)");
			
			if($insert) {
				print "<div class='btn bg-green'>Congrats! ".ucwords($type)." was successfully inserted.</div>";
			} else {
				print "<div class='btn btn-danger'>Sorry! There was an error inserting the ".ucwords($type)." .</div>";
			}
		}
	
	}
		
	
}
?>