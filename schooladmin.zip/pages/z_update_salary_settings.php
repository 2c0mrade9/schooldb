<?php 
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$models = new Models;
require 'core/checkaccess.php';

if(isset($_POST['empid']) and isset($_POST['update'])  and isset($_POST['designID']) and isset($_POST['employeeID']) and isset($_POST['amount']) and isset($_POST['payhead']) and is_numeric($_POST['payhead'])) {
	if(is_numeric($_POST['designID']) and is_numeric($_POST['amount'])) {
		
		
		$d = $db->cleanData($_POST['designID']);
		$e = $db->cleanData($_POST['empid']);
		$a = $db->cleanData($_POST['amount']);
		$p = $db->cleanData($_POST['payhead']);
		$b = $db->cleanData($_POST['balance']);
		$admin = $_SESSION['Username'];
		
		$check = $db->select("SELECT * FROM `salary_settings` WHERE `employeeid`='$e'");
		if($db->scount($check) < 0) {
			print "<div class='btn btn-danger'>Sorry! This salary setting does not exist in the database.</div><Br><Br>";
		} else {
			$insert = $db->update("UPDATE `salary_settings` SET designation='$d',payhead='$p',amount='$a',
							balance='$b',moddate=now(),modby='$admin' WHERE employeeid='$e'");
			
			if($insert) {
				print "Congrats! Salary Settings was successfully updated";
			} else {
				print "Sorry! There was an error updating the Salary Settings.";
			}
		}
								
	} else {
		print "<div class='btn btn-danger'>Sorry! You have supplied an invalid inputs. Amount must be only Numerics (0-9)</div><br><br>";
	}
} else {
	print "<div class='btn btn-danger'>Sorry! You have supplied an invalid inputs.</div><Br><Br>";
}

?>