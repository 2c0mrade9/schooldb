<?php
//call the checkaccess file
require 'core/checkaccess.php';
//initialization
$msg = '';
//check if the user has submitted information to be processed
if(isset($_SESSION['vpb_captcha_code_FVIPFinal']) and !empty($_SESSION['vpb_captcha_code_FVIPFinal'])) {
	
	if(isset($_GET['key']) and isset($_GET['t']) and is_numeric($_GET['t']) and isset($_GET['y'])) {
		
		$key = $db->cleanData($_GET['key']);
		$sess = $_SESSION['vpb_captcha_code_FVIPFinal'];
		$acterm = $db->cleanData($_GET['t']);
		$acyear = $db->cleanData($_GET['y']);
		
		if($key==md5(sha1($sess))) {
			//query the students table
			$ssql = $db->select("select id, class, balance from students where status='1'");
			//continue processing the file
			$accterm = AC_TERM;
			$accyear = AC_YEAR;
			//continue
			//update the settings table
			$db->update("update cepstb_options set Term='$accterm', AcademicYear='$accyear'");
			//using the while loop fetch each students balance
			while($sresult = $ssql->fetch_assoc()) {
				//set a variable for the balance, id and class
				$sid = $sresult["id"];
				$sbalance = $sresult["balance"];
				$sclass = $sresult["class"];
				//query the classes table
				$csql = $db->select("select id, fees from class where id='$sclass' and status='1'");
				//fetch the fees for each student from the class table
				$cresult = $csql->fetch_assoc();
				//assign variable
				$cfees = $cresult["fees"];
				//set a new balance for the student
				$nbalance = $sbalance + $cfees;
				//update the students table
				$db->update("update students set balance='$nbalance' where id='$sid' and nofees='0'");
			}
			//update the settings table
			$db->update("update cepstb_options set Term='$accterm', AcademicYear='$accyear'");
			//conclude
		} else {
			//redirect the user to the dashboard
			print "<script>window.location.href='".SITE_URL."/close-account'</script>";
		}
	} else {
		//redirect the user to the dashboard
		print "<script>window.location.href='".SITE_URL."/close-account'</script>";
	}
} else {
	//redirect the user to the dashboard
	print "<script>window.location.href='".SITE_URL."/close-account'</script>";
}
?>
<!DOCTYPE html>
<html class="white-bg-login" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>CLOSE ACCOUNT CONFIRM | <?PHP PRINT SITE_NAME; ?></title>
    <link rel="SHORTCUT ICON" href="<?php print SITE_IMAGE_PATH; ?>/site.png">
    <!-- bootstrap 3.0.2 -->
    <link href="<?php print SITE_CSS_PATH; ?>/bootstrap.css" rel="stylesheet" type="text/css">
    <!-- font Awesome -->
    <link href="<?php print SITE_CSS_PATH; ?>/font-awesome.css" rel="stylesheet" type="text/css">
    <!-- Style -->
    <link href="<?php print SITE_CSS_PATH; ?>/style.css" rel="stylesheet" type="text/css">
    <!-- iNilabs css -->
    <link href="<?php print SITE_CSS_PATH; ?>/inilabs.css" rel="stylesheet" type="text/css">
    <link href="<?php print SITE_CSS_PATH; ?>/responsive.css" rel="stylesheet" type="text/css">
</head>

<body class="white-bg-login" style="background:url(<?php print SITE_IMAGE_PATH; ?>/loginbg.jpg) repeat scroll #1A2229;">

    <div class="col-md-4 col-md-offset-4 marg" style="margin-top:30px;">
        <center><img src="<?php print SITE_IMAGE_PATH; ?>/site.png" height="50" width="50"></center>
		<center><h4><?php print SITE_NAME; ?></h4></center>
    </div>

     
<div class="form-box" id="login-box" style="height:500px;width:600px;bottom:0px;">
	<div class="header bg-fuchsia">CLOSE ACCOUNT MENU</div>
	
    <form method="post" action="<?php print SITE_URL; ?>/close-account-confirm">
        <!-- style="margin-top:40px;" -->
        <div class="body white-bg">
			<div style="text-align:LEFT;font-size:16px;height:300px;" class="alert">
				<?PHP print $msg; ?>
				<STRONG><h2>BACKING UP DATABASE... AND CLOSING ACCOUNT</h2></strong><br><br>
				Please wait....<img src="<?php print SITE_IMAGE_PATH; ?>/loadings.gif" style="height:35px;"> 
				<?php header("Refresh: 10; url=".SITE_URL."/close-account-success?key=".md5(sha1($_SESSION['vpb_captcha_code_FVIPFinal'])).""); ?>
				<br><hr>
				<em>May take up to 10 seconds... <strong>Dont press any key!!!</strong></em>
			</div>
			
		</div>
    </form>
	<br clear="all">
	<div class="body white-bg bg-green" align="center"><strong>CREATED BY: </strong><?php print $site->getSiteAuthor(); ?></div>
</div>

</body></html>