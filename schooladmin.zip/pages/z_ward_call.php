<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$models = new Models;
$guardian = new Guardian;
require 'core/checkaccess.php';
if(isset($_POST['call_wards']) and isset($_POST['pid']) and is_numeric($_POST['pid']) and !isset($_POST['adding_new'])) {
?>
	<span id="fetch_wards" style="color:#ff4000"><?php print $guardian->listWards($db->cleanData($_POST['pid']), "dont")->studentName; ?></span>
	<?php if($guardian->listWards($db->cleanData($_POST['pid']), "dont")->found == "yes") { ?>
	<br clear="all"><br clear="all">
	<?php } ?>
<?php
} elseif(isset($_POST['pid']) and isset($_POST['adding_new']) and isset($_POST['call_wards'])) {
?>
	<span id="fetch_wards" style="color:#ff4000"><?php print $guardian->listWardsNew($db->cleanData($_POST['pid']), "dont")->studentName; ?></span>
	<?php if($guardian->listWardsNew($db->cleanData($_POST['pid']), "dont")->found == "yes") { ?>
	<br clear="all"><br clear="all">
	<?php } ?>
<?php
}
?>