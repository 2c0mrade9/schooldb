<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Parents',$site->getSiteName());
//create a new object of the count model
$guardian = new Guardian;

$db = new Database;
?>

		<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
					<div class="box">
						<div class="box-header bg-purple">
							<h3 class="box-title"><i class="fa fa-users"></i> Parents / Guardians</h3>

						   
							<ol class="breadcrumb">
								<li><a href="<?php print SITE_URL; ?>"><i class="fa fa-laptop"></i> Dashboard</a></li>
								<li class="active">Parents / Guardians</li>
							</ol>
						</div><!-- /.box-header -->
						<!-- form start -->
						<div class="box-body">
							<div class="row">
								<div class="col-sm-12">

									<h5 class="page-header">
										<a class="btn btn-success" href="<?php print SITE_URL; ?>/parents-add">
											<i class="fa fa-plus"></i> 
											Add a Parents / Guardians                        </a>
									</h5>
									
						
									
									<div class="col-sm-12">

									<div class="nav-tabs-custom">
										<div class="box-header bg-red">
											<h3 class="box-title">
												All Parents / Guardians
											</h3>
										</div>
										
										<?PHP
										if(isset($ACTION[1])) {
										?>
										<div class="tab-content">
										<div id="all" class="tab-pane active">
										<div id="hide-table">
											<div id="example1_wrapper" class="dataTables_wrapper form-inline" role="grid">
											<table aria-describedby="example1_info" id="example1" class="table table-striped table-bordered table-hover dataTable no-footer">
												<thead>
												<tr role="row">
													<td>ID</td>
													<td>FULLNAME</td>
													<td>PROFESSION</td>
													<td>WARD</td>
													<td>PHONE</td>
													<td width="17%">ACTION</td>
												</tr>
												</thead>

												<tbody aria-relevant="all" aria-live="polite" role="alert">
													<?php print $guardian->getGuardians("", "LIMIT 5000", "DESC"); ?>
												</tbody>
											</table>
											</div>
										</div>

										</div>
									</div>
										<?php
										} else {
											PageNotFound();
										}
										?>

									</div> <!-- nav-tabs-custom -->
									</div>
									
								</div>
							</div>
						</div><?php //body div ?>
					</div><?php //box div ?>
				</div><?php //col-sm-12 div ?>
			</div><?php //row div ?>
		</section>
	</aside>
		
<?php
//get the page footer to include
template_footer();
?>