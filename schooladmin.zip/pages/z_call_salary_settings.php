<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$design = new Designation;
$employees = new Employees;
$payheads = new Payhead;
require 'core/checkaccess.php';

if(isset($_POST['loadSalaries']) and isset($_POST['call_all'])) {
	
	//query the database
	$sql = $db->select("SELECT * FROM `salary_settings` WHERE status='1' ORDER BY `id` ASC");	
	//count
	if($db->scount($sql) > 0) {
?>
		<div class="col-sm-12">
			<div class="box-body" style="padding: 0px;">
				<table class="table table-hover">
					<thead>
					<tr role="row">
						<td>ID</td>
						<td width="30%">NAME</td>
						<td>DESIGNATION</td>
						<td>PAYHEAD</td>
						<td>AMOUNT</td>
						<td>BALANCE</td>
						<td>ACTION</td>
					</tr>
					</thead>
					<tbody aria-relevant="all" aria-live="polite" role="alert">
					<?php 
						//using the while loop
						while($result = $sql->fetch_assoc()) {
							print "<tr align='left' class='gradeU'>";
							print "<td><strong>{$result['id']}</strong></td>";
							print "<td>{$employees->getEmployeeById($result['employeeid'])->teacherName}</td>";
							print "<td>{$design->getDesignationById($result['designation'])->desigName}</td>";
							print "<td>{$payheads->getPayheadById($result['payhead'])->payHeadName}</td>";
							print "<td><strong>{$result['amount']}</strong></td>";
							print "<td><strong>{$result['balance']}</strong></td>";
							print '<td><a href="'.SITE_URL.'/salary-settings-view/'.$result['employeeid'].'" class="btn btn-info" data-placement="top" data-toggle="tooltip" data-original-title="View" title="View"><i class="fa fa-check-square-o"></i></a>
							<a onclick="javascript:confirmSubmit(\''.$result['id'].'\',\'salary_settings\', \'Salary Setting of - ('.$employees->getEmployeeById($result['employeeid'])->teacherName.')\');" class="btn btn-danger" data-placement="top" data-toggle="tooltip" data-original-title="View" title="Delete"><i class="fa fa-trash-o"></i></a>';
							print "</td>";
							print "</tr>";
						}
					?>
					</tbody>
				</table>
			</div>
			
		</div>
		<script type="text/javascript">
           $("#example1").dataTable({"iDisplayLength": 10});
        </script>
<?php
	} else {
?>
	<table class="table table-striped table-bordered table-hover dataTable no-footer">
	<tr>
		<th align="right">
		There are no salary settings currently in the database</th>
	</tr>
	</table>

<?php
	}
}
?>