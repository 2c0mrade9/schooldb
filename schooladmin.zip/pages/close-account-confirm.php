<?php
//call the checkaccess file
require 'core/checkaccess.php';
//initialization
if(!isset($_POST['yesContinue'])) {
	print "<script>window.location.href='".SITE_URL."/close-account'</script>";
}
$msg = '';
//check if the user has submitted information to be processed
if(isset($_POST['vpb_captcha_code']) and !empty($_POST['vpb_captcha_code'])) {
	//CONTINUE
	$msg = "";
	//Clean the data
	$code = $db->cleanData($_POST['vpb_captcha_code']);
	$sess = $_SESSION['vpb_captcha_code_FVIP'];
	$acyear = $db->cleanData($_POST["academicYear"]);
	$acterm = $db->cleanData($_POST["academicTerm"]);
	//continue
	if($acterm==AC_TERM) {
		$msg = "<script>alert('You supplied the same Academic Term. Please change it to continue or Click on CANCEL to QUIT the process.');</script>";
	} else {
		//update the database
		if($code==$sess) {
			//set new session
			$_SESSION['vpb_captcha_code_FVIPFinal'] = $code;
			//redirect the user to the dashboard
			$msg = "<script>window.location.href='".SITE_URL."/close-account-true?key=".md5(sha1($code))."&t=$acterm&y=$acyear'</script>";
		} else {
			//print an error message
			$msg = "<div class='alert alert-danger'>You entered a wrong security key. Try Again!!!</div>";
		}
	}
}
?>
<!DOCTYPE html>
<html class="white-bg-login" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>CLOSE ACCOUNT CONFIRM | <?PHP PRINT SITE_NAME; ?></title>
    <link rel="SHORTCUT ICON" href="<?php print SITE_IMAGE_PATH; ?>/site.png">
    <!-- bootstrap 3.0.2 -->
    <link href="<?php print SITE_CSS_PATH; ?>/bootstrap.css" rel="stylesheet" type="text/css">
    <!-- font Awesome -->
    <link href="<?php print SITE_CSS_PATH; ?>/font-awesome.css" rel="stylesheet" type="text/css">
    <!-- Style -->
    <link href="<?php print SITE_CSS_PATH; ?>/style.css" rel="stylesheet" type="text/css">
    <!-- iNilabs css -->
    <link href="<?php print SITE_CSS_PATH; ?>/inilabs.css" rel="stylesheet" type="text/css">
    <link href="<?php print SITE_CSS_PATH; ?>/responsive.css" rel="stylesheet" type="text/css">
</head>

<body class="white-bg-login" style="background:url(<?php print SITE_IMAGE_PATH; ?>/loginbg.jpg) repeat scroll #1A2229;">

    <div class="col-md-4 col-md-offset-4 marg" style="margin-top:30px;">
        <center><img src="<?php print SITE_IMAGE_PATH; ?>/site.png" height="50" width="50"></center>
		<center><h4><?php print SITE_NAME; ?></h4></center>
    </div>

     
<div class="form-box" id="login-box" style="height:auto;width:600px;bottom:0px;">
	<div class="header bg-fuchsia">CLOSE ACCOUNT MENU</div>
	
    <form method="post" action="<?php print SITE_URL; ?>/close-account-confirm">
        <!-- style="margin-top:40px;" -->
        <div class="body white-bg">
			<div style="text-align:justify;font-size:16px;" class="alert">
				<?PHP print $msg; ?>
				<label>
				<strong>Academic Term</strong>
			</label>
            <select tabindex="-1" name="academicTerm" id="academicTerm" class="form-control guargianID select2-offscreen">
				<option value="<?php print AC_TERM; ?>" selected='selected'>Term <?php print AC_TERM; ?></option>
				<option value="<?php print AC_TERM; ?>">-------------------------------------------------------------</option>
				<option value="1">Term 1</option>
				<option value="2">Term 2</option>
				<option value="3">Term 3</option>
				<option value="4">Term 4</option>
			</select>
            <div class="form-group">
				<label>
					<strong>Academic Year</strong>
				</label>
                <select tabindex="-1" name="academicYear" id="academicYear" class="form-control guargianID select2-offscreen">
					<?php
					$currentYear = date("Y")-3;
					if(isset($_GET['y']))
						print "<option value='".$_GET['y']."' selected='selected'>{$_GET['y']}</option>";
					
					print "<option selected='selected' value='".AC_YEAR."'>".AC_YEAR."</option>";
					print "<option value='".AC_YEAR."'>----------------------------------------------------------------</option>";
					for($i = 0; $i < 5; $i++) {
						$currentYear++;
						$previousYear = $currentYear - 1;
						if(($previousYear."/".$currentYear) == ''.(date("Y")).'/'.(date("Y")+1).'') {
							if(isset($_GET['y']))
								print "<option value='".($previousYear)."/".($currentYear)."'>".($previousYear)."/".($currentYear)."</option>";
							else
								print "<option value='".($previousYear)."/".($currentYear)."'>".($previousYear)."/".($currentYear)."</option>";
						} else
							print "<option value='".($previousYear)."/".($currentYear)."'>".($previousYear)."/".($currentYear)."</option>";
					}
					?>
				</select>
            </div>     

				<STRONG><EM>Enter the Security Key to continue.
				</EM></STRONG> <BR><BR>
				<input class="form-group" id="vpb_captcha_" name="vpb_captcha_code" type="text">
				<div class="vpb_captcha_wrapper">
				<img src="/captcha/vasplusCaptcha.php?rand=<?php echo rand(); ?>" id='captchaimg' >
				</div>
				<BR>
				<STRONG>ACADEMIC YEAR: <?php print AC_YEAR; ?><BR>
				ACADEMIC TERM: <?php print AC_TERM; ?></STRONG>
				<hr>
				<input type="hidden" name="yesContinue" id="yesContinue" value="true">
				<button class="header bg-green" style="cursor:pointer;" onclick="return contCLOSE();" id="contCLOSE">CONTINUE</button>
				<span class="header bg-red" style="cursor:pointer;" onclick="return contCANCEL();" id="contCANCEL">CANCEL</span>
			</div>
			<?php// header("Refresh: 5; url=".SITE_URL."/funcky.php"); ?>
		</div>
    </form>
	<br clear="all">
	<div class="body white-bg bg-green" align="center"><strong>CREATED BY: </strong><?php print $site->getSiteAuthor(); ?></div>
	<script>$("#vpb_captcha_").focus();
	function contCANCEL() {
		if(confirm("ARE YOU SURE YOU WANT TO CANCEL THE PROCESS?")) {
			window.location="<?php print SITE_URL; ?>/dashboard"; 
		}
	}
	</script>
</div>

</body></html>