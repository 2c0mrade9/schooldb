<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
require 'core/checkaccess.php';

$db=new Database;
$student =  new Students;
$classes = new Classes;
$feestype = new FeesType;
$invoice = new Invoices;

if(isset($_POST['showcase'])) {
	//add additional 
	$add = "";
	$title = "";
	//get user payrolls
	$exp = "/^[a-zA-Z0-9]+$/";
	//initial query 
	$query = "select * from payments where ";
	$query2 = "select sum(amount) as amount from `payments` where ";
	//add more query options
	//check if a unique id was parsed
	if(isset($_POST['unq']) and preg_match($exp, $_POST['unq'])) {
		$query .= "and unqid='".$db->cleanData($_POST['unq'])."' ";
		$query2 .= "and unqid='".$db->cleanData($_POST['unq'])."' ";
	}
	//check if a feetype id was parsed
	if(isset($_POST['ty']) and is_numeric($_POST['ty']) and $_POST['ty']!=0) {
		$query .= "and feetypeid='".$db->cleanData($_POST['ty'])."' ";
		$query2 .= "and feetypeid='".$db->cleanData($_POST['ty'])."' ";
	}
	//check if a student id was parsed
	if(isset($_POST['std']) and preg_match($exp, $_POST['std'])) {
		$query .= "and studentunq='".$db->cleanData($_POST['std'])."' ";
		$query2 .= "and studentunq='".$db->cleanData($_POST['std'])."' ";
	}
	//check if a class id was parsed
	if(isset($_POST['c']) and is_numeric($_POST['c']) and $_POST['c']!=0) {
		$query .= "and classid='".$db->cleanData($_POST['ty'])."' ";
		$query2 .= "and classid='".$db->cleanData($_POST['ty'])."' ";
	}
	//check if a class id was parsed
	if(isset($_POST['y'])) {
		$query .= "and academicyear='".$db->cleanData($_POST['y'])."' ";
		$query2 .= "and academicyear='".$db->cleanData($_POST['y'])."' ";
	}
	//check if a class id was parsed
	if(isset($_POST['t']) and is_numeric($_POST['t'])) {
		$query .= "and term='".$db->cleanData($_POST['t'])."' ";
		$query2 .= "and term='".$db->cleanData($_POST['t'])."' ";
	}
	if(isset($_POST['split']) and $_POST['split']=="yes") {
		$split = "";
		$sp=0;
	} else {
		$split = "group by studentunq";
		$sp=1;
	}
	//call the status column
	$query .="and status='1' $split";
	$query2 .="and status='1' $split";
	
	//FILTER THE QUERY STRING
	$query = str_replace("where and", "where", $query);	
	$query2 = str_replace("where and", "where", $query2);
	//query the database
	$sql = $db->select($query);	
	$sql2 = $db->select($query2);
	//count
	if($db->scount($sql) > 0) {	
?>
		<div class="col-sm-">
		
		
			<div id="all" class="tab-pane active">
			<?php print $title; ?>
			<div id="">
				<table class="table table-striped table-bordered table-hover dataTable no-footer">
					<thead>
						<tr role="row" style="font-weight:bold;font-size:18px">
							<th width="5%">#</th>
							<th width="12%">Fee Type</th>
							<th width="20%">Date</th>
							<th width="20%">Student</th>
							<th width="12%">Amount Paid</th>
							<th width="8%">Balance</th>
							<th>ACTION</th>
						</tr>
					</thead>
					<tbody aria-relevant="all" aria-live="polite" role="alert">
					<?php 
					//using the while loop
					while($result = $sql->fetch_assoc()) {
						//fetch the second query
						$result2 = $sql2->fetch_assoc();
						//fetch the student balance
						$balance = $student->getStudentById($result['studentunq'])->studentBalance;
						$amountDue = $balance;
						//initiate new balance
						$newbalance = $amountDue-$result2['amount'];
						if($sp==0)
							$amount=$result['amount'];
						elseif($sp==1)
							$amount=$result2['amount'];
						
						print "<tr align='left' class='gradeU'>";
						print "<td>{$result['id']}</td>";
						print "<td>{$result['feetype']}</td>";
						print "<td>".date("l d M Y", strtotime($result['date']))."</td>";
						print "<td>{$result['studentid']}</td>";
						/*if($result['feetypeid'] == 1)
							print "<td>{$amountDue}</td>";
						else
							print "<td>".$feestype->getFeeTypeById($result['feetypeid'])->feeTypeAmount."</td>";*/
						print "<td>{$amount}</td>";
						print "<td><strong>$balance</strong></td>";
						print "<td style='text-align:left'>";
						print  '
						<a href="'.SITE_URL.'/invoice-view/'.$result['unqid'].'" class="btn btn-info" data-placement="top" data-toggle="tooltip" data-original-title="View" title="View"><i class="fa fa-check-square-o"></i></a>
						<a href="'.SITE_URL.'/invoice-edit/'.$result['unqid'].'" class="btn btn-warning" data-placement="top" data-toggle="tooltip" data-original-title="Edit" title="Edit"><i class="fa fa-edit"></i></a>
						<a onclick="javascript:confirmSubmit(\''.$result['id'].'\',\'payments\', \'Payment of Student With ID - ('.$result['studentunq'].')\');" class="btn btn-danger" title="Delete" data-placement="top" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i></a>';
						print "</td>";
						print "</tr>";
						
					}
					?>
					</tbody>
			</table>
		</div>
		<script type="text/javascript">
			$("#example2").dataTable();
		</script>
	
		</div>
		
		
	</div>	
<?php
	} else {
?>
	<table class="table table-striped table-bordered table-hover dataTable no-footer">
	<tr>
		<th align="right">
		There are no  Payments currently in the database</th>
	</tr>
	</table>

<?php
	}
}