<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Administrator',$site->getSiteName());
//create a new object of the count model
$users = new UserModel;
?>

		<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
					<div class="box">
						<div class="box-header bg-purple">
							<h3 class="box-title"><i class="fa fa-users"></i> Administrators</h3>

						   
							<ol class="breadcrumb">
								<li><a href="<?php print SITE_URL; ?>"><i class="fa fa-laptop"></i> Dashboard</a></li>
								<li class="active">Administrators</li>
							</ol>
						</div><!-- /.box-header -->
						<!-- form start -->
						<div class="box-body">
							<div class="row">
								<div class="col-sm-12">

									<h5 class="page-header">
										<a class="btn btn-success" href="<?php print SITE_URL; ?>/users-add">
											<i class="fa fa-plus"></i> 
											Add an Administrator                        </a>
									</h5>
									
						
									
									<div class="col-sm-12">

									<div class="nav-tabs-custom ">
										
										<div class="box-header bg-red">
											<h3 class="box-title">
												All Administrators
											</h3>
										</div>
										
										
										<div class="tab-content">
										<div id="all" class="tab-pane active">
										<div id="hide-table">
											<div id="example1_wrapper" class="dataTables_wrapper form-inline" role="grid">
											<table aria-describedby="example1_info" id="example1" class="table table-striped table-bordered table-hover dataTable no-footer">
												<thead>
												<tr role="row" style="font-weight:bold">
													<td>ID</td>
													<td>FULLNAME</td>
													<td>USERNAME</td>
													<td>ROLE</td>
													<td>LAST ACCESS</td>
													<?php if(isset($_SESSION["theFutureAdminLoggedIns"])) { ?>
													<td>ACTION</td>
													<?php } ?>
												</tr>
												</thead>

												<tbody aria-relevant="all" aria-live="polite" role="alert">
													<?php print $users->getAdminUsers("", "LIMIT 5000", "DESC"); ?>
												</tbody>
											</table>
											</div>
										</div>

										</div>
									</div>
									

									</div> <!-- nav-tabs-custom -->
									</div>
									
								</div>
							</div>
						</div><?php //body div ?>
					</div><?php //box div ?>
				</div><?php //col-sm-12 div ?>
			</div><?php //row div ?>
		</section>
	</aside>
		<script type="text/javascript">
            $(function() {
                $("#example1").dataTable();
                $('#example2').dataTable({
                    "bPaginate": true,
                    "bLengthChange": false,
                    "bFilter": false,
                    "bSort": true,
                    "bInfo": true,
                    "bAutoWidth": false
                });
            });
        </script>
<?php
//get the page footer to include
template_footer();
?>