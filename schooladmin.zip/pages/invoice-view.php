<?php
//include the header of the website
$pageDescription = $site->getSiteDescription();
require 'core/checkaccess.php';
template_header('Invoice - View',$site->getSiteName());
//create a new object of the count model
$invoices = new Invoices;
$student = new Students;
?>
	
	<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
	    <div class="well bg-purple">
        <div class="row">

            <div class="col-sm-6">
                <button class="btn-cs btn-sm-cs" onclick="javascript:printDiv('printablediv')"><span class="fa fa-print"></span> Print </button>
				<?php if(isset($ACTION[1]) and $invoices->getInvoiceById($ACTION[1])->invoiceResult==true) { ?>
					<a href="<?php print SITE_URL; ?>/invoice-history/<?php print $invoices->getInvoiceById($ACTION[1])->invoiceStudentUnq; ?>?n=<?php print $invoices->getInvoiceById($ACTION[1])->invoiceStudentUnq; ?>&c=<?php print $invoices->getInvoiceById($ACTION[1])->invoiceStudentClass; ?>&y=<?php print $invoices->getInvoiceById($ACTION[1])->invoiceAcademicYear; ?>&t=<?php print $invoices->getInvoiceById($ACTION[1])->invoiceTermR; ?>&ty=<?php print $invoices->getInvoiceById($ACTION[1])->invoiceFeeType; ?>&tyid=<?php print $invoices->getInvoiceById($ACTION[1])->invoiceFeeTypeID; ?>&cid=<?php print $invoices->getInvoiceById($ACTION[1])->invoiceStudentClassId; ?>" class="btn-cs btn-sm-cs" style="text-decoration: none;" role="button"><i class="fa fa-check-square-o"></i> View History</a>
					<a href="<?php print SITE_URL; ?>/invoice-edit/<?php print $ACTION[1]; ?>" class="btn-cs btn-sm-cs" style="text-decoration: none;" role="button"><i class="fa fa-edit"></i> Edit</a>
				<?php } ?>
				<a href="<?php print SITE_URL; ?>/invoice-create" class="btn-cs btn-sm-cs" style="text-decoration: none;" role="button"><i class="fa fa-credit-card"></i> Record New</a>
            </div>

            <div class="col-sm-6 active">
                <ol style="display: block;" class="breadcrumb">
                    <li><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i> Dashboard</a></li>
                    <li class="active"><a href="<?php print SITE_URL; ?>/invoice/index">Invoice</a></li>
                    <li class="active">View</li>
                </ol>
            </div>
        </div>
    </div>
<?php if(isset($ACTION[1]) and $invoices->getInvoiceById($ACTION[1])->invoiceResult==true) { ?>
	<?php if(isset($_GET['updated'])) { ?>
	<div class='btn btn-success'>Congrats! The Invoice has been successfully updated.</div><br><br>
	<?php } ?>
<div id="printablediv">
	<section class="content invoice">
		<!-- title row -->
		<div class="row">
		    <div class="col-xs-12">
		        <h2 class="page-header">
		            <img src="<?php print SITE_IMAGE_PATH; ?>/site.png" class="img-circle" alt="" height="25px" width="25px">
					<?php print SITE_NAME; ?><small class="pull-right">Create Date : <?php print date("d M Y"); ?></small>
		        </h2>
		    </div><!-- /.col -->
		</div>
		<!-- info row -->
		<div class="row invoice-info">
			
		    <div class="col-sm-4 invoice-col">
		   
				From
				<address>
					<strong><?php print SITE_NAME; ?></strong><br>
					<strong>Phone :</strong> <?php print $site->getSitePhone(); ?><br>
					<strong>Email :</strong> <?php print $site->getSiteEmail(); ?><br>
					<strong>Address : </strong> <?php print $site->getSiteAddress(); ?>
				</address>
	            

		    </div><!-- /.col -->
		    <div class="col-sm-4 invoice-col">
		        		        	To		        	<address>
		        		<strong><?php print $invoices->getInvoiceById($ACTION[1])->invoiceStudentName; ?></strong><br>
		        		Class : <?php print $invoices->getInvoiceById($ACTION[1])->invoiceStudentClass; ?><br>
		        		Email : <?php print $invoices->getInvoiceById($ACTION[1])->invoiceStudentEmail; ?><br>
						Phone : <?php print $invoices->getInvoiceById($ACTION[1])->invoiceStudentPhone; ?><br>
		        	</address>
		        
		    </div><!-- /.col -->
		    <div class="col-sm-4 invoice-col">
		        <b>Invoice ID: <?php print $invoices->getInvoiceById($ACTION[1])->invoiceUnq; ?></b><br>
		        <b>Payment Date :  </b><?php print $invoices->getInvoiceById($ACTION[1])->invoiceDate; ?><br>
				<b>Academic Year : </b><?php print $invoices->getInvoiceById($ACTION[1])->invoiceAcademicYear; ?><br>
				<b>Term : </b><?php print $invoices->getInvoiceById($ACTION[1])->invoiceTerm; ?><br>
				<b>Payment Status : </b><?php print $invoices->getInvoiceById($ACTION[1])->paymentStatus; ?>
				
				
				
		    </div><!-- /.col -->
		</div><!-- /.row -->

		<!-- Table row -->
        <br>
		<div class="row">
			<div class="col-xs-12" id="hide-table">
		        <table class="table table-striped">
		            <thead>
		                <tr>
		                    <th class="col-lg-1">#</th>
		                    <th class="col-lg-9">Fee Type</th>
		                    <th class="col-lg-2">Total</th>
		                </tr>
		            </thead>
		            <tbody>
		                <tr>
		                    <td data-title="#">
		                        1
							</td>
		                    <td data-title="Fee Type">
								<?php print $invoices->getInvoiceById($ACTION[1])->invoiceFeeType; ?>
							</td>
		                    <td data-title="Sub Total">
                                GHc <?php print $invoices->getInvoiceById($ACTION[1])->invoiceFeeTypeAmount; ?>
							</td>
		                </tr>
		            </tbody>
		        </table>
		    </div>
		</div><!-- /.row -->

		<div class="row">
		    <!-- accepted payments column -->
		    <div class="col-sm-6">
		    </div><!-- /.col -->
		    <div class="col-xs-12 col-sm-6 col-lg-6 col-md-18">
		        <p class="lead">Amount</p>
		        <div class="table-responsive">
		            <table class="table">
		                <tbody><tr>
                            <th class="col-sm-8 col-xs-8">Sub Total</th>
                            <td class="col-sm-4 col-xs-4"><?php print $invoices->getInvoiceById($ACTION[1])->invoiceSubTotal; ?></td>
		                </tr>
		            </tbody></table>
                                            <table class="table">
                            <tbody><tr>
                                <th class="col-sm-8 col-xs-8">Payment Made</th>
                                <td class="col-sm-4 col-xs-4"><?php print $invoices->getInvoiceById($ACTION[1])->invoiceAmount; ?></td>
                            </tr>
                        </tbody></table>

                        <table class="table">
                            <tbody><tr>
                                <th class="col-sm-8 col-xs-8">Balance (GHC)</th>
                            <td class="col-sm-4 col-xs-4">GHc<?php print $student->getStudentById($invoices->getInvoiceById($ACTION[1])->invoiceStudentUnq)->studentBalance; ?></td>
                            </tr>
                        </tbody></table>
                    
		        </div>
		    </div><!-- /.col -->
		</div><!-- /.row -->

		<!-- this row will not appear when printing -->
	</section><!-- /.content -->
</div>

<script language="javascript" type="text/javascript">
    function printDiv(divID) {
        //Get the HTML of div
        var divElements = document.getElementById(divID).innerHTML;
        //Get the HTML of whole page
        var oldPage = document.body.innerHTML;

        //Reset the page's HTML with div's HTML only
        document.body.innerHTML = 
          "<html><head><title></title></head><body>" + 
          divElements + "</body>";

        //Print Page
        window.print();

        //Restore orignal HTML
        document.body.innerHTML = oldPage;
    }
    function closeWindow() {
        location.reload(); 
    }
    
</script>
 <?php } else {
		print '<div id="printablediv">
		<section class="content invoice">';
		PageNotFound();
		print '</section>';
		print '</div>';
	} ?>
                    </div>
                </div>
            </section>
        </aside>
<?php
//get the page footer to include
template_footer();
?>