<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
require 'core/checkaccess.php';

$db=new Database;
$design = new Designation;
$employees = new Employees;
$payhead = new Payhead;
$payheads = new Payhead;

if(isset($_POST['loadSalaries']) and isset($_POST['call_all'])) {
	//add additional 
	$add = "";
	$title = "";
	//get user payrolls
	if(isset($_POST['filter'])) {
		$title = "<div class=\"btn btn-info\">Filtering Payroll ";
		if(isset($_POST['eid']) and $_POST['eid'] != "0") {
			$eid = $db->cleanData($_POST['eid']);
			$add .= "`employeeid`='{$eid}' AND ";
			$title .= "per <strong>Employee ID - ".$eid. "</strong> ";
		}
		if(isset($_POST['mid']) and $_POST['mid'] != "0") {
			$mid = $db->cleanData($_POST['mid']);
			$add .= "`month`='{$mid}' AND ";
			$title .= "per <strong>Month - ".$mid. "</strong> ";
		}
		if(isset($_POST['yid']) and $_POST['yid'] != "0") {
			$yid = $db->cleanData($_POST['yid']);
			$add .= "`year`='{$yid}' AND ";
			$title .= "per <strong>Year - ".$yid. "</strong> ";
		}
		$title .= "</div><br><hr>";
	}
	
	
	//query the database
	$sql = $db->select("SELECT 
						id, sum(amount) as amount,employeeid,month,year,payhead
					FROM `payroll` WHERE $add status='1' GROUP BY month, year, employeeid ORDER BY `id` desc");	
	//count
	if($db->scount($sql) > 0) {
		
?>
		<div class="col-sm-">
		
		
			<div id="all" class="tab-pane active">
			<?php print $title; ?>
			<div id="hide-table">
				<table id="example2" class="table table-striped table-bordered table-hover dataTable no-footer col-sm-12">
					<thead>
					<tr role="row">
						<td>ID</td>
						<td width="30%">NAME</td>
						<td>PERIOD</td>
						<td>PAYHEAD</td>
						<td>AMOUNT</td>
						<td>BALANCE</td>
						<td>ACTION</td>
					</tr>
					</thead>
					<tbody aria-relevant="all" aria-live="polite" role="alert">
					<?php 
						//using the while loop
						while($result = $sql->fetch_assoc()) {
							//check the salary_settings of the employee
							$check = $db->select("SELECT * FROM `salary_settings` WHERE `employeeid`='{$result['employeeid']}'");
							if($db->scount($check) > 0) {
								$res = $check->fetch_assoc();
								//fetch the balance in the employee salary settings table
								$bal = $res['balance'];
								if($bal > 0) {
									$back = "style='color:red'";
									$balance = "You owe {$employees->getEmployeeById($result['employeeid'])->teacherName} a total of GHc".$bal;
								} else {
									$back = '';
									$balance = "No outstanding salary to be paid";
								}
							} else {
								$back = '';
								$bal = 0.00;
								$balance = "No outstanding salary to be paid";
							}
							print "<tr align='left' $back title='{$balance}'>";
							print "<td><strong>{$result['id']}</strong></td>";
							print "<td><strong>{$employees->getEmployeeById($result['employeeid'])->teacherName}</strong></td>";
							print "<td><strong>{$design->getMonthById($result['month'])->monName} {$result['year']}</strong></td>";
							print "<td><strong>{$payheads->getPayheadById($result['payhead'])->payHeadName}</strong></td>";
							print "<td><strong>{$result['amount']}</strong></td>";
							print "<td><strong>{$bal}</strong></td>";
							print '<td><a href="'.SITE_URL.'/payroll-view/'.$result['id'].'" class="btn btn-info" data-placement="top" data-toggle="tooltip" data-original-title="View" title="View"><i class="fa fa-check-square-o"></i></a>
							<a onclick="javascript:confirmSubmit(\''.$result['id'].'\',\'payroll\', \'Payroll of '.$employees->getEmployeeById($result['employeeid'])->teacherName.' - for the Period ('.$design->getMonthById($result['month'])->monName.' '.$result['year'].')\');"   class="btn btn-danger" data-placement="top" data-toggle="tooltip" data-original-title="View" title="Delete"><i class="fa fa-trash-o"></i></a>';
							print "</td>";
							print "</tr>";
						}
					?>
					</tbody>
				</table>
			</div>
			<script type="text/javascript">
				$("#example2").dataTable();
			</script>
		
			</div>
			
			
		</div>
		
<?php
	} else {
?>
	<table class="table table-striped table-bordered table-hover dataTable no-footer">
	<tr>
		<th align="right">
		There are no Salary Payroll currently in the database <?php print $title; ?></th>
	</tr>
	</table>

<?php
	}
}
elseif(isset($_POST['empPayment']) and isset($_POST['employeeID'])) {
	
	$employeeID = strtolower($db->cleanData($_POST['employeeID']));
	
	if(!isset($_POST['details'])) {
		print "<span class='btn btn-info'> This employee is entitled to <strong>GHc ".$payhead->getSalarySettingsById($employeeID)->amount."
				</strong> a month.</span>";
	} else {
		$mid = $db->cleanData($_POST['mid']);
		$yid = $db->cleanData($_POST['yid']);
?>
	<table class="table table-striped table-bordered table-hover dataTable no-footer">
		<tr role="row" style="font-weight:bold;font-size:18px">
			<td width="20%">OUTSTANDING BAL.</td>
			<td width="20%">SALARY</td>
			<td width="20%">TOTAL AMOUNT DUE</td>
			<td width="20%">AMOUNT PAID</td>
			<td width="20%" style="color:#ff4000">BALANCE PAYABLE</td>
		</tr>
		<tr>
			<td>
				<?php print "GHc ".$payhead->getSalarySettingsById($employeeID)->balance; ?>
			</td>
			<td>
				<?php print "GHc ".$payhead->getSalarySettingsById($employeeID)->amount; ?>
			</td>
			<td>
				<?php print "GHc ".$t=$payhead->getSalarySettingsById($employeeID)->balance+$payhead->getSalarySettingsById($employeeID)->amount; ?>
			</td>
			<td>
				<?php print "GHc ".$payhead->paymentDetails(
								$employeeID,
								$payhead->getSalarySettingsById($employeeID)->amount,
								$mid,
								$yid
							)->amt; ?>
			</td>
			<td style="color:#ff4000;font-weight:bolder;font-size:18px">
				<?php print "GHc ".$payhead->paymentDetails(
								$employeeID,
								$payhead->getSalarySettingsById($employeeID)->amount,
								$mid,
								$yid
							)->bal; ?>
			</td>
		</tr>
	</table>
<?php
	}
	
}
?>