<?php
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$feestype = new FeesType;
$classes = new Classes;
$invoices = new Invoices;
require 'core/checkaccess.php';

if(isset($_POST['listGuardian']) and isset($_POST['call_all'])) {
	
	//query the database
	$sql = $db->select("SELECT * FROM `guardian` WHERE status='1' ORDER BY `id` ASC");	
	//count
	if($db->scount($sql) > 0) {
?>
		
		<div class="col-sm-12">
			<div id="all" class="tab-pane active">
			<div id="hide-table">
				<table id="example1" class="table table-striped table-bordered table-hover dataTable no-footer col-sm-12">
					<thead>
					<tr role="row">
						<td>ID</td>
						<td width="35%">NAME</td>
						<td width="">PHONE </td>
						<td width="23%">ACTION</td>
					</tr>
					</thead>
					<tbody aria-relevant="all" aria-live="polite" role="alert">
					<?php 
						//using the while loop
						while($result = $sql->fetch_assoc()) {
							//print out the result
							print "<tr align='left' class='gradeU'>";
							print "<td><strong>{$result['id']}</strong></td>";
							print "<td>{$result['fullname']}</td>";
							print "<td>{$result['phone']}</td>";
							print '<td><a href="'.SITE_URL.'/guardian-view/'.$result['id'].'" class="btn btn-info" data-placement="top" data-toggle="tooltip" data-original-title="View" title="View Details of '.$result['fullname'].'"><i class="fa fa-check-square-o"></i></a>
							<a title="Edit Details of '.$result['fullname'].'" href="'.SITE_URL.'/guardian-edit/'.$result['id'].'" class="btn btn-warning" data-placement="top" data-toggle="tooltip" data-original-title="View"><i class="fa fa-edit"></i></a>';
							print "</td>";
							print "</tr>";
						}
					?>
					</tbody>
				</table>
			</div>
			</div>
		</div>
		<script type="text/javascript">
            $("#example1").dataTable({"iDisplayLength": 15, "fSort": [0,'desc']});
        </script>
<?php
	} else {
?>
	<table class="table table-striped table-bordered table-hover dataTable no-footer">
	<tr>
		<th align="right">
		There are no Parents / Guardians currently in the database</th>
	</tr>
	</table>

<?php
	}
}
?>