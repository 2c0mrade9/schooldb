<?php
require 'core/checkaccess.php';
//include the header of the website
$pageDescription = $site->getSiteDescription();
template_header('Teacher - View',$site->getSiteName());
//create a new object of the count model
$employees = new Employees;
?>

		<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        
    <div class="well bg-purple">
        <div class="row">
            <div class="col-sm-6" style="">
                <button class="btn-cs btn-sm-cs" onclick="javascript:printDiv('printablediv')"><span class="fa fa-print"></span> Print </button>
                <button class="btn-cs btn-sm-cs" data-toggle="modal" data-target="#idCard"><span class="fa fa-floppy-o"></span> ID Card </button>
                <a href="<?php print SITE_URL; ?>/employee-edit/<?php print $ACTION[1]; ?>" class="btn-cs btn-sm-cs" style="text-decoration: none;" role="button"><i class="fa fa-edit"></i> Edit</a>
				</div>
            <div class="col-sm-6">
                <ol class="breadcrumb">
                    <li><a href="<?php print SITE_URL; ?>"><i class="fa fa-laptop"></i> Dashboard</a></li>
                    <li class="active"><a href="<?php print SITE_URL; ?>/employee/index">Employees</a></li>
                    <li class="active">View</li>
                </ol>
            </div>
        </div>   
    </div>
    
	<?php if(isset($ACTION[1]) and $employees->getEmployeeById($ACTION[1])->teacherResult==true) { ?>
    <div id="printablediv">
        <section class="panel">
            <div class="profile-view-head bg-blue">
                <a href="#">
                    <img src="<?php print SITE_IMAGE_PATH; ?>/default.png" alt="">                </a>

                <h1><?php print $employees->getEmployeeById($ACTION[1])->teacherName; ?></h1>
                <p><?php print $employees->getEmployeeById($ACTION[1])->teacherDesig; ?></p>
            </div>
            <div class="panel-body profile-view-dis" style="color:#000;font-size:14px">
                <h1 style="color:green">Personal Information</h1>
                <div class="row">
                    <div class="profile-view-tab">
                        <p><span>Date of Birth </span>: <?php print $employees->getEmployeeById($ACTION[1])->teacherDob; ?></p>
                    </div>
                    <div class="profile-view-tab">
                        <p><span>Joining Date </span>: <?php print $employees->getEmployeeById($ACTION[1])->teacherJoin; ?></p>
                    </div>
                    <div class="profile-view-tab">
                        <p><span>Gender </span>: <?php print $employees->getEmployeeById($ACTION[1])->teacherGender; ?></p>
                    </div>
                    <div class="profile-view-tab">
                        <p><span>Religion </span>: <?php print $employees->getEmployeeById($ACTION[1])->teacherReligion; ?></p>
                    </div>
                    <div class="profile-view-tab">
                        <p><span>Email </span>: <?php print $employees->getEmployeeById($ACTION[1])->teacherEmail; ?></p>
                    </div>
                    <div class="profile-view-tab">
                        <p><span>Phone </span>: <?php print $employees->getEmployeeById($ACTION[1])->teacherPhone; ?></p>
                    </div>
                    <div class="profile-view-tab">
                        <p><span>Address </span>: <?php print $employees->getEmployeeById($ACTION[1])->teacherAddress; ?></p>
                    </div>
                    <div class="profile-view-tab">
                        <p><span>Username </span>: <?php print $employees->getEmployeeById($ACTION[1])->teacherUser; ?></p>
                    </div>
		<hr>
			<div class="profile-view-tab">
                        <p><span>Qualification </span>: <?php print $employees->getEmployeeById($ACTION[1])->teacherQualification; ?></p>
                    </div>
			<div class="profile-view-tab">
                        <p><span>Certificate Obtained </span>: <?php print $employees->getEmployeeById($ACTION[1])->teacherCert; ?></p>
                    </div>
			<div class="profile-view-tab">
                        <p><span>Last School Attended </span>: <?php print $employees->getEmployeeById($ACTION[1])->teacherSchool; ?></p>
                    </div>
			<div class="profile-view-tab">
                        <p><span>Experience </span>: <?php print $employees->getEmployeeById($ACTION[1])->teacherExperience; ?></p>
                    </div>
                </div>

            </div>
        </section>
    </div>

    
    <!-- Modal content start here -->
    <div class="modal fade" id="idCard">
      <div class="modal-dialog">
        <div class="modal-content" style="background-color">
            <div id="idCardPrint">
              <div class="modal-header">
                <?php print $employees->getEmployeeById($ACTION[1])->teacherDesig; ?> ID Card
				</div>
              <div class="modal-body"> 
                    <table>
                        <tbody><tr>
                            <td>
                                <h4 style="margin:0;">
                                <img src="<?php print SITE_IMAGE_PATH; ?>/site.png" style="margin-bottom:10px;" alt="" height="25px" width="25px">                                </h4>
                            </td>
                            <td style="padding-left:5px;">
                                <h4><?PHP PRINT SITE_NAME; ?></h4>
                            </td>
                        </tr>
                    </tbody></table>

                <table class="idcard-Table" style="background-color:#173640">
                    <tbody><tr>
                        <td>
                            <h4>
                        <img src="<?php print SITE_IMAGE_PATH; ?>/default.png" style="border: 8px solid #2F6C7F" alt="">                            </h4> 
                        </td>
                        <td class="row-style">
                            <h3><?php print $employees->getEmployeeById($ACTION[1])->teacherName; ?></h3>
                            <h5>Designation : <?php print $employees->getEmployeeById($ACTION[1])->teacherDesig; ?>                            </h5>
                            <h5>Email : <?php print $employees->getEmployeeById($ACTION[1])->teacherEmail; ?>                            </h5>
                            <h5>
                                Phone :        <?php print $employees->getEmployeeById($ACTION[1])->teacherPhone; ?>                     </h5>
                        </td>
                    </tr>
                </tbody></table>    
              </div>
            </div>
          <div class="modal-footer">
            <button type="button" style="margin-bottom:0px;" class="btn btn-default" onclick="javascript:closeWindow()" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-success" onclick="javascript:printDiv('idCardPrint')">Print</button>
          </div>
        </div>
      </div>
    </div>
    <!-- Modal content End here -->

    <script language="javascript" type="text/javascript">
        function printDiv(divID) {
            //Get the HTML of div
            var divElements = document.getElementById(divID).innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            document.body.innerHTML = 
              "<html><head><title></title></head><body>" + 
              divElements + "</body>";

            //Print Page
            window.print();

            //Restore orignal HTML
            document.body.innerHTML = oldPage;
        }
        function closeWindow() {
            location.reload(); 
        }
    </script>
		
		<?php
			} else {
				PageNotFound();
			}
		?>

    
 
                    </div>
                </div>
            </section>
        </aside>
		
<?php
//get the page footer to include
template_footer();
?>
