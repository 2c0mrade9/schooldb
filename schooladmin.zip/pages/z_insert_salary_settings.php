<?php 
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$models = new Models;
require 'core/checkaccess.php';

if(isset($_POST['designID']) and isset($_POST['employeeID']) and isset($_POST['amount']) and isset($_POST['payhead']) and is_numeric($_POST['payhead'])) {
	if(is_numeric($_POST['designID']) and is_numeric($_POST['amount'])) {
		
		
		$d = $db->cleanData($_POST['designID']);
		$e = $db->cleanData($_POST['employeeID']);
		$a = $db->cleanData($_POST['amount']);
		$p = $db->cleanData($_POST['payhead']);
		$admin = $_SESSION['Username'];
		
		$check = $db->select("SELECT * FROM `salary_settings` WHERE `designation`='$d' AND `payhead`='$p'
								AND `employeeid`='$e'
							");
		if($db->scount($check) > 0) {
			print "<div class='btn btn-danger'>Sorry! This salary setting already exists in the database for the specified employee.</div><Br><Br>";
		} else {
			$insert = $db->insert("INSERT INTO `salary_settings` (designation,payhead,employeeid,amount,balance,rdate,rname) VALUES (
				'$d','$p','$e','$a','$a',now(),'$admin'
			)");
			
			if($insert) {
				print "Congrats! Salary Settings was successfully inserted";
			} else {
				print "Sorry! There was an error inserting the Salary Settings.";
			}
		}
								
	} else {
		print "<div class='btn btn-danger'>Sorry! You have supplied an invalid inputs. Amount must be only Numerics (0-9)</div><br><br>";
	}
} else {
	print "<div class='btn btn-danger'>Sorry! You have supplied an invalid inputs.</div><Br><Br>";
}

?>