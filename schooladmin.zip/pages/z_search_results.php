<?php 
/********************************************************************************
* This script is written by Emmanuel Obeng
* Email: emmallob14@gmail.com
* Do not remove this copyright information from the top of this code.
*********************************************************************************/
$db=new Database;
$models = new Models;
$classes = new Classes;
$students = new Students;
$guardian = new Guardian;
$employees = new Employees;
$designation = new Designation;

require 'core/checkaccess.php';
//check if the form has been submitted
if(isset($_POST['q']) and isset($_POST['s'])) {
	//check the number of characters parsed
	if(strlen($_POST['q']) < 3) {
		//print '<div class="btn btn-danger">Sorry! A minimum of 3 characters is required for the search term.</div>';
	} else {
		//clean the data submitted by the user
		$q = $db->cleanData($_POST['q']);
		$s = strtolower($db->cleanData($_POST['s']));
		//now lets run some documentation based on the search type submitted.
		//since the default search type is for students lets run the students model to get the information.
		?>
			<div id="example1_wrapper" style="border-top:solid 1px #000" class="dataTables_wrapper form-inline" role="grid">
			<table aria-describedby="example1_info" id="example1" class="table table-striped table-bordered table-hover dataTable no-footer">
			<thead>
			<tr role="row">
		<?php
		if($s=="students") {
			?>
				<td>ID</td>
				<td>FULLNAME</td>
				<td>CLASS</td>
				<td>GUARDIAN/PHONE</td>
				<td>PHONE</td>
				<td>ACTION</td>
				</tr>
				</thead>
			<tbody aria-relevant="all" aria-live="polite" role="alert">
			<?php $students->getStudents("`surname` LIKE '%$q%' OR firstname LIKE '%$q%'");
		} elseif($s=="guardian") {
		?>
			
			<td>ID</td>
			<td>FULLNAME</td>
			<td>PROFESSION</td>
			<td>WARD</td>
			<td>PHONE</td>
			<td width="17%">ACTION</td>
			</tr>
			</thead>
			<tbody aria-relevant="all" aria-live="polite" role="alert">
			<?php $guardian->getGuardians("`fullname` LIKE '%$q%' OR phone LIKE '%$q%'"); ?>
		<?php
		} elseif($s=="employees") {
		?>
			<td>ID</td>
			<td>FULLNAME</td>
			<td>DESIGNATION</td>
			<td>QUALIFICATION</td>
			<td>CLASS</td>
			<td>PHONE</td>
			<td>ACTION</td>
			</tr>
			</thead>
			<tbody aria-relevant="all" aria-live="polite" role="alert">
			<?php print $employees->getEmployees("`fullname` LIKE '%$q%' OR phone LIKE '%$q%'", "LIMIT 5000", "DESC"); ?>
		<?php
		} elseif($s=="designation") {
		?>
			<td>ID</td>
			<td width="35%">NAME</td>
			<td width="">Number </td>
			<td width="23%">ACTION</td>
			</tr>
			</thead>
			<tbody aria-relevant="all" aria-live="polite" role="alert">
			<?php print $designation->getDesignation("`name` LIKE '%$q%'", "LIMIT 5000", "DESC"); ?>
		
		<?php
		} elseif($s=="class") {
		?>
			<td>ID</td>
			<td width="15%">CLASS</td>
			<td width="20%">TEACHER NAME</td>
			<td width="20%">NUMBER OF STUDENTS</td>
			<td width="20%">FEES PAYABLE</td>
			<td>ACTION</td>
			</tr>
			</thead>
			<tbody aria-relevant="all" aria-live="polite" role="alert">
			<?php print $classes->getClasses("`name` LIKE '%$q%'", "LIMIT 5000", "DESC"); ?>
		
		<?php } ?>
			</tbody>
		</table>
		</div>
		<?php
	}
} else {
	//display error message
	print '<div class="btn btn-danger">Sorry! No results found for search term.</div>';
}
?>
<script type="text/javascript">
	$(function() {
		$("#example1").dataTable();
	});
</script>