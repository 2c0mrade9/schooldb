<?php
//include the header of the website
require 'core/checkaccess.php';
$pageDescription = $site->getSiteDescription();
template_header('Home Page',$site->getSiteName());
//create a new object of the count model
$count = new CountModel;
$students = new Students;
$employees = new Employees;
$guardian = new Guardian;
?>

<aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        

	  <div class="row">
		<div class="col-lg-3 col-xs-6">
			<div class="small-box ">
				<a class="small-box-footer" href="<?php print SITE_URL; ?>/invoice/index">
					<div class="icon bg-purple" style="padding: 9.5px 18px 8px 18px;">
						<i class="fa fa-money"></i>
					</div>
					<div class="inner ">
						<h3>
							&nbsp;
						</h3>
						<p>
							Fees Payments
						</p>
					</div>
				</a>
			</div>
		</div>
	  
		<div class="col-lg-3 col-xs-6">
			<div class="small-box ">
				<a class="small-box-footer" href="<?php print SITE_URL; ?>/payroll/index">
					<div class="icon bg-aqua" style="padding: 9.5px 18px 8px 18px;">
						<i class="fa fa-sitemap"></i>
					</div>
					<div class="inner ">
						<h3>
							&nbsp;
						</h3>
						<p>
							Payroll
						</p>
					</div>
				</a>
			</div>
		</div>

		<div class="col-lg-3 col-xs-6">
			<div class="small-box ">
				<a class="small-box-footer" href="<?php print SITE_URL; ?>/salary-settings/index">
					<div class="icon bg-red" style="padding: 9.5px 18px 8px 18px;">
						<i class="fa fa-gears"></i>
					</div>
					<div class="inner ">
						<h3>
							&nbsp;
						</h3>
						<p>
							Salary Settings</p>
					</div>
				</a>
			</div>
		</div>
		
		<div class="col-lg-3 col-xs-6">
			<div class="small-box ">
				<a class="small-box-footer" href="<?php print SITE_URL; ?>/payhead-add/index">
					<div class="icon bg-green" style="padding: 9.5px 18px 8px 18px;">
						<i class="fa fa-user"></i>
					</div>
					<div class="inner ">
						<h3>
							&nbsp;
						</h3>
					  <p>
						Pay Heads
					</p>
					</div>
				</a>
			</div>
		</div>

	  </div>


 
		  <div class="row"> 
			<div class="col-sm-3">
					  <section class="panel">
				  <div class="profile-db-head">
					<a href="<?php print SITE_URL; ?>/profile/index">
					  <img src="<?php print SITE_IMAGE_PATH; ?>/site.png" alt="">            </a>

					<h1><?php print SITE_NAME; ?></h1>
					<p><?php print $_SESSION['Username']; ?></p>

				  </div>
				  <table class="table table-hover">
					  <tbody>
						  <tr>
							<td>
							  <i class="glyphicon glyphicon-user" style="color:#FDB45C;"></i>
							</td>
							<td>Username</td>
							<td><?php print $_SESSION['Username']; ?></td>
						  </tr>
						  <tr>
							  <td>
								<i class="fa fa-envelope" style="color:#FDB45C;"></i>
							  </td>
							  <td>Email</td>
							<td><?php print $site->getSiteEmail(); ?></td>
						  </tr>
						  <tr>
							<td>
							  <i class="fa fa-phone" style="color:#FDB45C;"></i>
							</td>
							<td>Phone</td>
							<td><?php print $site->getSitePhone(); ?></td>
						  </tr>
						  <tr>
							<td>
							  <i class=" fa fa-globe" style="color:#FDB45C;"></i>
							</td>
							<td>Address</td>
							<td><?php print $site->getSiteAddress; ?></td>
						  </tr>
					  </tbody>
				  </table>
				</section>
				  </div>
			<div class="col-sm-9">
			  <div class="box">
				<div class="box-header" style="background-color:#FDB45C;">
					<h3 class="box-title">
						Fees Payments
					</h3>
				</div>
				<div class="col-sm-12" style="background-color:#fff;">
					<div class="box-body" style="padding: 0px;">
						<div id="loadPaymentsView"></div>
					</div>
				</div>

			  </div>
			</div>
			<div class="col-sm-9">
			  <div class="box">
				<div class="box-header" style="background-color:#FDB45C;">
					<h3 class="box-title">
						Payroll
					</h3>
				</div>
				<div class="col-sm-12" style="background-color:#fff;">
					<div class="box-body" style="padding: 0px;">
						<div id="payrollview"></div>
					</div>
				</div>

			  </div>
			</div><br><hr><br>
			<div class="col-sm-9" style="float:right">
			  
			  <div class="box">
				<div class="box-header" style="background-color:#FDB45C;">
					<h3 class="box-title">
						Salary Settings
					</h3>
				</div>

				<div class="box-body" style="padding: 0px;">
					<table width="100%" class="table table-hover">
						<thead>
							<tr>
								<td>ID</td>
								<td width="30%">NAME</td>
								<td>DESIGNATION</td>
								<td>PAYHEAD</td>
								<td>AMOUNT</td>
								<td>BALANCE</td>
								<td>ACTION</td>
							</tr>
						</thead>
						<tbody>
							<?php print $employees->fetchSalarySettings(); ?>
						</tbody>
					</table>
				</div>
				

			  </div>
				
				</div>
			
			  </div>
			</div>
			

		  </div>

 
                    </div>
                </div>
            </section>
        </aside>
		<script>
		loadSalaries();
		function loadSalaries() {
			$.ajax({
				type: 'POST',
				url: "<?php print SITE_URL; ?>/z_call_payroll",
				data: "loadSalaries&call_all",
				dataType: "html",
				success: function(data) {
				   $('#payrollview').html(data);
				}
			});
		}
		loadSalariesView();
		function loadSalariesView() {
			$.ajax({
				type: 'POST',
				url: "<?php print SITE_URL; ?>/z_call_salary_settings",
				data: "loadSalaries&call_all",
				dataType: "html",
				success: function(data) {
				   $('#loadSalariesView').html(data);
				}
			});
		}
		loadPaymentsView();
		function loadPaymentsView() {
			$.ajax({
				type: "POST",
				data: "showcase",
				url: "<?php print SITE_URL; ?>/z_call_invoice",
				success: function(response) {
					$("#loadPaymentsView").html(response);
				}
			});
		}
		</script>
<?php
//get the page footer to include
template_footer();
?>