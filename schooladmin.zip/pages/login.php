<?php
$logoutGoTo = "dashboard";
if (!isset($_SESSION)) {
    session_start();
}

if (isset($_GET['logout'])) {
    $_SESSION['CMS_Username'] = NULL;
    $_SESSION['aUserID'] = NULL;
    $_SESSION['Level'] = NULL;
    $_SESSION['User_Role'] = NULL;
    $_SESSION['LastAccess'] = NULL;
	$_SESSION['theCEPSAdminLoggedIn'] = NULL;
	$_SESSION['FullName'] = NULL;		
	$_SESSION['Administrator'] = NULL;
	$_SESSION['theFutureAdminLoggedIns'] = NULL;
	$_SESSION['AcademicYear'] = NULL;
	$_SESSION['Term'] = NULL;
	
	unset($_SESSION['theFutureAdminLoggedIn']);
	unset($_SESSION['theFutureAdminLoggedIns']);
    unset($_SESSION['aCMS_Username']);
    unset($_SESSION['aUserID']);
    unset($_SESSION['Level']);
	unset($_SESSION['AcademicYear']);
	unset($_SESSION['Term']);
    unset($_SESSION['User_Role']);
    unset($_SESSION['LastAccess']);   
	unset($_SESSION['FullName']);
    unset($_SESSION['Administrator']);
}

// *** Validate request to login to this site.
if (!isset($_SESSION)) {
    session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
    $_SESSION['PrevUrl'] = $_GET['accesscheck'];
} else {
	$_SESSION['PrevUrl'] = $site->getSiteUrl()."/settings";
}

if (isset($_POST['Username'])) {
    $Username = stripslashes($_POST['Username']);
    $password = stripslashes($_POST['Password']);
    $cmsUserAuthorization = "Level";
    $cmsRedirectSuccess = $site->getSiteUrl()."/settings";
    $cmsRedirectLoginFailed = "?error&";
    $cmsRedirectToReferer = true;
	
	//trim the information give by user
	$Username = $db->cleanData($Username);
	$Username = htmlspecialchars($Username);
	
	$password = $db->cleanData($password);
	
	//encrypt the password given by the user
	$actPassword = $password;
	//$actPassword = md5("LoggedInAdmin").$encryptedPassword;
	$actPassword = md5(sha1($actPassword));
	//print $actPassword;
	
	//make query
	$sql = $db->select("SELECT * FROM `tb_admin` WHERE `Username`='$Username' AND `Password`='$actPassword' AND `Activated`='1'") or trigger_error ($db->db_error()); 
	$count = $db->scount($sql);
	
	$login_check = $sql->fetch_assoc();

	if( $count == 1 ){ 

		// Create the id session var
		$id = $login_check["id"];   
		$_SESSION['aUserID'] = $id;
			
		$username = $login_check["Username"];   
		$_SESSION['Username'] = $username;
			
		//getnerate the main session for the website
		$randNum = rand(9999, 999999999999);
		$_SESSION['theFutureAdminLoggedIn'] = base64_encode("g4p3h9xfn8sq03hs2234$id").$randNum;       

		$role = $login_check["Role"];   
		$_SESSION['User_Role'] = $role;
		
		if($role == 1)
			$_SESSION['theFutureAdminLoggedIns'] = $randNum.time();
		if($role == 1)
			$_SESSION['prop'] = $randNum.time();
			
		$LastAccess = $login_check["LastAccess"];   
		$_SESSION['LastAccess'] = $LastAccess;
		
		$sq = $db->select("select * from cepstb_options");
		while($res = $sq->fetch_assoc()) {
			$_SESSION['Term'] = $res["Term"];
			$_SESSION['AcademicYear'] = $res["AcademicYear"];
		}
			
		$FullName = $login_check["FullName"];   
		$_SESSION['FullName'] = $FullName;
			
		$FirstName = $login_check["FirstName"];   
		$_SESSION['FirstName'] = $FirstName;
			
		$Email = $login_check["Email"];   
		$_SESSION['Email'] = $Email;
			
		$level = $login_check["Level"];   
		$_SESSION['Level'] = $level;
		//update the information
		$db->update("UPDATE `tb_admin` SET `LastAccess`=now() WHERE id='$id'") or trigger_error($db->db_error()); 
		//redirect the user the success page
		if(strlen($_POST['redirect']) > 5)
			print "<script>window.location.href='{$db->cleanData($_POST['redirect'])}'</script>";
		else
			print "<script>window.location.href='{$site->getSiteUrl()}/settings'</script>";
	} else {
		if(strlen($_POST['redirect']) > 5)
			print "<script>window.location.href='{$site->getSiteUrl()}/login?error&redirect=".$_POST['redirect']."'</script>";
		else 
			print "<script>window.location.href='{$site->getSiteUrl()}/login?error'</script>";
   }
} 

$pageTitle = "Sign In";
$cPageRedirect = str_ireplace(
			array("login","logout","logout_success"),
			array("settings","","login"), $_SERVER['REQUEST_URI']);
?>
<!DOCTYPE html>
<html class="white-bg-login" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Sign in | <?PHP PRINT SITE_NAME; ?></title>
    <link rel="SHORTCUT ICON" href="<?php print SITE_IMAGE_PATH; ?>/site.png">
    <!-- bootstrap 3.0.2 -->
    <link href="<?php print SITE_CSS_PATH; ?>/bootstrap.css" rel="stylesheet" type="text/css">
    <!-- font Awesome -->
    <link href="<?php print SITE_CSS_PATH; ?>/font-awesome.css" rel="stylesheet" type="text/css">
    <!-- Style -->
    <link href="<?php print SITE_CSS_PATH; ?>/style.css" rel="stylesheet" type="text/css">
    <!-- iNilabs css -->
    <link href="<?php print SITE_CSS_PATH; ?>/inilabs.css" rel="stylesheet" type="text/css">
    <link href="<?php print SITE_CSS_PATH; ?>/responsive.css" rel="stylesheet" type="text/css">
</head>

<body class="white-bg-login" style="background:url(<?php print SITE_IMAGE_PATH; ?>/loginbg.jpg) repeat scroll #1A2229;">

    <div class="col-md-4 col-md-offset-4 marg" style="margin-top:30px;">
        <center><img src="<?php print SITE_IMAGE_PATH; ?>/site.png" height="50" width="50"></center>
		<center><h4><?php print SITE_NAME; ?></h4></center>
    </div>

     
<div class="form-box" id="login-box" style="height:460px;bottom:0px;">
    <?php if(!isset($ACTION[1])) { ?>
	<div class="header bg-fuchsia">SIGN IN</div>
	
    <form method="post" action="<?php print SITE_URL; ?>/login">

        <!-- style="margin-top:40px;" -->

        <div class="body white-bg">
				<?php if(isset($_GET['error']))  { ?>
					<div style="text-align:center" class="alert alert-danger">
						<strong>Invalid Username and / or Password</strong>
					</div>
				<?php } ?>
				<?php if(isset($_GET['logout_success']))  { ?>
					<div style="text-align:center" class="alert alert-success">
						<strong>Successfully Logged out</strong>
					</div>
				<?php } ?>
            <div class="form-group">
                <input class="form-control" placeholder="Username" id="Username" name="Username" autofocus="" type="text">
            </div>
            <div class="form-group">
                <input class="form-control" placeholder="Password" id="Password" name="Password" type="password">
            </div>     


            <div class="checkbox">
                <label>
                    <input value="Remember Me" name="remember" type="checkbox">
					<input value="" name="redirect" type="hidden">
                    <span> &nbsp; Remember Me</span>
                </label>
                <span class="pull-right">
                    <label>
                        <a href="<?php print SITE_URL; ?>/login/forgotten-password"> Forgot Password?</a>
                    </label>
                </span>
            </div>
            <input class="btn btn-lg btn-success btn-block" value="SIGN IN" type="submit">
        </div>
    </form>
	<?php } ?>
	<br clear="all">
	<div class="body white-bg bg-green" align="center"><strong>CREATED BY: </strong><?php print $site->getSiteAuthor(); ?></div>
</div>

</body></html>