-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2016 at 02:05 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `schooladmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `cepstb_options`
--

CREATE TABLE IF NOT EXISTS `cepstb_options` (
  `id` int(5) NOT NULL,
  `SiteType` varchar(50) DEFAULT NULL,
  `SiteName` varchar(255) NOT NULL,
  `SiteDomain` varchar(255) DEFAULT NULL,
  `SiteSlogan` varchar(255) DEFAULT NULL,
  `SiteDescription` text,
  `SiteEmail` varchar(255) DEFAULT NULL,
  `SitePhone` varchar(500) DEFAULT NULL,
  `SiteAddress` text,
  `SiteUrl` varchar(255) NOT NULL,
  `SiteUrlMain` varchar(255) NOT NULL,
  `SiteKeywords` text,
  `SiteHomePageText` text,
  `SiteFooterText` text,
  `SiteSEO` text NOT NULL,
  `SiteActive` tinyint(1) DEFAULT '1',
  `SiteActiveMsg` text NOT NULL,
  `Term` varchar(15) NOT NULL,
  `AcademicYear` varchar(10) NOT NULL,
  `CreatedBy` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cepstb_options`
--

INSERT INTO `cepstb_options` (`id`, `SiteType`, `SiteName`, `SiteDomain`, `SiteSlogan`, `SiteDescription`, `SiteEmail`, `SitePhone`, `SiteAddress`, `SiteUrl`, `SiteUrlMain`, `SiteKeywords`, `SiteHomePageText`, `SiteFooterText`, `SiteSEO`, `SiteActive`, `SiteActiveMsg`, `Term`, `AcademicYear`, `CreatedBy`) VALUES
(1, 'main', 'Future VIP''s School', NULL, '', 'Future VIP''s School stands out tall when you want to make a comparison of the best JHS''s currently running in the country. We have the best and well educated teachers with over a decade of experience who attend to each and every kid at a point in time to ensure that all at par.  We can also boast of large and serene environment which will enable students have a conducive environment for teaching and learning ', 'info@futurevip.com', '+233 (0) 503-778-2119', '<p>\nFuture VIP''s School\n<br>\nP.O. Box 2<br />\nAccra, Ghana\n</p>', 'http://localhost/schooladmin', '', 'school management system, php school database system, future, vip, future vip school, future vip east legon, HTML,CSS,XML,JavaScrip,php,codeigniter, accra, east legon, djen ayor, jhs school, best jhs school', '', '', '', 1, '', '1', '2015/2016', 'Emmallen Networks (0554947764) - emmallob14@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
  `id` int(11) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `teacher` int(11) NOT NULL DEFAULT '0',
  `fees` int(10) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `slug`, `name`, `teacher`, `fees`, `note`) VALUES
(1, 'class-1', 'Class 1', 0, 205, ''),
(2, 'class-2', 'Class 2', 0, 205, ''),
(3, 'class-3', 'Class 3', 0, 205, ''),
(4, 'class-4', 'Class 4', 0, 205, ''),
(5, 'class-5', 'Class 5', 0, 205, ''),
(6, 'class-6', 'Class 6', 0, 205, ''),
(7, 'jhs-1', 'JHS 1', 3, 250, ''),
(8, 'jhs-2', 'JHS 2', 0, 250, ''),
(9, 'jhs-3', 'JHS 3', 2, 305, ''),
(10, 'kindergaten-i', 'Kindergaten I', 0, 205, ''),
(11, 'kindergaten-ii', 'Kindergaten II', 0, 205, ''),
(12, 'nursery-i', 'Nursery I', 0, 305, ''),
(13, 'nursery-ii', 'Nursery II', 0, 305, '');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE IF NOT EXISTS `designation` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `slug` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`id`, `name`, `slug`) VALUES
(1, 'Teacher', 'teacher'),
(2, 'Administrator', 'administrator'),
(3, 'Secretary', 'secretary'),
(4, 'Director', 'director'),
(5, 'Proprietriess', 'proprietriess'),
(6, 'Caterer', 'caterer');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(11) NOT NULL,
  `class` int(11) NOT NULL DEFAULT '0',
  `fullname` varchar(255) NOT NULL,
  `designation` int(5) NOT NULL DEFAULT '0',
  `dob` date NOT NULL,
  `gender` enum('Male','Female','Null') NOT NULL,
  `religion` varchar(255) NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `djoin` date NOT NULL,
  `salary` int(11) NOT NULL,
  `balance` int(11) NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT 'assets/images/default.png',
  `qualification` int(11) NOT NULL,
  `full_qualification` text NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `rdate` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `class`, `fullname`, `designation`, `dob`, `gender`, `religion`, `email`, `phone`, `address`, `djoin`, `salary`, `balance`, `photo`, `qualification`, `full_qualification`, `username`, `password`, `status`, `rdate`) VALUES
(1, 6, 'Frank Amoako', 3, '1990-03-20', 'Male', '1', 'frankamoako@gmail.com', '0203317732', '', '2015-09-01', 0, 0, 'assets/images/default.png', 3, '', 'franky', '', '1', '2015-10-04'),
(2, 9, 'Sithole Kofi Norgbe', 2, '1989-06-14', 'Male', '1', 'sitholenorgbey@gmail.com', '0554263215', 'Tesa', '2015-09-01', 0, 0, 'assets/images/default.png', 2, '', '', '', '1', '2015-10-03'),
(3, 7, 'Emmanuel Obeng', 1, '1992-03-22', 'Male', '1', 'emmallob14@gmail.com', '0554947764', 'Adjiringanor', '2015-10-04', 0, 0, 'assets/images/default.png', 6, '', '2015-09-07', '', '1', '2015-10-03'),
(4, 0, 'Philomena Mensah', 3, '1994-07-20', 'Female', '1', 'philomens@gmail.com', '020554214', 'Adjiringanor, old town', '2015-10-14', 0, 0, 'assets/images/default.png', 5, 'More experience in the French language', 'annon', '', '1', '2015-10-06'),
(5, 0, 'Nicholas Boadi', 2, '2009-06-10', 'Male', '1', 'nicholasboadi@yahoo.com', '0254215400', 'Adjiringanor, old town', '2015-10-01', 0, 0, 'assets/images/default.png', 4, 'Over 10 years of experience in teaching social studies and RME. I have taught in at least 5 schools over the past 10 years and have acquired various degrees of knowledge and experiece. and that makes me superb', 'annon', '', '1', '2015-10-07');

-- --------------------------------------------------------

--
-- Table structure for table `finance_feestype`
--

CREATE TABLE IF NOT EXISTS `finance_feestype` (
  `id` int(11) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `type` varchar(255) NOT NULL,
  `level` enum('1','2') NOT NULL DEFAULT '1',
  `note` text NOT NULL,
  `amount` int(11) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `finance_feestype`
--

INSERT INTO `finance_feestype` (`id`, `slug`, `type`, `level`, `note`, `amount`, `status`) VALUES
(1, 'school-fees', 'School Fees', '1', '', 0, '1'),
(2, 'classes-fees', 'Classes Fees', '1', '', 1, '1'),
(3, 'feeding-fees', 'Feeding Fees', '1', '', 3, '1'),
(4, 'sports-fee', 'Sports Fee', '1', '', 1, '1'),
(5, 'p-t-a-dues', 'P.T.A Dues', '1', '', 5, '1'),
(6, 'admission-forms', 'Admission Forms', '1', '', 50, '1');

-- --------------------------------------------------------

--
-- Table structure for table `guardian`
--

CREATE TABLE IF NOT EXISTS `guardian` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `profession` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `occupation` varchar(50) NOT NULL,
  `ward` varchar(10) NOT NULL DEFAULT '0',
  `photo` varchar(255) NOT NULL DEFAULT 'assets/images/default.png',
  `rdate` date NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guardian`
--

INSERT INTO `guardian` (`id`, `fullname`, `profession`, `phone`, `email`, `address`, `occupation`, `ward`, `photo`, `rdate`, `status`) VALUES
(1, 'Paul Darlington Obeng', 'Driver', '0203317732', '', '', '', 'VIP0510', 'assets/images/default.png', '0000-00-00', '1'),
(2, 'Mr Frank Amoako', 'Driver', '0542154251', 'mrfrankamo@gmail.com', 'Otano first stop', 'Driver', 'VIP3510', 'assets/images/default.png', '2015-10-03', '1'),
(4, 'Mr. Silas Tagoe', 'Presbytry', '0207238338', '', '', 'Presbytry', 'VIP2810', 'assets/images/default.png', '2015-10-05', '1');

-- --------------------------------------------------------

--
-- Table structure for table `months`
--

CREATE TABLE IF NOT EXISTS `months` (
  `id` int(11) NOT NULL,
  `name` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `months`
--

INSERT INTO `months` (`id`, `name`) VALUES
(1, 'January'),
(2, 'February'),
(3, 'March'),
(4, 'April'),
(5, 'May'),
(6, 'June'),
(7, 'July'),
(8, 'August'),
(9, 'September'),
(10, 'October'),
(11, 'November'),
(12, 'December');

-- --------------------------------------------------------

--
-- Table structure for table `payhead`
--

CREATE TABLE IF NOT EXISTS `payhead` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payhead`
--

INSERT INTO `payhead` (`id`, `name`, `slug`, `description`) VALUES
(1, 'Feeding Allowances', 'feeding-allowances', ''),
(2, 'Basic Salary', 'basic-salary', 'This Is The Basic Salary Of An Employee And He Is Entitled To This In Addition To Other Payments.'),
(3, 'Full Salary', 'full-salary', '');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL,
  `unqid` varchar(20) NOT NULL,
  `feetypeid` int(5) NOT NULL DEFAULT '0',
  `feetype` varchar(50) NOT NULL DEFAULT '0',
  `studentid` varchar(50) NOT NULL DEFAULT '0',
  `studentunq` varchar(15) NOT NULL,
  `studentemail` varchar(50) NOT NULL,
  `studentphone` varchar(15) NOT NULL,
  `class` varchar(50) NOT NULL,
  `classid` int(11) NOT NULL,
  `amount` varchar(10) NOT NULL,
  `academicyear` varchar(15) NOT NULL,
  `term` varchar(15) NOT NULL,
  `date` date NOT NULL,
  `rdate` date NOT NULL,
  `rname` varchar(50) NOT NULL,
  `status` varchar(5) NOT NULL DEFAULT '1',
  `updater` varchar(60) NOT NULL,
  `dateupd` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `unqid`, `feetypeid`, `feetype`, `studentid`, `studentunq`, `studentemail`, `studentphone`, `class`, `classid`, `amount`, `academicyear`, `term`, `date`, `rdate`, `rname`, `status`, `updater`, `dateupd`) VALUES
(1, 'INV3139953', 1, 'School Fees', 'Setsofia Paula', '6987', '', '', 'JHS 1', 7, '200', '2015/2016', '1', '2015-10-02', '2015-10-05', 'annon', '1', '', '0000-00-00'),
(2, 'INV3899230', 1, 'School Fees', 'Tagoe Tryzinna', 'VIP2810', '', '', 'JHS 1', 7, '200', '2015/2016', '1', '2015-10-02', '2015-10-05', 'annon', '1', '', '0000-00-00'),
(3, 'INV8627319', 1, 'School Fees', 'Tagoe Tryzinna', 'VIP2810', '', '', 'JHS 1', 7, '200', '2015/2016', '1', '2015-10-03', '2015-10-05', 'annon', '1', '', '0000-00-00'),
(4, 'INV2403564', 1, 'School Fees', 'Baah Akwasi', 'VIP9510', '', '', 'JHS 1', 7, '50', '2015/2016', '1', '2015-10-07', '2015-10-07', 'annon', '1', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

CREATE TABLE IF NOT EXISTS `payroll` (
  `id` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `designation` int(11) NOT NULL,
  `payhead` int(11) NOT NULL,
  `employeeid` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `rdate` date NOT NULL,
  `rname` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payroll`
--

INSERT INTO `payroll` (`id`, `month`, `designation`, `payhead`, `employeeid`, `amount`, `rdate`, `rname`) VALUES
(1, 9, 1, 3, 3, 350, '2015-10-08', 'annon'),
(2, 10, 1, 3, 3, 350, '2015-11-23', 'annon'),
(3, 10, 2, 3, 5, 400, '2015-11-23', 'annon');

-- --------------------------------------------------------

--
-- Table structure for table `qualification`
--

CREATE TABLE IF NOT EXISTS `qualification` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qualification`
--

INSERT INTO `qualification` (`id`, `name`, `slug`) VALUES
(1, 'JHS', 'jhs'),
(2, 'SHS', 'shs'),
(3, 'O''Level', 'o-level'),
(4, 'A''Level', 'a-level'),
(5, '1st Degree', '1st-degree'),
(6, '2nd Degree', '2nd-degree'),
(7, 'Professor in Theological Studies', 'professor-in-theological-studies');

-- --------------------------------------------------------

--
-- Table structure for table `religion`
--

CREATE TABLE IF NOT EXISTS `religion` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `religion`
--

INSERT INTO `religion` (`id`, `name`, `slug`) VALUES
(1, 'Christianity', ''),
(2, 'Islam', ''),
(3, 'Hindu', ''),
(4, 'Hari Krishna', ''),
(5, 'Ekankar', ''),
(6, 'Catholic', ''),
(7, 'Mozama Disco Christo Church', 'mozama-disco-christo-chur');

-- --------------------------------------------------------

--
-- Table structure for table `salary_settings`
--

CREATE TABLE IF NOT EXISTS `salary_settings` (
  `id` int(11) NOT NULL,
  `designation` int(11) NOT NULL,
  `payhead` int(11) NOT NULL,
  `employeeid` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `balance` int(11) NOT NULL,
  `rdate` date NOT NULL,
  `rname` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salary_settings`
--

INSERT INTO `salary_settings` (`id`, `designation`, `payhead`, `employeeid`, `amount`, `balance`, `rdate`, `rname`) VALUES
(1, 1, 3, 3, 350, -350, '2015-10-08', 'annon'),
(2, 2, 3, 5, 450, 50, '2015-10-08', 'annon'),
(3, 3, 3, 4, 300, 300, '2015-10-08', 'annon'),
(4, 2, 3, 2, 350, 350, '2015-10-08', 'annon');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `id` int(11) NOT NULL,
  `studentunq` varchar(255) NOT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `nameslug` varchar(255) NOT NULL,
  `parent` int(11) DEFAULT '0',
  `teacher` int(11) NOT NULL DEFAULT '0',
  `dob` date DEFAULT NULL,
  `gender` enum('Male','Female','Null') DEFAULT NULL,
  `religion` int(11) DEFAULT '0',
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `class` int(11) NOT NULL DEFAULT '0',
  `photo` varchar(255) NOT NULL DEFAULT 'assets/images/default.png',
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `rname` varchar(50) NOT NULL,
  `rdate` date NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `studentunq`, `surname`, `firstname`, `nameslug`, `parent`, `teacher`, `dob`, `gender`, `religion`, `email`, `phone`, `language`, `address`, `class`, `photo`, `username`, `password`, `rname`, `rdate`, `status`) VALUES
(1, 'VIP0510', 'Owusu Kwabena', 'Daniel', '', 1, 2, '2000-03-08', 'Male', 1, 'emmallob14@gmail.com', '0554947764', '', 'P.O.Box AF 2582, Adentan', 9, 'assets/images/default.png', '', '', '', '0000-00-00', '1'),
(2, 'VIP3510', 'Osei Ampofo', 'Cathrine', '', 2, 2, '2004-06-16', 'Female', 1, '', '', 'French', 'Adjiringanor', 9, 'assets/images/default.png', '', '', 'emman', '2015-10-03', '1'),
(3, 'VIP9510', 'Baah', 'Akwasi', '', 0, 3, '2005-11-15', 'Male', 1, '', '', '', '', 7, 'assets/images/default.png', '', '', 'emman', '2015-10-03', '1'),
(4, 'VIP2810', 'Tagoe', 'Tryzinna', '', 4, 3, '2004-08-28', 'Female', 1, '', '', '', '', 7, 'assets/images/default.png', '', '', 'emman', '2015-10-03', '1'),
(5, '6987', 'Setsofia', 'Paula', '', 0, 3, '2002-05-29', 'Female', 1, '', '', '', '', 7, 'assets/images/default.png', '', '', 'annon', '2015-10-05', '1'),
(6, 'VIP2786', 'Amoako', 'Frank', 'amoakofrank8', 0, 0, '2000-07-17', 'Male', 1, '', '', 'Twi, English', '', 8, 'assets/images/default.png', '', '', 'annon', '2015-10-06', '1');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE IF NOT EXISTS `subjects` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `year` varchar(4) NOT NULL,
  `name` varchar(50) NOT NULL,
  `class` int(11) NOT NULL,
  `teacher` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `code`, `year`, `name`, `class`, `teacher`) VALUES
(1, 'acall-classes-ict-2015', '2015', 'ICT', 1, 3),
(2, 'acall-classes-ict-2015', '2015', 'ICT', 2, 3),
(3, 'acall-classes-ict-2015', '2015', 'ICT', 3, 3),
(4, 'acall-classes-ict-2015', '2015', 'ICT', 4, 3),
(5, 'acall-classes-ict-2015', '2015', 'ICT', 5, 3),
(6, 'acall-classes-ict-2015', '2015', 'ICT', 6, 3),
(7, 'acall-classes-ict-2015', '2015', 'ICT', 7, 3),
(8, '8-ict-2015', '2015', 'ICT', 8, 3),
(9, 'acall-classes-ict-2015', '2015', 'ICT', 9, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE IF NOT EXISTS `tb_admin` (
  `id` int(5) NOT NULL,
  `FirstName` varchar(50) NOT NULL DEFAULT '',
  `LastName` varchar(50) NOT NULL DEFAULT '',
  `FullName` varchar(120) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `lastPassChange` datetime NOT NULL,
  `lastPassChangeDays` int(30) NOT NULL,
  `PassSalt` varchar(200) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Level` varchar(20) NOT NULL DEFAULT 'editor',
  `Role` int(5) DEFAULT NULL,
  `SecureQuestion` varchar(200) DEFAULT NULL,
  `SecureAnswer` varchar(200) DEFAULT NULL,
  `LastAccess` datetime DEFAULT '0000-00-00 00:00:00',
  `Activated` tinyint(1) DEFAULT '0',
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id`, `FirstName`, `LastName`, `FullName`, `Username`, `Password`, `lastPassChange`, `lastPassChangeDays`, `PassSalt`, `Email`, `Level`, `Role`, `SecureQuestion`, `SecureAnswer`, `LastAccess`, `Activated`, `status`) VALUES
(1, 'Customs', 'Registry', 'Future VIP School', 'cregistry', '7e74dbc20b7e54a5319c426e1ffe1232 ', '0000-00-00 00:00:00', 0, NULL, 'cregistry@localhost', 'editor', 1, NULL, NULL, '2015-08-06 13:50:59', 1, '1'),
(2, 'Annonymous', 'Registry', 'Annonymous', 'annon', '7e74dbc20b7e54a5319c426e1ffe1232 ', '0000-00-00 00:00:00', 0, NULL, 'annon@localhost', 'editor', 3, NULL, NULL, '2016-01-07 13:01:43', 1, '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cepstb_options`
--
ALTER TABLE `cepstb_options`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `designation`
--
ALTER TABLE `designation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `finance_feestype`
--
ALTER TABLE `finance_feestype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guardian`
--
ALTER TABLE `guardian`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `months`
--
ALTER TABLE `months`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payhead`
--
ALTER TABLE `payhead`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payroll`
--
ALTER TABLE `payroll`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qualification`
--
ALTER TABLE `qualification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `religion`
--
ALTER TABLE `religion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salary_settings`
--
ALTER TABLE `salary_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usr_role_fk` (`Role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cepstb_options`
--
ALTER TABLE `cepstb_options`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `designation`
--
ALTER TABLE `designation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `finance_feestype`
--
ALTER TABLE `finance_feestype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `guardian`
--
ALTER TABLE `guardian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `months`
--
ALTER TABLE `months`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `payhead`
--
ALTER TABLE `payhead`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `payroll`
--
ALTER TABLE `payroll`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `qualification`
--
ALTER TABLE `qualification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `religion`
--
ALTER TABLE `religion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `salary_settings`
--
ALTER TABLE `salary_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
