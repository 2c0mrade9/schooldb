<?php
//Include the various contant files inside the website
require 'core/constants.php';
//automatically load all the models and classes
//that is needed in the website
function __autoload($class) {
	include("core/models/" . ($class) . ".php");
}
//@params pageTitle
//@params pageDescription
function template_header($pageTitle = '', $pageDescription) {
	//create a new object of the Options Class
	$site = new Options();
	global $ACTION;
	
	//$_SESSION['aCMS_Username'] = "obeng";
?>
<!DOCTYPE html>
<html style="min-height: 964px;"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="UTF-8">
        <?php
			echo '<title> '.( empty($pageTitle) ? '' : $pageTitle . ' | ').''.$site->getSiteName().'</title>';
		?>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        
        <meta name="description" content="<?php print $site->getSiteDescription; ?>">
		<meta name="keywords" content="<?php print $site->getSiteKeyWords; ?>">
		<meta name="author" content="<?php print $site->getSiteAuthor; ?>">
        <link rel="SHORTCUT ICON" href="<?php print SITE_IMAGE_PATH; ?>/site.png">
        
		<link href="<?php print SITE_CSS_PATH; ?>/bootstrap.css" rel="stylesheet">
        <link href="<?php print SITE_CSS_PATH; ?>/font-awesome.css" rel="stylesheet">
        <link href="<?php print SITE_CSS_PATH; ?>/icomoon.css" rel="stylesheet">
        <link href="<?php print SITE_CSS_PATH; ?>/dataTables.css" rel="stylesheet">
		<link href="<?php print SITE_CSS_PATH; ?>/loading-bar.css" rel="stylesheet">
        <link href="<?php print SITE_CSS_PATH; ?>/style.css" rel="stylesheet">
        <link href="<?php print SITE_CSS_PATH; ?>/datepicker.css" rel="stylesheet">
        <link href="<?php print SITE_CSS_PATH; ?>/timepicker.css" rel="stylesheet">
        <link href="<?php print SITE_CSS_PATH; ?>/hidetable.css" rel="stylesheet">
        <link href="<?php print SITE_CSS_PATH; ?>/inilabs.css" rel="stylesheet">
        <link href="<?php print SITE_CSS_PATH; ?>/responsive.css" rel="stylesheet">
        <link href="<?php print SITE_CSS_PATH; ?>/fullcalendar.css" rel="stylesheet">
        <link href="<?php print SITE_CSS_PATH; ?>/jquery-te-1.css" rel="stylesheet">
        <link href="<?php print SITE_CSS_PATH; ?>/toastr.css" rel="stylesheet">
        <link href="<?php print SITE_CSS_PATH; ?>/rid.css" rel="stylesheet">

        <link rel="stylesheet" href="<?php print SITE_CSS_PATH; ?>/select2.css">
        <link rel="stylesheet" href="<?php print SITE_CSS_PATH; ?>/select2-bootstrap.css">
        <link rel="stylesheet" href="<?php print SITE_CSS_PATH; ?>/gh-pages.css">
        <link rel="stylesheet" href="<?php print SITE_CSS_PATH; ?>/jqueryui.css">
		
		<script type="text/javascript" src="<?php print SITE_JS_PATH; ?>/jquery.js"></script>
        <script type="text/javascript" src="<?php print SITE_JS_PATH; ?>/datepicker.js"></script>
        <script type="text/javascript" src="<?php print SITE_JS_PATH; ?>/timepicker.js"></script>
        <script type="text/javascript" src="<?php print SITE_JS_PATH; ?>/toastr.js"></script>
        
		<script>
		function confirmSubmit(id,table,item) {
			if(confirm('Are you sure you want to delete this ' + item)) {
					$.ajax({
					type: "POST",  
					url: "<?php print SITE_URL; ?>/z_delete",  
					data: "pid="+id+"&table="+table+"&item_p="+item,
					success: function(response) {
							alert(item +' has been Deleted');
						window.location ='';
					}
				});
			}
		}
		</script>

    </head>
<body style="min-height: 964px;" class="skin-blue  pace-done"><!-- header logo: style can be found in header.less -->
        <header class="header active">
            <a href="<?php print SITE_URL; ?>/dashboard/index" class="logo">
                <!-- Add the class icon to your logo image or logo icon to add the margining -->
				<?php print SITE_NAME; ?>
            </a>
            <!-- Header Navbar: style can be found in header.less -->
            <nav class="navbar navbar-static-top" role="navigation">
                <!-- Sidebar toggle button-->
                <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <div class="navbar-right">
                    <ul class="nav navbar-nav">
                        <!-- Messages: style can be found in dropdown.less-->
						<li onclick="javascript:window.location.href='<?php print SITE_URL; ?>/settings'" 
							class="dropdown user user-menu" style="border-right:solid #000000 1px;padding:5px;cursor:pointer;" title="Click to Change the settings">
							Academic Year: <strong><?php print AC_YEAR; ?></strong><BR>
							Academic Term: <strong><?php print AC_TERM; ?></strong>
						</li>
						
                        <!-- User Account: style can be found in dropdown.less -->
						<li class="dropdown user user-menu">
                            <a href="<?php print SITE_URL; ?>/profile/index">
                                <div><i class="fa fa-briefcase"></i></div>
								Profile 
                            </a>
						</li>
                        <li class="dropdown user user-menu">
                            <a href="<?php print SITE_URL; ?>/login?logout">
                            <div><i class="fa fa-power-off"></i></div>
                            Log out 
							</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
		<div style="min-height: 494px;" class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside style="min-height: 964px;" class="left-side sidebar-offcanvas">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
                    <div class="user-panel bg-fuchsia">
                        <div class="pull-left image">
                            <img src="<?php print SITE_IMAGE_PATH; ?>/site.png" class="img-circle" alt="User Image">
                        </div>

                        <div class="pull-left info">
                            <p><?php print SITE_NAME; ?></p>
							<a href="<?php print SITE_URL; ?>/profile/index">
                                <i class="fa fa-hand-o-right color-green"></i>
                                <?php print $_SESSION['Username']; ?>
							</a>
                        </div>
                    </div>

                    <!-- sidebar menu: : style can be found in sidebar.less -->
                        <ul class="sidebar-menu">
                        <li <?php if($ACTION[0] == "dashboard") print 'class="active"'; ?>><a href="<?php print SITE_URL; ?>/dashboard/index"><i class="fa fa-laptop"></i><span>Dashboard</span></a></li>
                        <li <?php if($ACTION[0] == "student-edit" || $ACTION[0] == "student-view" || $ACTION[0] == "student-add" || $ACTION[0] == "student") print 'class="active"'; ?>><a href="<?php print SITE_URL; ?>/student/index"><i class="fa fa-users"></i><span>Student</span></a></li>
                        <li <?php if($ACTION[0] == "parents-add" || $ACTION[0] == "guardian-view" || $ACTION[0] == "parents") print 'class="active"'; ?>><a href="<?php print SITE_URL; ?>/parents/index"><i class="fa fa-user"></i><span>Parents</span></a></li>
                        <li <?php if($ACTION[0] == "designation-view" || $ACTION[0] == "designation") print 'class="active"'; ?>><a href="<?php print SITE_URL; ?>/designation/index"><i class="fa fa-briefcase "></i><span>Designation</span></a></li>
						<li <?php if($ACTION[0] == "employee-add" || $ACTION[0] == "employee-view" || $ACTION[0] == "employee") print 'class="active"'; ?>><a href="<?php print SITE_URL; ?>/employee/index"><i class="fa fa-sitemap "></i><span>Employee</span></a></li>
                        <li <?php if($ACTION[0] == "classes-view" || $ACTION[0] == "classes-add" || $ACTION[0] == "classes") print 'class="active"'; ?>><a href="<?php print SITE_URL; ?>/classes/index"><i class="fa fa-sitemap"></i><span>Class</span></a></li>
                        <li <?php if($ACTION[0] == "subject-add" || $ACTION[0] == "subject-view" || $ACTION[0] == "subject") print 'class="active"'; ?>><a href="<?php print SITE_URL; ?>/subject/index"><i class="fa fa-comments"></i><span>Subject</span></a></li>
						<li <?php if($ACTION[0] == "accounts" || $ACTION[0] == "fees-type") print 'class="active"'; ?>>
							<a href="<?php print SITE_URL; ?>/accounts/"><i class="fa fa-money"></i><span>Account</span></a>
						</li>       
                        <li <?php if($ACTION[0] == "report") print 'class="active"'; ?>><a href="<?php print SITE_URL; ?>/report/index"><i class="fa fa-clipboard"></i><span>Report</span></a></li>
						<li <?php if($ACTION[0] == "user") print 'class="active"'; ?>><a href="<?php print SITE_URL; ?>/user/"><i class="fa fa-users"></i><span>Admin User</span></a></li>                        
                        <li <?php if($ACTION[0] == "settings") print 'class="active"'; ?>><a href="<?php print SITE_URL; ?>/setting/index"><i class="fa fa-gears"></i><span>Setting</span></a></li>  
						<li <?php if($ACTION[0] == "close-account") print 'class="active"'; ?>><a href="<?php print SITE_URL; ?>/close-account/index"><i class="fa fa-money"></i><span>Close Account</span></a></li>  
                    </ul>
                    
                </section>
                <!-- /.sidebar -->
            </aside>
			
			<?php if($ACTION[0] !="search1") { ?>
			<aside class="right-side">
            <section class="content">
                <div class="col-xs-12 bg-aqua" align="center" style="background:#fff;padding:5px;border-radius:4px;">
						<form method="get" action="<?php print SITE_URL; ?>/search1" id="search_form" name="search_form">
							<span style="font-weight:bold;font-size:16px;">Search: </span>
							<input type="text" name="q" value="<?php $db = new Database; if(isset($_GET['q'])) print $db->cleanData($_GET['q']); ?>" id="q" style="padding:3px;border-radius:3px;font-size:14px;width:500px;">
							<input type="hidden" name="search_type" value="<?php if(isset($_GET['search_type'])) print $db->cleanData($_GET['search_type']); else print 'Students'; ?>">
							<input class="btn btn-" value="Search" type="submit">
						</form>
				</div>
			</section>
			</aside>
			<?php } ?>
			<?php if($ACTION[0] =="search1") { ?>
			<aside class="right-side">
				<section class="content">
					
				</section>
			</aside>
			<?php } ?>
			
<?php } ?>
    


<?php function template_footer() { ?>
		
		</div>
        <!-- start:footer -->
		 <!-- Jquery datatable js -->
        <script type="text/javascript" src="<?php print SITE_JS_PATH; ?>/jquery_002.js"></script>
        
		<!-- Bootstrap js -->
        <script type="text/javascript" src="<?php print SITE_JS_PATH; ?>/jquery.dataTables.js"></script>
		<script type="text/javascript" src="<?php print SITE_JS_PATH; ?>/dataTables.bootstrap.js"></script>
        <!-- Style js -->
        <script type="text/javascript" src="<?php print SITE_JS_PATH; ?>/style.js"></script>

       <!-- Datatable js -->
        <script type="text/javascript" src="<?php print SITE_JS_PATH; ?>/dataTables.js"></script>

        <script type="text/javascript" src="<?php print SITE_JS_PATH; ?>/inilabs.js"></script>

        <!-- autocomplete plugin select2 js -->
        <script type="text/javascript" src="<?php print SITE_JS_PATH; ?>/select2.js"></script>

        <!-- Jquery UI jquery -->
        <script src="<?php print SITE_JS_PATH; ?>/jqueryui.js" type="text/javascript" charset="utf-8" async="" defer="defer"></script>
        
        <!-- Jquery gritter -->
		<script>
            $( ".select2" ).select2( { placeholder: "Select username", maximumSelectionSize: 6 } );
            $( ".guargianID" ).select2( { placeholder: "Select Guargian" , maximumSelectionSize: 6 } );

            $( "button[data-select2-open]" ).click( function() {
                $( "#" + $( this ).data( "select2-open" ) ).select2( "open" );
            });
			$('#example2').dataTable();
			$('#example1').dataTable();
		    
        </script>
        
</body>
<?php } ?>

<?php function die404() { ?>

<?php
$pageTitle = "Page Not Found";
require 'core/checkaccess.php';
template_header($pageTitle, "");

?>

     <aside class="right-side">
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
					<div class="error-page">
						<h2 class="headline text-info"> 404</h2>
						<div class="error-content">
							<h3><i class="fa fa-warning text-yellow"></i> Oops! Page not found.</h3>
							<p>
								We could not find the page you were looking for.
								Meanwhile, you may <a href="<?php print SITE_URL; ?>">return to dashboard</a> or try using the search form.
							</p>
						</div><!-- /.error-content -->
					</div><!-- /.error-page --> 
                    </div>
                </div>
            </section>
        </aside>
	
<?php
//get the page footer to include
template_footer();
?>

<?php } ?>

<?php function pageNotFound() { ?>
	<section class="">
        <div class="">
            <div class="col-xs-12">
				<div class="error-page">
					<h2 class="headline text-info"> 404</h2>
					<div class="error-content">
						<h3><i class="fa fa-warning text-yellow"></i> Oops! Page not found.</h3>
						<p>
							We could not find the page you were looking for.<Br>
							<a href="<?php print SITE_URL; ?>">RETURN TO DASHBOARD</a> or <a href="<?php print SITE_URL; ?>/search">SEARCH</a>
						</p>
					</div><!-- /.error-content -->
				</div><!-- /.error-page --> 
            </div>
        </div>
    </section>
 
<?php } ?>