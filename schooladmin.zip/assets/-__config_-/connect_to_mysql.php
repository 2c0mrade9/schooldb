<?php 
# FileName='Connection_php_mysql.htm' 
# Type='MYSQL' 
# HTTP='true' 
//setting the database variables
$hostname_config = "localhost"; 
$database_config = "schooladmin"; 
$username_config = "root"; 
$password_config = ""; 
//defining them as constant
define("DB_HOST", $hostname_config ); 
define("DB_USER", $username_config ); 
define("DB_PASS", $password_config ); 
define("DB_NAME", $database_config ); 

//connection to the database
$mysqli = new mysqli($hostname_config, $username_config, $password_config, $database_config);

//checking for errors
if ($mysqli->connect_errno) {
	die('Connect Error: ' . $mysqli->connect_errno);
}
?>