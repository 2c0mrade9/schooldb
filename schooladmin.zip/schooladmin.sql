-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2016 at 08:59 PM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `schooladmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `cepstb_options`
--

CREATE TABLE `cepstb_options` (
  `id` int(5) NOT NULL,
  `SiteType` varchar(50) DEFAULT NULL,
  `SiteName` varchar(255) NOT NULL,
  `SiteDomain` varchar(255) DEFAULT NULL,
  `SiteSlogan` varchar(255) DEFAULT NULL,
  `SiteDescription` text,
  `SiteEmail` varchar(255) DEFAULT NULL,
  `SitePhone` varchar(500) DEFAULT NULL,
  `SiteAddress` text,
  `SiteUrl` varchar(255) NOT NULL,
  `SiteUrlMain` varchar(255) NOT NULL,
  `SiteKeywords` text,
  `SiteHomePageText` text,
  `SiteFooterText` text,
  `SiteSEO` text NOT NULL,
  `SiteActive` tinyint(1) DEFAULT '1',
  `SiteActiveMsg` text NOT NULL,
  `Term` varchar(15) NOT NULL,
  `AcademicYear` varchar(10) NOT NULL,
  `CreatedBy` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cepstb_options`
--

INSERT INTO `cepstb_options` (`id`, `SiteType`, `SiteName`, `SiteDomain`, `SiteSlogan`, `SiteDescription`, `SiteEmail`, `SitePhone`, `SiteAddress`, `SiteUrl`, `SiteUrlMain`, `SiteKeywords`, `SiteHomePageText`, `SiteFooterText`, `SiteSEO`, `SiteActive`, `SiteActiveMsg`, `Term`, `AcademicYear`, `CreatedBy`) VALUES
(1, 'main', 'Future VIP''s School', NULL, '', 'Future VIP''s School stands out tall when you want to make a comparison of the best JHS''s currently running in the country. We have the best and well educated teachers with over a decade of experience who attend to each and every kid at a point in time to ensure that all at par.  We can also boast of large and serene environment which will enable students have a conducive environment for teaching and learning ', 'info@futurevip.com', '+233 (0) 503-778-2119', '<p>\nFuture VIP''s School\n<br>\nP.O. Box 2<br />\nAccra, Ghana\n</p>', 'http://localhost/schooladmin', '', 'school management system, php school database system, future, vip, future vip school, future vip east legon, HTML,CSS,XML,JavaScrip,php,codeigniter, accra, east legon, djen ayor, jhs school, best jhs school', '', '', '', 1, '', '2', '2015/2016', 'Emmallen Networks (0554947764) - emmallob14@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `id` int(11) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `teacher` int(11) NOT NULL DEFAULT '0',
  `fees` int(10) NOT NULL,
  `note` text NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `slug`, `name`, `teacher`, `fees`, `note`, `status`) VALUES
(1, 'class-1', 'Class 1', 0, 205, '', '1'),
(2, 'class-2', 'Class 2', 0, 205, '', '1'),
(3, 'class-3', 'Class 3', 0, 205, '', '1'),
(4, 'class-4', 'Class 4', 0, 205, '', '1'),
(5, 'class-5', 'Class 5', 0, 205, '', '1'),
(6, 'class-6', 'Class 6', 0, 205, '', '1'),
(7, 'jhs-1', 'JHS 1', 3, 250, '', '1'),
(8, 'jhs-2', 'JHS 2', 0, 250, '', '1'),
(9, 'jhs-3', 'JHS 3', 2, 305, '', '1'),
(10, 'kindergaten-i', 'Kindergaten I', 0, 205, '', '1'),
(11, 'kindergaten-ii', 'Kindergaten II', 0, 205, '', '1'),
(12, 'nursery-i', 'Nursery I', 0, 305, '', '1'),
(13, 'nursery-ii', 'Nursery II', 0, 305, '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `delete_history`
--

CREATE TABLE `delete_history` (
  `id` int(11) NOT NULL,
  `delby` varchar(150) NOT NULL,
  `content` varchar(500) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delete_history`
--

INSERT INTO `delete_history` (`id`, `delby`, `content`, `date`) VALUES
(1, 'annon', 'Deleted Student with Name ', '2014-01-16 16:05:18');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `slug` varchar(25) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`id`, `name`, `slug`, `status`) VALUES
(1, 'Teacher', 'teacher', '1'),
(2, 'Administrator', 'administrator', '1'),
(3, 'Secretary', 'secretary', '1'),
(4, 'Director', 'director', '1'),
(5, 'Proprietriess', 'proprietriess', '1'),
(6, 'Caterer', 'caterer', '1'),
(7, 'Web Designer', 'web-designer', '1');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `uniqueid` varchar(15) DEFAULT NULL,
  `class` int(11) NOT NULL DEFAULT '0',
  `fullname` varchar(255) NOT NULL,
  `designation` int(5) NOT NULL DEFAULT '0',
  `dob` date NOT NULL,
  `gender` enum('Male','Female','Null') NOT NULL,
  `religion` varchar(255) NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `djoin` date NOT NULL,
  `salary` int(11) NOT NULL,
  `balance` int(11) NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT 'assets/images/default.png',
  `qualification` int(11) NOT NULL,
  `certificate` varchar(50) DEFAULT NULL,
  `schoolname` varchar(60) DEFAULT NULL,
  `full_qualification` text NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `rdate` datetime NOT NULL,
  `admin` varchar(15) NOT NULL,
  `headteacher_remarks` text NOT NULL,
  `proprietries_remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `uniqueid`, `class`, `fullname`, `designation`, `dob`, `gender`, `religion`, `email`, `phone`, `address`, `djoin`, `salary`, `balance`, `photo`, `qualification`, `certificate`, `schoolname`, `full_qualification`, `username`, `password`, `status`, `rdate`, `admin`, `headteacher_remarks`, `proprietries_remarks`) VALUES
(1, 'FVIPT2345', 6, 'Frank Amoako', 3, '1990-03-20', 'Male', '1', 'frankamoako@gmail.com', '0203317732', '', '2015-09-01', 0, 0, 'assets/images/default.png', 3, NULL, NULL, '', 'franky', '', '1', '2015-10-04 00:00:00', '', '', ''),
(2, 'FVIPT8743', 9, 'Sithole Kofi Norgbe', 1, '1989-06-14', 'Male', '1', 'sitholenorgbey@gmail.com', '0554263215', 'Tesa', '2015-09-01', 0, 0, 'assets/images/default.png', 2, 'SSSCE', 'Adonteng Secondary School', '', '', '', '1', '2015-10-03 00:00:00', '', '', ''),
(3, 'FVIPT5310', 7, 'Emmanuel Obeng', 1, '1992-03-22', 'Male', '1', 'emmallob14@gmail.com', '0554947764', 'Adjiringanor', '2015-10-04', 0, 0, 'assets/images/default.png', 6, NULL, NULL, '', '2015-09-07', '', '1', '2015-10-03 00:00:00', '', '', ''),
(4, 'FVIPT8923', 0, 'Philomena Mensah', 3, '1994-07-20', 'Female', '1', 'philomens@gmail.com', '020554214', 'Adjiringanor, old town', '2015-10-14', 0, 0, 'assets/images/default.png', 5, NULL, NULL, 'More experience in the French language', 'annon', '', '1', '2015-10-06 00:00:00', '', '', ''),
(5, 'FVIPT0092', 0, 'Nicholas Boadi', 2, '2009-06-10', 'Male', '1', 'nicholasboadi@yahoo.com', '0254215400', 'Adjiringanor, old town', '2015-10-01', 0, 0, 'assets/images/default.png', 4, NULL, NULL, 'Over 10 years of experience in teaching social studies and RME. I have taught in at least 5 schools over the past 10 years and have acquired various degrees of knowledge and experiece. and that makes me superb', 'annon', '', '1', '2015-10-07 00:00:00', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `finance_feestype`
--

CREATE TABLE `finance_feestype` (
  `id` int(11) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `type` varchar(255) NOT NULL,
  `level` enum('1','2') NOT NULL DEFAULT '1',
  `note` text NOT NULL,
  `amount` int(11) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `finance_feestype`
--

INSERT INTO `finance_feestype` (`id`, `slug`, `type`, `level`, `note`, `amount`, `status`) VALUES
(1, 'school-fees', 'School Fees', '1', '', 0, '1'),
(2, 'classes-fees', 'Classes Fees', '1', '', 1, '1'),
(3, 'feeding-fees', 'Feeding Fees', '1', '', 3, '1'),
(4, 'sports-fee', 'Sports Fee', '1', '', 1, '1'),
(5, 'p-t-a-dues', 'P.T.A Dues', '1', '', 5, '1'),
(6, 'admission-forms', 'Admission Forms', '1', '', 50, '1');

-- --------------------------------------------------------

--
-- Table structure for table `guardian`
--

CREATE TABLE `guardian` (
  `id` int(11) NOT NULL,
  `uniqueid` varchar(15) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `alias` varchar(200) NOT NULL,
  `profession` varchar(100) NOT NULL,
  `religion` int(11) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `residence` varchar(150) NOT NULL,
  `hometown` varchar(255) NOT NULL,
  `occupation` varchar(50) NOT NULL,
  `ward` varchar(10) NOT NULL DEFAULT '0',
  `photo` varchar(255) NOT NULL DEFAULT 'assets/images/default.png',
  `rdate` datetime NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `admin` varchar(50) NOT NULL,
  `moddate` datetime NOT NULL,
  `modadmin` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guardian`
--

INSERT INTO `guardian` (`id`, `uniqueid`, `fullname`, `alias`, `profession`, `religion`, `phone`, `email`, `address`, `residence`, `hometown`, `occupation`, `ward`, `photo`, `rdate`, `status`, `admin`, `moddate`, `modadmin`) VALUES
(1, 'FVIPG4533', 'Mr Seth Dika', 'mr-seth-dika', 'Electrician', 1, '0243369782', '', 'c/o P. O. Box 52, Legon', 'Ability', 'Ada-Goi', 'Electrician', '0', 'assets/images/default.png', '2016-01-14 00:00:00', '1', '', '0000-00-00 00:00:00', ''),
(2, 'FVIPG4435', 'Memuna Issah Abubakar', 'memuna-issah-abubakar', 'Trader', 2, '0553726452', '', '', 'Dzen-Ayoor', 'Bawku', 'Trader', '0', 'assets/images/default.png', '2016-01-14 00:00:00', '1', '', '0000-00-00 00:00:00', ''),
(3, 'FVIPG9918', 'Regina Ansah Amoakea', 'regina-ansah-amoakea', 'Caterer', 1, '0275131454', '', '', 'Otano', 'Larteh', 'Caterer', '0', 'assets/images/default.png', '2016-01-14 00:00:00', '1', '', '0000-00-00 00:00:00', ''),
(4, 'FVIPG1727', 'Abubakar', 'abubakar', 'Lawyer', 2, '0245388214', '', '', 'White House', 'Kumasi', 'Lawyer', '0', 'assets/images/default.png', '2016-01-14 00:00:00', '1', '', '0000-00-00 00:00:00', ''),
(5, 'FVIPG8794', 'Roger Kovor', 'roger-kovor', 'Capenter', 1, '024850836', '', 'c/o Johnson Bedzra, BOX 5341 Cantonment Accra', 'Adjiringanor', 'Dzodze', 'Capenter', '0', 'assets/images/default.png', '2016-01-14 00:00:00', '1', '', '0000-00-00 00:00:00', ''),
(6, 'FVIPG2061', 'Divine', 'divine', 'Taxi Driver', 1, '0246825678', '', 'P. O. BOX 2', 'Beijin', 'Ho', 'Taxi Driver', '0', 'assets/images/default.png', '2016-01-14 00:00:00', '1', '', '0000-00-00 00:00:00', ''),
(7, 'FVIPG1748', 'Divine Azango', 'divine-azango', 'Taxi Driver', 1, '0246825678', '', 'P. O. BOX 7', 'Beijin', 'Ho', 'Taxi Driver', '0', 'assets/images/default.png', '2016-01-14 00:00:00', '1', '', '0000-00-00 00:00:00', ''),
(8, 'FVIPG9304', 'Cosmos Kumadze', 'cosmos-kumadze', 'Generator Expert', 1, '0243766435', 'blezcosmos@yahoo.com', 'P. O. BOX H676, Hohoe', 'Adonai Lane, Ability', 'Tafi Atome', 'Generator Expert', '0', 'assets/images/default.png', '2016-01-14 04:34:02', '1', 'annon', '0000-00-00 00:00:00', ''),
(9, 'FVIPG302', 'Nyamadi Rejoice', 'nyamadi-rejoice', 'Trader', 1, '0271453339 / 05', 'agbemakorprosper@ymail.com', '', 'Adonai Lane, Ability', 'Anloga', 'Trader', '0', 'assets/images/default.png', '2016-01-14 04:35:38', '1', 'annon', '0000-00-00 00:00:00', ''),
(10, 'FVIPG9511', 'Joseph Odai Afotey', 'joseph-odai-afotey', 'Constructor', 1, '0202268198', '', 'Adjiringanor', 'Teshie-Nungua', '', 'Constructor', '0', 'assets/images/default.png', '2016-01-14 04:36:56', '1', 'annon', '0000-00-00 00:00:00', ''),
(11, 'FVIPG4417', 'Daniel Tawiah', 'daniel-tawiah', 'Driver', 1, '0243348677', '', '', 'Kings Cottage, East Legon', 'Kwame Danso - Brong Ahofo (B/A)', 'Driver', '0', 'assets/images/default.png', '2016-01-14 04:38:38', '1', 'annon', '0000-00-00 00:00:00', ''),
(12, 'FVIPG8424', 'DIana Dkuy', 'diana-dkuy', 'Trader', 1, '0543677413', '', '', 'Adjiringanor', 'La', 'Trader', '0', 'assets/images/default.png', '2016-01-14 04:39:25', '1', 'annon', '0000-00-00 00:00:00', ''),
(13, 'FVIPG9993', 'Obaa Yaa Enchill', 'obaa-yaa-enchill', 'Mason', 1, '02002129728', '', 'P. O. BOX 172, North Kaneshie, Accra', 'Adjiringanor', '', 'Mason', '0', 'assets/images/default.png', '2016-01-14 04:42:03', '1', 'annon', '0000-00-00 00:00:00', ''),
(14, 'FVIPG8973', 'Stephen Tsodor', 'stephen-tsodor', 'Director of Carpenter', 1, '0246491346', '', '', '', 'Kpando, Konda', 'Director of Carpenter', '0', 'assets/images/default.png', '2016-01-14 04:42:55', '1', 'annon', '0000-00-00 00:00:00', ''),
(15, 'FVIPG6364', 'Hector Bristben Fynn', 'hector-bristben-fynn', 'General Deacon of the Word Annointed Church', 1, '0265558559', '', '', 'Adjiringanor', 'Cape Coast', 'General Deacon of the Word Annointed Church', '0', 'assets/images/default.png', '2016-01-14 04:56:30', '1', 'annon', '0000-00-00 00:00:00', ''),
(16, 'FVIPG8774', 'Alberta Banga', 'alberta-banga', 'Business Woman', 1, '0244797469 / 0244 714291', 'georgeatvision@yahoo.com', 'P. O. BOX MD 220 Madina, Accra', 'Dzen-Ayoor, East Legon', 'Bolgatanga', 'Business Woman', '0', 'assets/images/default.png', '2016-01-14 04:58:49', '1', 'annon', '0000-00-00 00:00:00', ''),
(17, 'FVIPG3805', 'Diana Amanyo', 'diana-amanyo', 'Trader', 1, '0277560862', '', 'P. O. BOX 9967 KIA', 'Nana Krom', 'Nkawkaw', 'Trader', '0', 'assets/images/default.png', '2016-01-14 04:59:44', '1', 'annon', '0000-00-00 00:00:00', ''),
(18, 'FVIPG7633', 'Godwin Banson', 'godwin-banson', 'Trader', 1, '0206715118', '', '', 'Beijin', 'Have, Volta Region', 'Trader', '0', 'assets/images/default.png', '2016-01-14 05:00:46', '1', 'annon', '0000-00-00 00:00:00', ''),
(19, 'FVIPG1026', 'Mr. Salley & Mrs. Leila Adamu', 'mr-salley-mrs-leila-adamu', 'Station Master', 2, '0266659905', '', '', 'Dzen-Ayoor', 'Eastern Region', 'Station Master', '0', 'assets/images/default.png', '2016-01-14 05:01:35', '1', 'annon', '0000-00-00 00:00:00', ''),
(20, 'FVIPG5043', 'Cecilia Nyame Fynn', 'cecilia-nyame-fynn', 'Trader', 1, '0249808375', '', '', 'Adjiringanor', 'Mankessim', 'Trader', '0', 'assets/images/default.png', '2016-01-14 05:02:33', '1', 'annon', '0000-00-00 00:00:00', ''),
(21, 'FVIPG2676', 'Dorcas Adu Boahen', 'dorcas-adu-boahen', 'Seamstress', 1, '0277372681', '', '', 'Beijin', 'Asin Breku', 'Seamstress', '0', 'assets/images/default.png', '2016-01-14 05:03:17', '1', 'annon', '0000-00-00 00:00:00', ''),
(22, 'FVIPG7681', 'Richmond Opare', 'richmond-opare', 'Soldier', 1, '0546103967', 'innocentpa2@gmail.com', '', 'Afordable, School Junction', 'Adumbonso', 'Soldier', '0', 'assets/images/default.png', '2016-01-14 05:04:51', '1', 'annon', '0000-00-00 00:00:00', ''),
(23, 'FVIPG6840', 'Johnson Shittu', 'johnson-shittu', 'Business Man', 1, '0240099445', '', '', 'Beijin', 'James Town', 'Business Man', '0', 'assets/images/default.png', '2016-01-14 05:05:50', '1', 'annon', '0000-00-00 00:00:00', ''),
(24, 'FVIPG6916', 'Daniel Doe', 'daniel-doe', 'Sales Manager', 1, '0244540529', 'danieldoe@yahoo.com', '', 'Trassacco', 'Adakulu Ahonda', 'Sales Manager', '0', 'assets/images/default.png', '2016-01-14 07:41:57', '1', 'annon', '2014-01-16 23:37:38', 'annon'),
(25, 'FVIPG2543', 'Joseph Nii Mensah Ashong', 'joseph-nii-mensah-ashong', 'building contractor', 1, '0242039221', 'jomens4real@gmail.com', 'C43/26OKPONGLO-EASTLEGON', 'okponglo eastlegon', 'la', 'buildingcontractor', '0', 'assets/images/default.png', '2016-01-15 13:11:25', '1', 'desmond', '0000-00-00 00:00:00', ''),
(26, 'FVIPG6303', 'Acheamfour Baah', 'acheamfour-baah', 'Constructor', 1, '0246793723', 'acheamfour.baah@yahoo.com', '', 'Adjiringanor', 'Beposo-Ashanti', 'Constructor', '0', 'assets/images/default.png', '2016-01-15 13:17:06', '1', 'desmond', '0000-00-00 00:00:00', ''),
(27, 'FVIPG7244', 'Florence Mensah', 'florence-mensah', 'Trader', 1, '', '', 'P.O.BOX6', 'Adjiringanor', 'Kumasi', 'Trader', '0', 'assets/images/default.png', '2016-01-15 13:21:14', '1', 'desmond', '0000-00-00 00:00:00', ''),
(28, 'FVIPG9083', 'Stephen Avuvor', 'stephen-avuvor', 'Mason', 1, '0243530694', '', '', 'Otanor', 'Have', 'Mason', '0', 'assets/images/default.png', '2016-01-15 13:26:14', '1', 'desmond', '0000-00-00 00:00:00', ''),
(29, 'FVIPG4343', 'Joyce Mensah', 'joyce-mensah', 'Trader', 1, '0241863294', '', '', 'Dzenayoor', 'Kumasi', 'Trader', '0', 'assets/images/default.png', '2016-01-15 13:30:41', '1', 'desmond', '0000-00-00 00:00:00', ''),
(30, 'FVIPG5686', 'Annie Nancy', 'annie-nancy', 'Trader', 1, '0540518573', '', '', 'Otinshie', 'Hohoe', 'Trader', '0', 'assets/images/default.png', '2016-01-15 13:30:51', '1', 'annon', '0000-00-00 00:00:00', ''),
(31, 'FVIPG676', 'Salomey', 'salomey', 'Fish Seller', 1, '0541284790', '', '', 'Otano', 'Kumasi', 'Fish Seller', '0', 'assets/images/default.png', '2016-01-15 13:33:43', '1', 'annon', '0000-00-00 00:00:00', ''),
(32, 'FVIPG1230', 'Mr. Afotey Joseph', 'mr-afotey-joseph', 'Driver', 1, '0579256525', '', '', 'Adjiringanor', 'Teshie', 'Driver', '0', 'assets/images/default.png', '2016-01-15 13:35:13', '1', 'annon', '0000-00-00 00:00:00', ''),
(33, 'FVIPG4015', 'Christiana Afai Moti', 'christiana-afai-moti', 'Trader', 1, '0249210601', '', '', 'Otano', 'Northern Region', 'Trader', '0', 'assets/images/default.png', '2016-01-15 13:35:59', '1', 'annon', '0000-00-00 00:00:00', ''),
(34, 'FVIPG3019', 'Mohammed Enchil', 'mohammed-enchil', 'Mason', 1, '0200429728', '', 'P.O.BOX174HORTHKANESHI', 'Adjiringanor', 'Mankessim', 'Mason', '0', 'assets/images/default.png', '2016-01-15 13:36:11', '1', 'desmond', '0000-00-00 00:00:00', ''),
(35, 'FVIPG572', 'Agbeli Famous', 'agbeli-famous', 'Carpenter', 1, '0248646245', '', '', 'Beijin', 'Agortime Kpetoe', 'Carpenter', '0', 'assets/images/default.png', '2016-01-15 13:36:45', '1', 'annon', '0000-00-00 00:00:00', ''),
(36, 'FVIPG8045', 'Amanyo Emmanuel', 'amanyo-emmanuel', 'Driver', 1, '0262370622 / 0241715617', '', 'P.O.BOX9967K.L.A.ACCRA', 'Nanakrom', 'Dzodze', 'Driver', '0', 'assets/images/default.png', '2016-01-15 13:40:43', '1', 'desmond', '0000-00-00 00:00:00', ''),
(37, 'FVIPG2495', 'Seth.a.laryea', 'seth-a-laryea', 'Bussinessman', 1, '0242216997/0244922658', '', '', 'Adjiringanor', 'Teshi', 'Bussinessman', '0', 'assets/images/default.png', '2016-01-15 13:45:33', '1', 'desmond', '0000-00-00 00:00:00', ''),
(38, 'FVIPG489', 'Sena Homenya', 'sena-homenya', 'Building Conctractor', 1, '0542682416', 'senahomenya@hotmail.com', '', 'Adjiringanor', 'Kpando', 'Building Conctractor', '0', 'assets/images/default.png', '2016-01-15 13:45:45', '1', 'annon', '0000-00-00 00:00:00', ''),
(39, 'FVIPG5371', 'Ajara Shuala', 'ajara-shuala', 'Trader', 2, '0242686712', '', '', 'Dzen-Ayoor', 'Khejebi - Volta Region', 'Trader', '0', 'assets/images/default.png', '2016-01-15 13:46:40', '1', 'annon', '0000-00-00 00:00:00', ''),
(40, 'FVIPG9216', 'Mis Patience Sarfo', 'mis-patience-sarfo', 'Trader', 1, '0249171134', '', '', 'Adjiringanor', 'Somanya', 'Trader', '0', 'assets/images/default.png', '2016-01-15 13:47:24', '1', 'annon', '0000-00-00 00:00:00', ''),
(41, 'FVIPG5722', 'Gladys Oko', 'gladys-oko', 'Seamstress', 1, '0234158437', '', '', 'Adjiringanor', 'Teshie', 'Seamstress', '0', 'assets/images/default.png', '2016-01-15 13:48:05', '1', 'annon', '0000-00-00 00:00:00', ''),
(42, 'FVIPG5282', 'Peace Negle', 'peace-negle', 'Seller', 1, '0249771557', '', '', 'Ogbojo Near Brookwood Hill School', 'Lume Hugakope', 'Seller', '0', 'assets/images/default.png', '2016-01-15 13:50:22', '1', 'annon', '0000-00-00 00:00:00', ''),
(43, 'FVIPG8509', 'John Ohene Djan', 'john-ohene-djan', 'Painter', 1, '0243169695', '', '', 'Tesa, Adjiringanor', 'Kukurantumi, Eastern Region', 'Painter', '0', 'assets/images/default.png', '2016-01-15 13:51:04', '1', 'annon', '0000-00-00 00:00:00', ''),
(44, 'FVIPG9430', 'Janet Frimpong', 'janet-frimpong', 'Teacher', 1, '0265678924', '', '', 'Tesa, Adjiringanor', 'Beposo', 'Teacher', '0', 'assets/images/default.png', '2016-01-15 13:52:00', '1', 'annon', '0000-00-00 00:00:00', ''),
(45, 'FVIPG4631', 'Vincent Yao Quarshie Avorditey', 'vincent-yao-quarshie-avorditey', 'Designer', 1, '0246308262', '', '', 'Otinshie', 'Agbozome', 'Designer', '0', 'assets/images/default.png', '2016-01-15 14:19:31', '1', 'desmond', '0000-00-00 00:00:00', ''),
(46, 'FVIPG9588', 'Alex Konadu', 'alex-konadu', 'Trada', 0, '', '', '', '', '', 'Trada', '0', 'assets/images/default.png', '2016-01-15 14:35:19', '1', 'yunus', '0000-00-00 00:00:00', ''),
(47, 'FVIPG8425', 'Beauty Okroma', 'beauty-okroma', 'Headdresser', 1, '0242931346', '', '', 'Bedzin', 'Hohoe', 'Headdresser', '0', 'assets/images/default.png', '2016-01-15 14:37:01', '1', 'desmond', '0000-00-00 00:00:00', ''),
(48, 'FVIPG8374', 'Alex Konadu', 'alex-konadu', 'Trader', 1, '0244168269', '', '', 'Berjin', 'Akumadan', 'Trader', '0', 'assets/images/default.png', '2016-01-15 14:37:55', '1', 'yunus', '0000-00-00 00:00:00', ''),
(49, 'FVIPG5162', 'Mr. Salley & Mrs. Leila Adamu', 'mr-salley-mrs-leila-adamu', 'Station Master', 2, '0266659909', '', '', 'Dzen-Ayoor, East Legon', 'Eastern Region', 'Station Master', '0', 'assets/images/default.png', '2016-01-15 14:44:03', '1', 'yunus', '0000-00-00 00:00:00', ''),
(50, 'FVIPG592', 'Alberta Banga', 'alberta-banga', 'Business Woman', 1, '0244797469', '', '', 'Dzen-Ayoor', 'Bolgatanga', 'Business Woman', '0', 'assets/images/default.png', '2016-01-15 14:48:44', '1', 'yunus', '0000-00-00 00:00:00', ''),
(51, 'FVIPG8555', 'Hector Bristben Fynn', 'hector-bristben-fynn', 'Pastor', 1, '025558559', '', '', 'Adjiringanor', 'Mankessim', 'Pastor', '0', 'assets/images/default.png', '2016-01-15 14:50:15', '1', 'desmond', '0000-00-00 00:00:00', ''),
(52, 'FVIPG736', 'Donatus Kwame Adzimah', 'donatus-kwame-adzimah', 'Lube Bay Attendant', 1, '0207394364', '', '', 'Dzen-Ayoor', 'Hohoe', 'Lube Bay Attendant', '0', 'assets/images/default.png', '2016-01-15 14:54:40', '1', 'yunus', '0000-00-00 00:00:00', ''),
(53, 'FVIPG8252', 'Mr.james Oko Annang', 'mr-james-oko-annang', 'Driver', 1, '0276929218', '', '', 'Adjiringanor', 'Teshie', 'Driver', '0', 'assets/images/default.png', '2016-01-15 14:56:55', '1', 'yunus', '0000-00-00 00:00:00', ''),
(54, 'FVIPG484', 'Seth Doevison', 'seth-doevison', 'Bussinessman', 1, '0205191352', 'doevison@yahoo.com', '', 'Ability', 'Ho', 'Bussinessman', '0', 'assets/images/default.png', '2016-01-15 14:58:00', '1', 'desmond', '0000-00-00 00:00:00', ''),
(55, 'FVIPG7338', 'Eric Quarshie', 'eric-quarshie', 'Carpenter', 1, '0247939371', '', '', 'Bedzin', 'Hohoe', 'Carpenter', '0', 'assets/images/default.png', '2016-01-15 15:00:43', '1', 'desmond', '0000-00-00 00:00:00', ''),
(56, 'FVIPG6203', 'Mr Daniel Opare', 'mr-daniel-opare', 'Constructor', 1, '0277083564', '', '', 'Otano', 'Anum Baso', 'Constructor', '0', 'assets/images/default.png', '2016-01-15 15:01:04', '1', 'yunus', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `guardian_add`
--

CREATE TABLE `guardian_add` (
  `id` int(11) NOT NULL,
  `parent` int(11) NOT NULL,
  `ward` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guardian_add`
--

INSERT INTO `guardian_add` (`id`, `parent`, `ward`) VALUES
(1, 3576057, 1),
(2, 3576057, 2),
(3, 689403, 1),
(4, 689403, 2);

-- --------------------------------------------------------

--
-- Table structure for table `guardian_ward`
--

CREATE TABLE `guardian_ward` (
  `id` int(11) NOT NULL,
  `guard` varchar(10) NOT NULL,
  `ward` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guardian_ward`
--

INSERT INTO `guardian_ward` (`id`, `guard`, `ward`) VALUES
(2, '1', 'FVIP41897'),
(3, '24', 'FVIP82379');

-- --------------------------------------------------------

--
-- Table structure for table `months`
--

CREATE TABLE `months` (
  `id` int(11) NOT NULL,
  `name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `months`
--

INSERT INTO `months` (`id`, `name`) VALUES
(1, 'January'),
(2, 'February'),
(3, 'March'),
(4, 'April'),
(5, 'May'),
(6, 'June'),
(7, 'July'),
(8, 'August'),
(9, 'September'),
(10, 'October'),
(11, 'November'),
(12, 'December');

-- --------------------------------------------------------

--
-- Table structure for table `payhead`
--

CREATE TABLE `payhead` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payhead`
--

INSERT INTO `payhead` (`id`, `name`, `slug`, `description`, `status`) VALUES
(1, 'Feeding Allowances', 'feeding-allowances', '', '1'),
(2, 'Basic Salary', 'basic-salary', 'This Is The Basic Salary Of An Employee And He Is Entitled To This In Addition To Other Payments.', '1'),
(3, 'Full Salary', 'full-salary', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `unqid` varchar(20) NOT NULL,
  `feetypeid` int(5) NOT NULL DEFAULT '0',
  `feetype` varchar(50) NOT NULL DEFAULT '0',
  `studentid` varchar(50) NOT NULL DEFAULT '0',
  `studentunq` varchar(15) NOT NULL,
  `studentemail` varchar(50) NOT NULL,
  `studentphone` varchar(15) NOT NULL,
  `class` varchar(50) NOT NULL,
  `classid` int(11) NOT NULL,
  `amount` varchar(10) NOT NULL,
  `academicyear` varchar(15) NOT NULL,
  `term` varchar(15) NOT NULL,
  `date` date NOT NULL,
  `rdate` date NOT NULL,
  `rname` varchar(50) NOT NULL,
  `status` varchar(5) NOT NULL DEFAULT '1',
  `updater` varchar(60) NOT NULL,
  `dateupd` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `unqid`, `feetypeid`, `feetype`, `studentid`, `studentunq`, `studentemail`, `studentphone`, `class`, `classid`, `amount`, `academicyear`, `term`, `date`, `rdate`, `rname`, `status`, `updater`, `dateupd`) VALUES
(1, 'INV3139953', 1, 'School Fees', 'Setsofia Paula', '6987', '', '', 'JHS 1', 7, '200', '2015/2016', '1', '2015-10-02', '2015-10-05', 'annon', '1', '', '0000-00-00'),
(2, 'INV3899230', 1, 'School Fees', 'Tagoe Tryzinna', 'VIP2810', '', '', 'JHS 1', 7, '200', '2015/2016', '1', '2015-10-02', '2015-10-05', 'annon', '1', '', '0000-00-00'),
(3, 'INV8627319', 1, 'School Fees', 'Tagoe Tryzinna', 'VIP2810', '', '', 'JHS 1', 7, '200', '2015/2016', '1', '2015-10-03', '2015-10-05', 'annon', '1', '', '0000-00-00'),
(4, 'INV2403564', 1, 'School Fees', 'Baah Akwasi', 'VIP9510', '', '', 'JHS 1', 7, '50', '2015/2016', '1', '2015-10-07', '2015-10-07', 'annon', '1', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

CREATE TABLE `payroll` (
  `id` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `acc_year` varchar(10) NOT NULL,
  `designation` int(11) NOT NULL,
  `payhead` int(11) NOT NULL,
  `employeeid` varchar(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `year` varchar(5) NOT NULL,
  `rdate` date NOT NULL,
  `rname` text NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payroll`
--

INSERT INTO `payroll` (`id`, `month`, `acc_year`, `designation`, `payhead`, `employeeid`, `amount`, `year`, `rdate`, `rname`, `status`) VALUES
(1, 9, '2015/2016', 1, 3, 'FVIPT2345', 350, '2015', '2015-10-08', 'annon', '1'),
(2, 10, '2015/2016', 1, 3, 'FVIPT8923', 350, '2015', '2015-11-23', 'annon', '1'),
(3, 10, '2015/2016', 2, 3, 'FVIPT8923', 400, '2015', '2015-11-23', 'annon', '1'),
(4, 11, '2015/2016', 1, 3, 'FVIPT5310', 300, '2015', '2016-02-11', 'cregistry', '1'),
(5, 12, '2015/2016', 1, 3, 'FVIPT5310', 300, '2015', '2016-02-11', 'cregistry', '1'),
(6, 1, '2015/2016', 1, 3, 'FVIPT5310', 300, '2016', '2016-02-13', 'cregistry', '1'),
(7, 2, '2015/2016', 1, 3, 'FVIPT5310', 500, '2016', '2016-02-13', 'cregistry', '1');

-- --------------------------------------------------------

--
-- Table structure for table `qualification`
--

CREATE TABLE `qualification` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qualification`
--

INSERT INTO `qualification` (`id`, `name`, `slug`, `status`) VALUES
(1, 'JHS', 'jhs', '1'),
(2, 'SHS', 'shs', '1'),
(3, 'O''Level', 'o-level', '1'),
(4, 'A''Level', 'a-level', '1'),
(5, '1st Degree', '1st-degree', '1'),
(6, '2nd Degree', '2nd-degree', '1'),
(7, 'Professor in Theological Studies', 'professor-in-theological-studies', '1');

-- --------------------------------------------------------

--
-- Table structure for table `religion`
--

CREATE TABLE `religion` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(25) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `religion`
--

INSERT INTO `religion` (`id`, `name`, `slug`, `status`) VALUES
(1, 'Christianity', '', '1'),
(2, 'Islam', '', '1'),
(3, 'Hindu', '', '0'),
(4, 'Hari Krishna', '', '0'),
(5, 'Ekankar', '', '0'),
(6, 'Catholic', '', '0'),
(7, 'Mozama Disco Christo Church', 'mozama-disco-christo-chur', '0'),
(8, 'Muslim', 'muslim', '0');

-- --------------------------------------------------------

--
-- Table structure for table `remarks`
--

CREATE TABLE `remarks` (
  `id` int(11) NOT NULL,
  `s_table` int(11) NOT NULL,
  `headteacher` text NOT NULL,
  `proprietries` text NOT NULL,
  `uniqueid` varchar(15) NOT NULL,
  `date` datetime NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `salary_settings`
--

CREATE TABLE `salary_settings` (
  `id` int(11) NOT NULL,
  `designation` int(11) NOT NULL,
  `payhead` int(11) NOT NULL,
  `employeeid` varchar(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `balance` int(11) NOT NULL,
  `rdate` date NOT NULL,
  `rname` varchar(15) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salary_settings`
--

INSERT INTO `salary_settings` (`id`, `designation`, `payhead`, `employeeid`, `amount`, `balance`, `rdate`, `rname`, `status`) VALUES
(1, 1, 3, 'FVIPT2345', 350, 0, '2015-10-08', 'annon', '1'),
(2, 2, 3, 'FVIPT8743', 450, 0, '2015-10-08', 'annon', '1'),
(3, 3, 3, 'FVIPT0092', 300, 0, '2015-10-08', 'annon', '1'),
(4, 1, 3, 'FVIPT5310', 350, 0, '2015-10-08', 'annon', '1');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `studentunq` varchar(255) NOT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `nameslug` varchar(255) NOT NULL,
  `parent` int(11) DEFAULT '0',
  `teacher` int(11) NOT NULL DEFAULT '0',
  `dob` date DEFAULT NULL,
  `gender` enum('Male','Female','Null') DEFAULT NULL,
  `religion` int(11) DEFAULT '0',
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `language` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `residence` varchar(150) NOT NULL,
  `class` int(11) NOT NULL DEFAULT '0',
  `photo` varchar(255) NOT NULL DEFAULT 'assets/images/default.png',
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `rname` varchar(50) NOT NULL,
  `rdate` date NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `headteacher_remarks` text NOT NULL,
  `proprietries_remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `studentunq`, `surname`, `firstname`, `nameslug`, `parent`, `teacher`, `dob`, `gender`, `religion`, `email`, `phone`, `language`, `address`, `residence`, `class`, `photo`, `username`, `password`, `rname`, `rdate`, `status`, `headteacher_remarks`, `proprietries_remarks`) VALUES
(1, 'FVIP41897', 'Obeng', 'Emmanuel Kwesi', 'obengemmanuel-kwesi9', 0, 2, '1999-06-23', 'Male', 1, 'emmallob14@gmail.com', '0275131454', 'Twi, English', 'P. O. BOX 172, North Kaneshie, Accra', 'Adjiringanor', 9, 'assets/images/default.png', '', '', 'annon', '2016-01-14', '1', '', ''),
(2, 'FVIP82379', 'Doe', 'Desmond', 'doedesmond8', 0, 0, '2001-07-08', 'Male', 1, '', '0542509374', 'Ewe, Twi & English', '', 'Trassacco', 8, 'assets/images/default.png', '', '', 'annon', '2016-01-14', '1', 'This is the best student that we have have over the period. He is an extraordinary student and i will recommend him for all who wants him in his or her organization', '');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `year` varchar(4) NOT NULL,
  `name` varchar(50) NOT NULL,
  `class` int(11) NOT NULL,
  `teacher` int(11) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `code`, `year`, `name`, `class`, `teacher`, `status`) VALUES
(1, 'acall-classes-ict-2015', '2015', 'ICT', 1, 3, '1'),
(2, 'acall-classes-ict-2015', '2015', 'ICT', 2, 3, '1'),
(3, 'acall-classes-ict-2015', '2015', 'ICT', 3, 3, '1'),
(4, 'acall-classes-ict-2015', '2015', 'ICT', 4, 3, '1'),
(5, 'acall-classes-ict-2015', '2015', 'ICT', 5, 3, '1'),
(6, 'acall-classes-ict-2015', '2015', 'ICT', 6, 3, '1'),
(7, 'acall-classes-ict-2015', '2015', 'ICT', 7, 3, '1'),
(8, '8-ict-2015', '2015', 'ICT', 8, 3, '1'),
(9, 'acall-classes-ict-2015', '2015', 'ICT', 9, 3, '1');

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id` int(5) NOT NULL,
  `FirstName` varchar(50) NOT NULL DEFAULT '',
  `LastName` varchar(50) NOT NULL DEFAULT '',
  `FullName` varchar(120) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `lastPassChange` datetime NOT NULL,
  `lastPassChangeDays` int(30) NOT NULL,
  `PassSalt` varchar(200) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Level` varchar(20) NOT NULL DEFAULT 'editor',
  `Role` int(5) DEFAULT NULL,
  `SecureQuestion` varchar(200) DEFAULT NULL,
  `SecureAnswer` varchar(200) DEFAULT NULL,
  `LastAccess` datetime DEFAULT '0000-00-00 00:00:00',
  `Activated` tinyint(1) DEFAULT '0',
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id`, `FirstName`, `LastName`, `FullName`, `Username`, `Password`, `lastPassChange`, `lastPassChangeDays`, `PassSalt`, `Email`, `Level`, `Role`, `SecureQuestion`, `SecureAnswer`, `LastAccess`, `Activated`, `status`) VALUES
(1, 'Customs', 'Registry', 'Future VIP School', 'cregistry', '7e74dbc20b7e54a5319c426e1ffe1232 ', '0000-00-00 00:00:00', 0, NULL, 'cregistry@localhost', 'editor', 1, NULL, NULL, '2016-02-14 18:26:09', 1, '1'),
(2, 'Annonymous', 'Registry', 'Annonymous', 'annon', '7e74dbc20b7e54a5319c426e1ffe1232 ', '0000-00-00 00:00:00', 0, NULL, 'annon@localhost', 'editor', 3, NULL, NULL, '2014-01-18 12:02:18', 1, '1'),
(3, 'Desmond', 'Doe', 'Doesmond Doe', 'desmond', '7e74dbc20b7e54a5319c426e1ffe1232 ', '0000-00-00 00:00:00', 0, NULL, 'annon@localhost', 'editor', 3, NULL, NULL, '2016-01-15 14:34:39', 1, '1'),
(4, 'Yunus', 'Salley', 'Yunus Salley', 'yunus', '7e74dbc20b7e54a5319c426e1ffe1232 ', '0000-00-00 00:00:00', 0, NULL, 'annon@localhost', 'editor', 3, NULL, NULL, '2016-01-15 14:33:46', 1, '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cepstb_options`
--
ALTER TABLE `cepstb_options`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delete_history`
--
ALTER TABLE `delete_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `designation`
--
ALTER TABLE `designation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `finance_feestype`
--
ALTER TABLE `finance_feestype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guardian`
--
ALTER TABLE `guardian`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guardian_add`
--
ALTER TABLE `guardian_add`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guardian_ward`
--
ALTER TABLE `guardian_ward`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `months`
--
ALTER TABLE `months`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payhead`
--
ALTER TABLE `payhead`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payroll`
--
ALTER TABLE `payroll`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qualification`
--
ALTER TABLE `qualification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `religion`
--
ALTER TABLE `religion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `remarks`
--
ALTER TABLE `remarks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salary_settings`
--
ALTER TABLE `salary_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usr_role_fk` (`Role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cepstb_options`
--
ALTER TABLE `cepstb_options`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `delete_history`
--
ALTER TABLE `delete_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `designation`
--
ALTER TABLE `designation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `finance_feestype`
--
ALTER TABLE `finance_feestype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `guardian`
--
ALTER TABLE `guardian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `guardian_add`
--
ALTER TABLE `guardian_add`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `guardian_ward`
--
ALTER TABLE `guardian_ward`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `months`
--
ALTER TABLE `months`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `payhead`
--
ALTER TABLE `payhead`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `payroll`
--
ALTER TABLE `payroll`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `qualification`
--
ALTER TABLE `qualification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `religion`
--
ALTER TABLE `religion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `remarks`
--
ALTER TABLE `remarks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `salary_settings`
--
ALTER TABLE `salary_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
